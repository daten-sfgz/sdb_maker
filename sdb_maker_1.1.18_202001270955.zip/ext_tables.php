<?php
defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
    function()
    {

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
            'Sfgz.SdbMaker',
            'Model',
            'SDB Databse Maker'
        );

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addStaticFile('sdb_maker', 'Configuration/TypoScript', 'SDB Maker');
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_sdbmaker_domain_model_accesspoints', 'EXT:sdb_maker/Resources/Private/Language/locallang_csh_tx_sdbmaker_domain_model_accesspoints.xlf');

    }
);

if (TYPO3_MODE === 'BE') {
        // load plugin model (model-controller to modeling database in fe)
        
        $addScript = \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extPath('sdb_maker').'../sdb_adminer/class.tx_sdbadminer_addFieldsToFlexForm.php';
        if( file_exists($addScript) ){
            include_once($addScript);
            // $TCA['tt_content']['types']['list']['subtypes_addlist']['sdbmaker_model'] = 'pi_flexform,bodytext';
            $flexform = 'sdbmaker_model.xml';
        }else{
            //$TCA['tt_content']['types']['list']['subtypes_addlist']['sdbmaker_model'] = 'pi_flexform';
            $flexform = 'sdbmaker_model_standalone.xml';
        }
        $TCA['tt_content']['types']['list']['subtypes_addlist']['sdbmaker_model'] = 'pi_flexform';
        
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPiFlexFormValue('sdbmaker_model', 'FILE:EXT:sdb_maker/Configuration/Flexforms/' . $flexform );
        
        // prevent pages-chooser in this content-element
        $TCA['tt_content']['types']['list']['subtypes_excludelist']['sdbmaker_model']='pages';

}
