
plugin.tx_sdbmaker_model {
    view {
        templateRootPaths.0 = EXT:sdb_maker/Resources/Private/Templates/
        partialRootPaths.0 = EXT:sdb_maker/Resources/Private/Partials/
        layoutRootPaths.0 = EXT:sdb_maker/Resources/Private/Layouts/
    }
    features {
      requireCHashArgumentForActionArguments = 0
    }
    settings {
        displayDateFormat = d.m.Y
        sql_config {
            ## ascii of special chars to replace in fieldnames: slash/ space/ [ a/ o/ u with umlaud] /sharp german sz
            searchChrRepString {
                    47 = _
                    32 = _
                    228 = ae
                    246 = oe
                    252 = ue
                    223 = ss
            }
            ## ascii ranges of allowed chars: 0 to 31 , 48 to 57 , 59 , 65 to 90 , 95 , 97 to 122
            searchRepAsciiRanges {
                    0 = 31
                    48 = 57
                    59 = 59
                    65 = 90
                    95 = 95
                    97 = 122
            }
            ## default name for unique key
            sNameDefaultUniqueKey = uid
            
            ## unique key for related tables [ 0 | 1 |2 ]
            bPrependOrAppendFieldnameToKey = 1
            
            ## how numerator is separed in dedublicated-fieldnames field_1, field_2 ...
            sNamesCounterSeparer = _
            
            ## transform field names to lowercase
            bFieldNamesLowercase = 1
            
            ## transform first char of field names to uppercase
            bFieldNamesUppercaseFirst = 1
            
            ## if false then field names are concatenated_by_underscore, otherwise byLowerCamelCase
            bFieldNamesConcatCamelCase = 1
            
            ## transform tablenames to lowercase
            bTableNamesLowercase = 1
            
            ## transform first char of tablenames to uppercase
            bTableNamesUppercaseFirst = 1
            
            ## if false then table names are concatenated_by_underscore, otherwise byLowerCamelCase
            bTableNamesConcatCamelCase = 1
            
            ## how foreign 1:n table names are separed
            sTableSeparer1n = _
            
            ## how subordinated n:m table names are separed
            sTableSeparerNm = _nm_
            
            ## order of names for 1n, 1m and nm tables. 0:tablename_fieldname , 1:fieldname_tablename
            iNamesOrderTableField = 0
            
            ## table defaults
            sSqlTableDefaults = ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_german2_ci
            
        }
        display_defaults {
                size {
                    RICHTEXT = 30x20
                    TEXTAREA = 40x8
                    NM_TABLE = 5
                }
                search.default = 1
                list.default = 1
        }
        sql_standalone {
            read_all_dbs = 1
            sql_limit_fe = 6000
            render_tinyint_1 = checkbox
            render_smallint_1 = checkbox
            render_mediumint_1 = checkbox
            render_int_1 = checkbox
            render_bit_1 = checkbox
            render_current_timestamp = label
            render_tinytext = textarea
            render_text = textarea
            render_richtext = richtext
            render_blob = textarea
            render_date = date
            render_time = time
            render_enum = selector
            render_set = checkgroup
        }
    }
}

page.includeJS.sdb_maker = typo3conf/ext/sdb_maker/Resources/Public/Scr/sdb_maker.js
page.includeJSFooter.sdbm_plugin_conf = typo3conf/ext/sdb_maker/Resources/Public/Scr/sdb_plugin_conf.js
page.includeJSFooter.sdbm_editlist = typo3conf/ext/sdb_maker/Resources/Public/Scr/sdb_editlist.js

lib.math = TEXT
  lib.math {
  current = 1
  prioriCalc = 1
}

// PAGE object for Ajax call:
ajaxselectlist_sdbmaker = PAGE
ajaxselectlist_sdbmaker {
    typeNum = 1563150001
 
    config {
        disableAllHeaderCode = 1
        additionalHeaders = Content-type:application/html
        xhtml_cleaning = 0
        debug = 0
        no_cache = 1
        admPanel = 0
    }
 
    10 < tt_content.list.20.sdbmaker_model
}

# the pageType 1563700001 appears in views ...
json_calls_sdbmaker = PAGE
json_calls_sdbmaker {
  config {
    disableAllHeaderCode = 1
    debug = 1
    no_cache = 1
    additionalHeaders {
      10 {
        header = Content-Type: application/json
        replace = 1
      }
    }
  }
  typeNum = 1563700001
   10 = USER_INT
   10 {
      userFunc = TYPO3\CMS\Extbase\Core\Bootstrap->run
      extensionName = SdbMaker
      pluginName = Model
      vendorName = Sfgz
      controller = Json
	  action = main
      switchableControllerActions {
         Json {
            1 = main
            2 = parents
            3 = children
         }
      }
   }
}


plugin.tx_sdbmaker._CSS_DEFAULT_STYLE (
    textarea.f3-form-error {
        background-color:#FF9F9F;
        border: 1px #FF0000 solid;
    }

    input.f3-form-error {
        background-color:#FF9F9F;
        border: 1px #FF0000 solid;
    }

    .typo3-messages .message-error, span.error {
        color:red;
    }

    .typo3-messages .message-ok, span.ok {
        color:green;
    }

    .tx-sdb-maker .state_0, .tx-sdb-maker .state_10, .tx-sdb-maker .state_20 {
        color:red;
    }

    .tx-sdb-maker .state_1, .tx-sdb-maker .state_11, .tx-sdb-maker .state_12 {
        color:green;
    }
    
	.tx-sdb-maker .widget:hover {
		box-shadow: 0 0 10px #00BDFF;
		border-radius: 4px;
	}

	.tx-sdb-maker TABLE TR TH, .tx-sdb-maker TABLE TR TD{
        vertical-align:top; 
	}

	.tx-sdb-maker TABLE.filelist {
        width:auto;
	}
	.tx-sdb-maker TABLE.filelist TR TD INPUT[type="submit"] {
        border:0;background:#fff;padding:0;cursor:pointer;
		font-size:100%;
	}

	.tx-sdb-maker TABLE TR TD INPUT.xls[type="submit"] {
        background-image: url(/typo3conf/ext/sfgz_design/Resources/Public/Img/Fileicons/xls.png);
        background-repeat: no-repeat;
		background-position: left ;
		padding-left:18px;
	}
	.tx-sdb-maker INPUT.xls[type="submit"]:hover,
	.tx-sdb-maker A:hover {
		opacity:0.6;
	}
	
	.tx-sdb-maker TD,
	.tx-sdb-maker TD A,
	.tx-sdb-maker TD A:visited,
	.tx-sdb-maker TD A:link
	{
		color:black;
	}
	
	.tx-sdb-maker TABLE TR.selected TD,
	.tx-sdb-maker TABLE TR.selected TD INPUT[type="submit"],
	.tx-sdb-maker TABLE TR.selected TD A,
	.tx-sdb-maker TABLE TR.selected TD A:visited,
	.tx-sdb-maker TABLE TR.selected TD A:link
	{
		font-weight:bold;
	}

	.tx-sdb-maker INPUT[type="submit"]:hover {
        color:#555;
	}

	.tx-sdb-maker TABLE.report {  border-collapse: separe;border-spacing: 0;}
	
	.tx-sdb-maker TABLE.report THEAD TR TH { 
        background:#333; 
        color:white;
        padding:2px 4px; 
	}
	.tx-sdb-maker TABLE.report.zebra THEAD TR TH { 
        font-style:italic; 
	}

	.tx-sdb-maker TABLE.report.zebra TBODY TR:nth-child(even) { background:#e0e0e0; }
	.tx-sdb-maker TABLE.report.zebra TBODY TR:nth-child(odd) { background:#f0f0f0; }
	.tx-sdb-maker TABLE.report.zebra TBODY TR.multipleValues:nth-child(even) { background:#f0e0d0; }
	.tx-sdb-maker TABLE.report.zebra TBODY TR.multipleValues:nth-child(odd) { background:#fff3dd; }

	.tx-sdb-maker TABLE.report TBODY TR TD {
        padding:8px 4px; 
        border-bottom:1px solid white;
	}

	.tx-sdb-maker TABLE.report TBODY TR.multipleValues TD {
            font-style:italic;
	}
	
	.tx-sdb-maker .groups_divs > P { padding:0; ; text-indent:-20px ; margin:0 0 0 -20px ; font-size:95%; }
	
	.tx-sdb-maker .nowrap { white-space:nowrap; }
	
	.tx-sdb-maker .delete INPUT[type="submit"] { 
        text-align:left;
        padding:0;
        margin:0;
        border:0;
        white-space:nowrap; 
        background-color: transparent;cursor: 
        pointer;font-size: 100%; 
	}

	.tx-sdb-maker P.pages_contents { margin: 3px 0 8px 20px; }
	
	.tx-sdb-maker TABLE.pages_contents { margin: 3px 0 8px 0; }
	.tx-sdb-maker TABLE.pages_contents TH { font-weight:normal;font-style:italic;white-space:nowrap; }

	table.plugin-config TR TD { padding-right:5px; }

	/* field description no wrap */
	table.plugin-config TR TD:nth-child(3) { white-space:nowrap; overflow:visible; }
	/* move up- down arrows */
	table.plugin-config tbody TR:first-child TD:first-child span { display:none; }
	table.plugin-config TR:last-child TD:nth-child(2) span { display:none; }
	/* single checkbox centered */
	table.plugin-config TR TD:nth-last-child(2) { text-align:center; }
	/* checkbox and text bottom-aligned */
	table.plugin-config TR TD:last-child { padding-right:0;  }
	table.plugin-config TR TD:last-child INPUT[type="checkbox"] { vertical-align:baseline;margin:3px 3px 0 0; padding:0; }
	
	table.plugin-config thead TR TH { font-weight:normal;font-style:italic; }
    
    .mainFilters {
        margin-bottom:3px;
    }
    
    table.zebra tr:nth-child(odd) {
        background:#c0c0c0;
    }
    table.zebra tr:nth-child(even) {
        background:#eaeaea;
    }
    table.zebra thead th {
        background:#fff;
    }
    
    .preViewSingleRecord { border:1px solid #333; }
    .preViewSingleRecord table TH {
         width:10px;
         white-space:nowrap;
    }
    .vList label { display:block; }
    SELECT.obj-selector { width:auto;max-width:14em; }
    SELECT.filter-selector { width:auto;max-width:12em; }
    

	input.add_record[type=submit], 
	button.arrowdown[type=button], 
	button.arrowup[type=button], 
	button.arrowleft[type=button], 
	button.arrowright[type=button], 
	button.reload[type=button], 
	button.delete[type=button], 
	button.dupliz[type=button], 
	button.add_record[type=button], 
	button.save[type=button] {
		font-size:9pt;
		padding:0 3px 0 0;
	}
    span.objectInfos {
        display:block;
        position:relative;
        z-index:10;
        margin:1px;
        margin-left:-30px;
        overflow:visible;
        white-space:nowrap;
        background:white;
        padding:2px 3px;
        border:thin solid #ddd;
        border-color: #eaeaea #ddd #aaa #e0e0e0;
        border-radius:3px;
        box-shadow: 0 0 3px #555;
    }
    
    .mainFilters input[type=search] {
		border-right:1px solid #BBB;
		border-bottom:1px solid #999;
	}
	
	.preViewSingleRecord BUTTON.pgbt, .singlePager BUTTON.pgbt { width:60px; }

	.table-wrapper {
        position:relative;
        margin-top:30px;
    }
    .table-scroll {
        overflow:auto;  
    }
    .table-wrapper table thead th .text {
        position:absolute;   
        top:-20px;
        z-index:2;
        height:20px;
        background:#fff;
        overflow:hidden;  
    }
	
	.editListObjects .aEdit:before, .editListObjects .aAdd:before { padding:0 5px; }
	.editListObjects .aEdit { display:none; }
	
	.editListTable TR.new TD { color:black; font-weight:bold; cursor:pointer; }
	.editListTable TR.edited TD { color:green; font-weight:normal; cursor:pointer; }
	.editListTable TR.old TD { color:#000; text-decoration: line-through #D00;}

)
