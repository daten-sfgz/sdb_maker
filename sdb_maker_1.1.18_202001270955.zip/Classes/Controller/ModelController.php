<?php
namespace Sfgz\SdbMaker\Controller;
use \TYPO3\CMS\Core\Utility\GeneralUtility;
use \TYPO3\CMS\Backend\Utility\BackendUtility;

/***
 *
 * This file is part of the "SDB Maker" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2019 Daniel Rueegg <colormixture@sfgz.ch>
 *  
 ***/

/**
 * ModelController
 */
class ModelController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{

    /**
        * analyseUtility
        *
        * @var \Sfgz\SdbMaker\Utility\AnalyseUtility
        */
    protected $analyseUtility = null;

    /**
        * connXlsUtility
        *
        * @var \Sfgz\SdbMaker\Utility\ConnXlsUtility
        */
    protected $connXlsUtility = null;

    /**
        * preImportUtility
        *
        * @var \Sfgz\SdbMaker\Utility\PreImportUtility
        */
    protected $preImportUtility = null;

    /**
        * importUtility
        *
        * @var \Sfgz\SdbMaker\Utility\ImportUtility
        */
    protected $importUtility = null;

    /**
        * editorUtility
        *
        * @var \Sfgz\SdbMaker\Utility\EditorUtility
        */
    protected $editorUtility = null;

    /**
        * naviUtility
        *
        * @var \Sfgz\SdbMaker\Utility\NavigationUtility
        */
    protected $naviUtility = null;
    
    /**
    * naviConfig
    *
    * @var array
    */
    protected $naviConfig = NULL;
    
    /**
        * initializeAction
        *
        */
    public function initializeAction()
    {
			$this->settings['pluginUid'] = $this->configurationManager->getContentObject()->data['uid'];

            $this->analyseUtility = GeneralUtility::makeInstance('Sfgz\\SdbMaker\\Utility\\AnalyseUtility');
            
            $this->connXlsUtility = GeneralUtility::makeInstance('Sfgz\\SdbMaker\\Utility\\ConnXlsUtility');
            $this->connXlsUtility->appendToUploadPath( $this->settings['pluginUid'] ); 
            
            $this->preImportUtility = GeneralUtility::makeInstance('Sfgz\\SdbMaker\\Utility\\PreImportUtility');
            $this->preImportUtility->initiateSettings( $this->settings ); 
            
            $this->importUtility = GeneralUtility::makeInstance('Sfgz\\SdbMaker\\Utility\\ImportUtility');
            $this->importUtility->initiateSettings( $this->settings ); 
            
            $this->pluginsUtility = GeneralUtility::makeInstance('Sfgz\\SdbMaker\\Utility\\PluginsUtility');
            $this->pluginsUtility->initiateSettings( $this->settings['pluginUid'] );
            
            $editorUtility = GeneralUtility::makeInstance('Sfgz\\SdbMaker\\Utility\\EditorUtility');
            $result = $editorUtility->initiateSettings( $this->settings ); 
            if( $result ) $this->editorUtility = $editorUtility;
            if( !$result ) die( 'ModelContoller->init: editor  not started with db ' . $this->settings['dbname'] );
            $this->naviConfig = $this->initiateNavigation();
            if( $this->naviConfig['redirect'] ){
                $this->redirect( $this->naviConfig['callAction'] ,null,null,array('submit' => $this->naviConfig['request']));
            }
            
    }
    
    private function initiateNavigation()
    {
            $this->naviUtility = GeneralUtility::makeInstance('Sfgz\\SdbMaker\\Utility\\NavigationUtility');
                        
            if( $this->request->hasArgument('submit') ) {
                $aSubmit = $this->request->getArgument('submit');
            }
            
            $aAllowedActions = $this->naviUtility->getNavigation( $this->request->getControllerActionName() , $this->settings );
            $aAllowedActions['request'] = $aSubmit;
            
            return $aAllowedActions;
    }

    /**
        * action display
        *  in view display we load partials "Model/Datalist" mainList_preLoadLists and main_filters
        *  - the partial mainList_preLoadLists draws a js-script to load lists
        *  - at the end of partial main_filters we fill the select-objects 
        *  - and if allowed by filter we load and filter the table with initiateAjaxCall() via Ajax 
        *  - the ajax call action list returns html from view "Ajax/List" wich calls partial "Model/Datalist" main_list
        *  onLoad of this table we 
        *   - bind the js-script initiateDataRows() to onClick event of each row.
        *   - this event loads a form via Ajax on click. 
        *  - the ajax call preview returns html from view "Ajax/Preview" 
        *
        * @return void
        */
    public function displayAction()
    {  
            // get main-control inputs
            $this->view->assign( 'naviConf' , $this->naviConfig );
            $this->view->assign( 'request' , $this->naviConfig['submit'] );
            $arg['submit'] = $this->naviConfig['submit'];
            
            // get plugin-settings
            $uid =  $this->configurationManager->getContentObject()->data['uid'];
            $aBodytext = $this->pluginsUtility->getBodytextArray($uid);
            $aDbTables =$this->pluginsUtility->getDbFieldPropertiesOfMainTables( $this->settings['dbname'] );
            
            $piSettings = $this->editorUtility->mergePiSettings( $aBodytext , $aDbTables );
            $piSettings['uid'] = $uid;
            $piSettings['pluginUid'] = $uid;
            $piSettings['actualTable'] = $piSettings['tablesList'][0];
            $piSettings['main']['mainlist']['aSteps'] = explode( ',' , $piSettings['main']['mainlist']['steps'] );
            $piSettings['calledFromAction'] = 'preview';
             
            $this->view->assign( 'piSettings' , $piSettings );
    }

    /**
        * action base
        *  in view base we load partial maintable_selector, there 
        *  - either we choose to load partial "Model/Datalist" edit-lists
        *  or
        *  - we load partials "Model/Datalist" mainList_preLoadLists and main_filters
        *    - the partial mainList_preLoadLists draws a js-script to load lists
        *    - at the end of partial main_filters we fill the select-objects 
        *    - and if allowed by filter we load and filter the table with initiateAjaxCall() via Ajax 
        *    - the ajax call action list returns html from view "Ajax/List" wich calls partial "Model/Datalist" main_list
        *    onLoad of this table we 
        *     - bind the js-script initiateDataRows() to onClick event of each row.
        *     - this event loads data via Json on click. 
        *     - then we fill the select-fields with fillOptionsLists()
        *
        * @return void
        */
    public function baseAction()
    {
            // get main-control inputs
            if( $this->request->hasArgument('submit') ) {
                $arg['submit'] = $this->request->getArgument('submit');
            }
            
            if( !isset($arg) || !isset($arg['submit']['table_choise']) || empty($arg['submit']['table_choise']) ) {
                $arg['submit']['table_choise'] = 0;
            }
            
            $this->view->assign( 'naviConf' , $this->naviConfig );
            $this->view->assign( 'request' , $arg['submit'] );

            $uid =  $this->configurationManager->getContentObject()->data['uid'];
            $aBodytext = $this->pluginsUtility->getBodytextArray($uid);
            $aDbTables =$this->pluginsUtility->getDbFieldPropertiesOfMainTables( $this->settings['dbname'] );
            
            $piSettings = $this->editorUtility->mergePiSettings( $aBodytext , $aDbTables );
            $piSettings['uid'] = $uid;
            $piSettings['pluginUid'] = $uid;
            $piSettings['actualTable'] = $piSettings['tablesList'][$arg['submit']['table_choise']];
            $piSettings['main']['mainlist']['aSteps'] = explode( ',' , $piSettings['main']['mainlist']['steps'] );
            $piSettings['calledFromAction'] = 'edit';

            $this->view->assign( 'piSettings' , $piSettings );
            
            // Here we load data for 1:n and 1:m tables
            // data for main-table gets loaded later by Json call. 
            if( $piSettings['actualTable']['type'] != 'Haupttabelle' ) {
                $data = $this->editorUtility->getDataFromChoosenTable( $piSettings['actualTable']['tablename'] );
                $this->view->assign( 'data' , $data );
            }

    }

    /**
        * action settings
        *  plugin configuration
        *
        * @return void
        */
    public function settingsAction()
    {  
            // get main-control inputs
            if( $this->request->hasArgument('submit') ) {
                $arg['submit'] = $this->request->getArgument('submit');
            }
            $iTableNbr = $arg['submit']['table_choise'];
            
            $this->view->assign( 'request' , $arg['submit'] );
            $this->view->assign( 'naviConf' , $this->naviConfig );
            unset($arg['submit']['table_choise']);
            
            // create list with main-tables to choose from in fe
            $tablesList = [];
            $aDbTables =$this->pluginsUtility->getDbFieldPropertiesOfMainTables( $this->settings['dbname'] );
            if( isset($aDbTables['tables']) ){
                ksort($aDbTables['tables']);
                foreach( $aDbTables['tables'] as $tablename => $tabDef ){
                    if( $tabDef['TABLE_TYPE'] == 'main' || $tabDef['TABLE_TYPE'] == 'loose') $tablesList[ count($tablesList)+1 ] = $tablename;
                }
            }
            
            // BREAK IF
            if( !count($tablesList) ){
                // no main-tables found in database!
                return;
            }
            
            // READ bodytext get table choise + settings ; 
            // set new table choise if affored, store bodytext. 
            $uid = $this->configurationManager->getContentObject()->data['uid'];
            $aBodytext = $this->pluginsUtility->getBodytextArray($uid);
            if( 
                $this->request->hasArgument('changeTableButton') && 
                $iTableNbr && 
                isset($tablesList[ $iTableNbr ]) 
            ){
                $this->view->assign( 'request' , $arg['submit'] );
                $aBodytext['table_choise'] = $tablesList[ $iTableNbr ];
                $this->pluginsUtility->setBodytextArray( $aBodytext , $uid );
                $this->addFlashMessage( 'Optionen für "' . $aBodytext['table_choise'] . '" geladen' , 'Tabelle geändert' , \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
            }else{
                $iTableNbr = array_search( $aBodytext['table_choise'] , $tablesList );
            }
            
            // BREAK IF
            if( !isset($tablesList[ $iTableNbr ]) ){
                // if no table is choosen then break script and return
                $this->view->assign( 'aDbTables' , [ 'tablesList'=> $tablesList  , 'dbname'=> $this->settings['dbname'] ] );
                return;
            }
            
            // table is choosen and stored
            // get defaults, overwride with stored settings, overwride with input settings and store.
            
            // STORE bodytext: overwrite with changed settings from input. Empty on first run!
            if( $this->request->hasArgument('changeSettingsButton') ){
                $incomed = [ 'fields' , 'filter' , 'main' ];
                foreach( $incomed as $category ){
                    if( $this->request->hasArgument($category) ) {
                        // clear the stored array to prevent ghost-fields
                        $aBodytext[ $aBodytext['table_choise'] ][$category] = [];
                        foreach($this->request->getArgument($category) as $fieldname => $fldDef ){
                            foreach( $fldDef as $attribute => $value ){
                                $aBodytext[ $aBodytext['table_choise'] ][$category][$fieldname][$attribute] = $value;
                            }
                        }
                    }
                }
                $this->pluginsUtility->setBodytextArray( $aBodytext , $uid );
                $this->addFlashMessage( 'Attribute gespeichert!' , 'Gespeichert' , \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
            }

            // get default rendertypes and labeltext for each field
            $aTableFields = $this->pluginsUtility->getRenderTypes( $aDbTables['tables'][ $tablesList[ $iTableNbr ] ] , $this->settings );
            // add table name
            $aTableFields['table_choise'] = $iTableNbr;
            // default for title in FE-Site
            $aTableFields['main']['title']['text'] = $tablesList[ $iTableNbr ];
            $aTableFields['main']['mainlist']['pager'] = 1;
            $aTableFields['main']['mainlist']['steps'] = '5,10,15,20,25,30,50,80,100';
            
            // rebuild aTableFields['fld'] in right sort order, therefore create the a array $aFldDefs:
            $aFldDefs = $aTableFields['fld'];
            unset($aTableFields['fld']);
           
            if( $this->request->hasArgument('resetSettingsButton') ){
                // reset
                $okText = 'Standardwerte eingesetzt. Bitte speichern oder abbrechen!';
                $this->view->assign( 'resetSettingsButton' , $okText );
                $this->addFlashMessage( $okText , 'Auf "Speichern" klicken!' , \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
                
            }else{
                if( isset($aBodytext[ $aBodytext['table_choise'] ]['fields']) ){
                    // append fld settings from bodytex to CONFIG in a additional array-dimension
                    foreach($aBodytext[ $aBodytext['table_choise'] ]['fields'] as $fieldname => $fdlDef ){ // store field-specific  data
                        // dont assume needless old fields
                        if( !isset($aFldDefs[$fieldname]) ) continue;
                        // overwrite defaults from DB table-definition
                        foreach( $fdlDef as $attribute => $value ){
                            $aFldDefs[$fieldname]['CONFIG'][$attribute] = $value;
                        }
                    }
                }
                // replace the default main AND filter settings with those from bodytex
                $aCat = [ 'main' , 'filter' ];
                foreach( $aCat as $category ) {
                    if( isset( $aBodytext[ $aBodytext['table_choise'] ][$category] ) ){
                        foreach($aBodytext[ $aBodytext['table_choise'] ][$category] as $fieldname => $fldDef ){
                                $aTableFields[$category][$fieldname] = $fldDef;
                        }
                    }
                }
            }
            
            // resort: rebuild the array fld in a new sort order
            // because 'position' was not in defaults but it has to appear in root of fieldDef[position] aswell as in CONFIG-part fieldDef[CONFIG][position]
            $aSort = [];
            if( is_array($aFldDefs) ){
                foreach( $aFldDefs as $fieldname => $fldDef ){
                        $aSort[ $fieldname ] = $fldDef['CONFIG']['position'];
                }
                // sort fieldnames by position
                asort($aSort);
                // reset the array fld in new sort order, append the attribute 'position' to the array
                foreach( $aSort as $fieldname => $pos ){
                    $aTableFields['fld'][$fieldname] = $aFldDefs[$fieldname];
                    $aTableFields['fld'][$fieldname]['CONFIG']['position'] = $pos;
                }
            }

            $this->view->assign( 'aDbTables' , [ 'tablesList'=> $tablesList , 'tablesFields'=> $aTableFields  , 'dbname'=> $this->settings['dbname'] ] );
            
            
    }

    /**
        * action database
        *  plugin configuration
        *
        * @return void
        */
    public function databaseAction()
    {  
            if( $this->request->hasArgument('submit') )  $arg['submit'] = $this->request->getArgument('submit');
            $this->view->assign( 'naviConf' , $this->naviConfig );
            
            $aDbTables =$this->pluginsUtility->getDbFieldPropertiesOfMainTables( $this->settings['dbname'] );

            if( isset($arg['submit']['delete']) ) {
                unset($arg['submit']['delete']);
                if( $this->request->hasArgument('delete') ) {
                    $aDeletable = $this->request->getArgument('delete');
                    $deleteResult = 0;
                    $aDeletionText = [];
                    if( is_array($aDeletable['view']) ){
                        foreach($aDeletable['view'] as $delViewName => $valid ){
                            if($valid){
                                $deleteResult = $this->importUtility->deleteTable( $this->settings['dbname'] , $delViewName );
                                $aDeletionText[] = 'View ' . $delViewName . ':' .  ( $deleteResult ? 'gelöscht' : 'nicht gelöscht' );
                                if( isset($aDbTables['views'][$delViewName]) ) unset($aDbTables['views'][$delViewName]);
                            }
                        }
                    }
                    if( is_array($aDeletable['table']) ){
                        foreach($aDeletable['table'] as $mainTableName => $valid ){
                            if( $valid && isset($aDbTables['tables'][$mainTableName]) ){
                                $tabDef =  $aDbTables['tables'][$mainTableName];
                                if( is_array($tabDef['REFERENCED_BY']) ){
                                    foreach($tabDef['REFERENCED_BY'] as $relTabFieldname => $refTabDef ){
                                        if( !isset($refTabDef['NM_TABLE']) ) continue;
                                        $deleteResult = $this->importUtility->deleteTable( $this->settings['dbname'] , $refTabDef['NM_TABLE'] );
                                        $aDeletionText[] = 'm:n Tabelle ' . $refTabDef['NM_TABLE'] . ':' . ( $deleteResult ? 'gelöscht' : 'nicht gelöscht' );
                                        if( isset($aDbTables['tables'][$refTabDef['NM_TABLE']]) && $deleteResult ) unset($aDbTables['tables'][$refTabDef['NM_TABLE']]);
                                       
                                       if( !isset($refTabDef['REF_TABLE']) ) continue;
                                        $deleteResult = $this->importUtility->deleteTable( $this->settings['dbname'] , $refTabDef['REF_TABLE'] );
                                        $aDeletionText[] = '1:m Tabelle ' . $refTabDef['REF_TABLE'] . ':' . ( $deleteResult ? 'gelöscht' : 'nicht gelöscht' );
                                        if( isset($aDbTables['tables'][$refTabDef['REF_TABLE']]) && $deleteResult ) unset($aDbTables['tables'][$refTabDef['REF_TABLE']]);
                                    }
                                }
                                
                                $deleteResult = $this->importUtility->deleteTable( $this->settings['dbname'] , $mainTableName );
                                $aDeletionText[] = 'Haupt-Tabelle ' . $mainTableName . ':' . ( $deleteResult ? 'gelöscht' : 'nicht gelöscht' );
                                if( isset($aDbTables['tables'][$mainTableName]) && $deleteResult ) unset($aDbTables['tables'][$mainTableName]);
                                
                                if( is_array($tabDef['REFERENCES']) ){
                                    foreach($tabDef['REFERENCES'] as $relTabFieldname => $tableToDelete ){
                                        $deleteResult = $this->importUtility->deleteTable( $this->settings['dbname'] , $tableToDelete );
                                        $aDeletionText[] = '1:n Tabelle ' . $tableToDelete . ':' . ( $deleteResult ? 'gelöscht' : 'nicht gelöscht' );
                                        if( isset($aDbTables['tables'][$tableToDelete]) && $deleteResult ) unset($aDbTables['tables'][$tableToDelete]);
                                    }
                                }
                            }
                        }
                    }
                    $strDeletionText = 'Löschergebnis: ' . ( !count($aDeletionText) ? ' (leer)' : implode( ', ' , $aDeletionText ) . '.' );
                    $this->addFlashMessage( $strDeletionText , count($aDeletionText) ? 'Gelöscht' : 'Keine Aktion' , \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
                }
            }elseif( isset( $arg['submit']['download'] ) ) {
                $subType = $arg['submit']['type'];
                $tabNam = $arg['submit']['download'];
                if( isset($aDbTables[$subType][$tabNam]) ){
                    switch( $subType ){
                        case 'tables':
                            // we want mn tables near by the realtaed 1n tables
                            $aSrt = [];
                            // fill first the array aSrt with an additional 4. dimension.
                            $aTableRecords=[];
                            foreach( $aDbTables[$subType] as $tablename => $tabDef ){
                                // list only the selected main-table and sub-tables that belong to the selected main-table
                                if( $tablename != $tabNam && $tabDef['REFERING_TABLE'] != $tabNam  ) continue;
                                $aSrt[$tablename][$tablename] = $this->editorUtility->sqlUtility->runQuery( 'SELECT * FROM ' . $tablename . ' LIMIT 20000;' );
                                // seek for mn-tables
                                if( !is_array($tabDef['REFERENCED_BY']) ) continue;
                                foreach($tabDef['REFERENCED_BY'] as $relTabFieldname => $refTabDef ){
                                    if( !isset($refTabDef['NM_TABLE']) ) continue;
                                    $aSrt[$refTabDef['REF_TABLE']][$refTabDef['NM_TABLE']] = $this->editorUtility->sqlUtility->runQuery( 'SELECT * FROM ' . $refTabDef['NM_TABLE'] . ' LIMIT 20000;' );
                                }
                            }
                            // flatenate the aSort and build the final array $aTableRecords with 3 dimensions
                            foreach( $aSrt as $sortRows ){
                                foreach( $sortRows as $tablename => $tabrows) $aTableRecords[$tablename] = $tabrows;
                            }
                            $this->connXlsUtility->exportTables( $aTableRecords , $tabNam . '.xlsx' );
                        break;
                        case 'views':
                            $query = $aDbTables[$subType][$tabNam]['viewdef'] . ' LIMIT 20000;';
                            $aTableRecords = $this->editorUtility->sqlUtility->runQuery( $query );
                            $this->connXlsUtility->exportTables( $aTableRecords , $tabNam . '.xlsx' );
                        break;
                    }
                }
            }
            
            // resort tables
            if( isset($aDbTables['tables']) ){
                $aSrtTab = [];
                foreach($aDbTables['tables'] as $tabnam => $tabDef){
                    $sortIndex = isset($tabDef['REFERING_TABLE']) ? $tabDef['REFERING_TABLE'] : $tabnam;
                    $aSrtTab[$sortIndex][$tabnam] = $tabDef;
                }
                if( count($aSrtTab) ){
                    ksort($aSrtTab);
                    unset($aDbTables['tables']);
                    foreach($aSrtTab as $subTabDef){
                        foreach($subTabDef as $tabnam => $tabDef){
                            $aDbTables['tables'][$tabnam] = $tabDef;
                        }
                    }
                }
            }
            $this->view->assign( 'request' , $arg['submit'] );
            
            $this->view->assign( 'aDbTables' , [ 'dbname'=> $this->settings['dbname'] , 'fieldDefinition'=>$aDbTables  , 'deletionText'=>$strDeletionText ] );
            
    }

    /**
        * action analyse
        *   detect total records, total fields
        *   each field: max-field-length, amount of empty values, amount of different values without empty (groups) , max in group (biggest group)
        *
        * @return void
        */
    public function analyseAction()
    {
            $arg = [];
            if( $this->request->hasArgument('submit') )  $arg['submit'] = $this->request->getArgument('submit');
            if( $this->request->hasArgument('group') )   $arg['submit']['group'] = $this->request->getArgument('group');
            if( $this->request->hasArgument('separer') ) $arg['submit']['separer'] = $this->request->getArgument('separer');
            if( $this->request->hasArgument('nullable') ) $arg['submit']['nullable'] = $this->request->getArgument('nullable');

            $buttonAction = ( isset( $arg['submit']['gruppieren'] ) )  ? $arg['submit']['gruppieren'] : $arg['submit']['umbrechen'];
            
            $arg['submit'] = $this->connXlsUtility->dispatchJobs($arg['submit']); //  submit[ delete | upload | download | selected ] = filename;

            $this->view->assign( 'naviConf' , $this->naviConfig );
            $this->view->assign( 'file_list' , $this->connXlsUtility->fileNames );
            $this->view->assign( 'request' , $arg['submit'] );

            // abort if no file is selected
            if( empty( $arg['submit']['selected'] ) ) return;
            
            $aTableRecords = $this->connXlsUtility->readData();
            
            // download a 'original' file from files-list
            if( $aTableRecords && isset( $arg['submit']['download'] ) ) $this->connXlsUtility->exportTables( $aTableRecords , $arg['submit']['selected'] . '.xlsx' );

            // abort if no records found in file
            if( !count( $aTableRecords ) ) return;

            // if no button was pressed then display original sheets in selected files
            $aTables = [];
            if( !is_array($buttonAction) ){
                    $aTables = $this->analyseUtility->displaySelectedFile($aTableRecords);
            }else{
            // if button umbrechen or gruppieren was pressed then display original AND converted sheet
                    $sheetname = array_shift( array_keys($buttonAction) );
                    if( !isset( $arg['submit']['group'][$sheetname][0]['tablename'] ) ) $arg['submit']['group'][$sheetname][0]['tablename'] = $sheetname;
                    if( isset($aTableRecords[$sheetname]) ) {
                            $aSeparer = is_array($arg['submit']['separer'][$sheetname]) ? $arg['submit']['separer'][$sheetname] : [];
                            $aTables[$sheetname] = $this->analyseUtility->displayConvertedSheet( $aTableRecords[$sheetname] , $aSeparer  );
                    }
            }

        
            $this->view->assign( 'alltable2analyze' , $aTables );
            
            // if button gruppieren was pressed then redirect
            if( isset( $arg['submit']['gruppieren'] ) ) $this->redirect('preflight',null,null,array('submit' => $arg['submit']));
    }

    /**
        * action preflight
        *
        * @return void
        */
    public function preflightAction()
    {
            
            if( $this->request->hasArgument('submit') )  {
                
                $arg['submit'] = $this->request->getArgument('submit');
             
                // go back, keep tablename in key of variable umbrechen
                if( isset( $arg['submit']['back'] ) )  {
                    $arg['submit']['umbrechen'] = $arg['submit']['back'];
                    // prevent infinite loop due to variable 'gruppieren' is set
                    if( isset( $arg['submit']['gruppieren'] ) ) unset($arg['submit']['gruppieren']);
                    // do not forward but redirect to run again the initializeAction
                    $this->redirect( 'analyse' , null , null , [ 'submit'=>$arg['submit']  , 'separer'=>$arg['submit']['separer']  , 'group'=>$arg['submit']['group'] , 'nullable'=>$arg['submit']['nullable']  ]  );
                
                }elseif( isset( $arg['submit']['zusynchronisieren'] ) ){
                    $arg['submit']['synchronisieren'] = $arg['submit']['zusynchronisieren'];
                    unset($arg['submit']['umbrechen']);
                    unset($arg['submit']['zusynchronisieren']);
                    $this->redirect( 'syncronize' , null , null , [ 'submit'=>$arg['submit']  , 'separer'=>$arg['submit']['separer']  , 'group'=>$arg['submit']['group']  ]  );
                }else{
                    $arg['submit'] = $this->connXlsUtility->dispatchJobs($arg['submit']);
                }
            }

           
            if( $this->request->hasArgument('dbaction') )  {
                $dbaction = $this->request->getArgument('dbaction');
                if( isset($dbaction['delete']) && is_array($dbaction['delete']) ) {
                    $deltable = array_shift( array_keys( $dbaction['delete'] ));
                    if( $deltable ) {
                        $deleteResult = $this->importUtility->deleteTable( $this->settings['dbname'] , $deltable );
                        if( $deleteResult == 1 ){
                            $this->addFlashMessage( $deltable . ' gelöscht.' , '' , \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
                        }else{
                            $this->addFlashMessage( $deltable . ' kann aufgrund mn-Beziehung(en) nicht gelöscht werden.' , '' , \TYPO3\CMS\Core\Messaging\AbstractMessage::INFO);
                        }
                    }
                    
                }elseif( isset($dbaction['create']) && is_array($dbaction['create']) ){
                    $arg['dbaction']['create'] = array_shift( array_keys( $dbaction['create'] ));
                    $arg['dbaction']['sqlText'] = $dbaction['sqlText'];
                    
                }
                
            }
            
            $this->view->assign( 'naviConf' , $this->naviConfig );
            $this->view->assign( 'request' , $arg['submit'] );
            
            $this->view->assign( 'blattname' , array_shift( array_keys($arg['submit']['group']) ) );
            
            // detect if tables could be created
            $inTabNam = array_shift( array_keys($arg['submit']['group']) );
            $mainTableName = $arg['submit']['group'][$inTabNam][0]['tablename'] ? $arg['submit']['group'][$inTabNam][0]['tablename'] : $inTabNam;
            $aSeparer = is_array($arg['submit']['separer'][$inTabNam]) ? $arg['submit']['separer'][$inTabNam] : [];
            $aAllTabRec = $this->connXlsUtility->readData();
            $aTable = $this->analyseUtility->displayConvertedSheet( $aAllTabRec[$inTabNam] , $aSeparer  );
            $aTableDefinitions = isset($aTable['outTable']['feldDefinitionen']) ? $aTable['outTable']['feldDefinitionen'] : [];
            
            $stateId =  $this->preImportUtility->detectConflicts( $aTableDefinitions , $arg['submit']['group'][$inTabNam] , $arg['submit']['nullable'][$inTabNam] , $mainTableName );
			$statusMessage  = '';
            $sStatusMsg = $this->preImportUtility->info;
            $aStateMsg = [];
			
			// if there is incomed  sql-text and button create is clicked then create tables
            $aSqlText = $this->importUtility->getSqlToCreateTables( $this->settings['dbname'] , $this->preImportUtility->workDB['usedTablenames'] );
            if( $arg['dbaction']['create'] && count($aSqlText) ) {
                $connected = $this->importUtility->readStart( $this->settings['dbname'] );
                if( $connected != 1 ) {
                    $this->addFlashMessage( $connected , 'Datenbank Verbindung' , \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
                }else{
                    foreach( $aSqlText as $i => $sqlText ) {
                        $aSqlText[$i] = ( isset($arg['dbaction']['sqlText'][$i]) && $arg['dbaction']['sqlText'][$i] ) ? $arg['dbaction']['sqlText'][$i] : $sqlText;
                        $result = $this->importUtility->execMultipleQueries( $this->settings['dbname'] , $aSqlText[$i] );
                        if( !$result ) {
                            $aStateMsg[] = '<span class="error">' . $i . ':' . 'FEHLER, abgebrochen</span>';
                            break;
                        }else{
                            $aStateMsg[] =  $i . ': <span class="ok">ok</span>';
                        }
                    }
                    $viewDef = $this->preImportUtility->collectDataForMainView( $this->preImportUtility->workDB['usedTablenames'] );
                    $bResult = $this->importUtility->createView( 'a' . $viewDef['maintable'] , $viewDef['maintable'] , $viewDef['unique'] , $viewDef['fields'] );
                    $this->importUtility->readEnd();
                }
                $flshMsg = (count($aSqlText) == 1 ? 'Die Tabelle wurde ' : count($aSqlText) . ' Tabellen wurden ');
                $flshMsg .=  $result ?  'erstellt.' : 'nicht erstellt.';
                
                $sStatusMsg = '<h4>Erstellt!</h4>' . $flshMsg . ' ';
                $stateId =  $this->preImportUtility->detectConflicts( $aTableDefinitions , $arg['submit']['group'][$inTabNam] , $arg['submit']['nullable'][$inTabNam] , $mainTableName ) ;
                $statusMessage  = trim($this->preImportUtility->info) ;
                
                $this->addFlashMessage( $flshMsg , 'Erstellt!' , \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
            }
            // assign sql text if tables could be created
            $this->view->assign( 'aSqlText' , $aSqlText );
            
            $this->view->assign( 'alltable2analyze' , $this->preImportUtility->workDB );
            $this->view->assign( 'deltable_result' , $arg['dbaction']['deltable_result']);
            $this->view->assign( 'dbTables' , $this->preImportUtility->workDB['database'] );

            $sStatusMsg = $sStatusMsg . implode( ', ' , $aStateMsg ) . ' ' . $statusMessage;
            $this->view->assign( 'database' , ['name'=>$this->settings['dbname'] , 'status'=> $sStatusMsg , 'statusNr'=> $stateId ] );

            $viewDef = $this->preImportUtility->collectDataForMainView( $this->preImportUtility->workDB['usedTablenames'] );
            $this->view->assign( 'viewDef' , $viewDef );
            $this->view->assign( 'aTable' , $aTable );

    }

    /**
        * action syncronize
        *
        * @return void
        */
    public function syncronizeAction()
    {
            $aTableRecords = [];
            $aFieldSeparers = [];
            $aRelatedTableData = [];
            $mainTableName = '';
            $stateId = 0;
            
            if( $this->request->hasArgument('submit') )  {
                $arg['submit'] = $this->request->getArgument('submit');
                
                $inTabNam = isset($arg['submit']['synchronisieren']) ? array_shift( array_keys($arg['submit']['synchronisieren']) ) : ( isset($arg['submit']['gruppieren']) ? array_shift( array_keys($arg['submit']['gruppieren']) ) : '');
                
                $aSeparer = is_array($arg['submit']['separer'][$inTabNam]) ? $arg['submit']['separer'][$inTabNam] : [];
                
                $mainTableName = $arg['submit']['group'][$inTabNam][0]['tablename'] ? $arg['submit']['group'][$inTabNam][0]['tablename'] : $inTabNam;
                
                $arg['submit'] = $this->connXlsUtility->dispatchJobs($arg['submit']);
                
                $aSheetsGroupOptions = $arg['submit']['group'][$inTabNam];
                
                $aAllTabRec = $this->connXlsUtility->readData( 'iso-8859-15' );
                $aTableRecords = $aAllTabRec[$inTabNam];
                
                $aTable = $this->analyseUtility->displayConvertedSheet( $aTableRecords , $aSeparer  );
                if( isset( $aTable['outTable']['feldDefinitionen'] ) ) {
                    // test if import can be done and refuse if not
                    $stateId = $this->preImportUtility->detectConflicts( $aTable['outTable']['feldDefinitionen'] , $arg['submit']['group'][$inTabNam] , $arg['submit']['nullable'][$inTabNam] , $mainTableName );
                    // get values for sibling tables
                    $aRelatedTableData = $this->analyseUtility->getValuesForParentTables( $aTable['outTable']['feldDefinitionen'] );
                }
            }
            
            // something went wrong
            if( $stateId != 12 || !count($aRelatedTableData) )  {
                $arg['submit']['umbrechen'] = $arg['submit']['back'];
                 // prevent infinite loop due to variable 'synchronisieren' or 'gruppieren' is set
                if( isset( $arg['submit']['synchronisieren'] ) ) unset($arg['submit']['synchronisieren']);
                if( isset( $arg['submit']['gruppieren'] ) ) unset($arg['submit']['gruppieren']);
                
                $err = [];
                if( !isset($mainTableName) || empty($mainTableName) ) $err[] = 'Tabellenname fehlt';
                if( $stateId != 12 ) $err[] = 'Tabelle nicht synchronisierbar';
                if( !count($aRelatedTableData) ) $err[] = 'Keine Daten in der Datei';
                if( !count($err) ) $err[] = 'Unbekannter Fehler';
                
                $this->addFlashMessage( 'Zurück geleitet, Problem: ' . implode( ', ' , $err ) . '.' , 'Umgeleitet!' , \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
                $this->forward( 'preflight' , null , null , [ 'submit'=>$arg['submit']  , 'separer'=>$arg['submit']['separer']  , 'group'=>$arg['submit']['group']  ]  );
            }
            
                    
            $connected = $this->importUtility->readStart( $this->settings['dbname'] );
            if( $connected && isset($aTableRecords) ) {
                // import into 1:n (parent) or 1:m (sibling) table
                $aRelationalTablesIndex = $this->importUtility->importIntoParentTables( $this->preImportUtility->workDB['usedTablenames'] , $aRelatedTableData );
                $aFieldRecord = $this->importUtility->collectDataForMainTableImport( $aTableRecords , $aRelationalTablesIndex , $this->preImportUtility->workDB['usedTablenames'] );
                $aResultDB = $this->importUtility->importIntoMainTable( $aFieldRecord , $this->preImportUtility->workDB['usedTablenames'] );
                $this->addFlashMessage( 'Es wurden ' . count($aTableRecords) . ' Zeilen synchronisiert.' , 'Daten importiert' , \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
                // if view where deleted manually, create it again
                $viewDef = $this->preImportUtility->collectDataForMainView( $this->preImportUtility->workDB['usedTablenames'] );
                $sqlStat = $this->importUtility->createView( 'a' . $viewDef['maintable'] , $viewDef['maintable'] , $viewDef['unique'] , $viewDef['fields'] );
            }
            $this->importUtility->readEnd();
            
            $usedData = [ 'aResultDB' => $aResultDB , 'aRelationalTablesIndex' => $aRelationalTablesIndex , 'usedTablenames' => $this->preImportUtility->workDB['usedTablenames'] ];
            $this->view->assign( 'alltable2analyze' , $usedData );

            $this->view->assign( 'naviConf' , $this->naviConfig );
            $this->view->assign( 'request' , $arg['submit'] );
            
            $this->view->assign( 'blattname' , array_shift( array_keys($arg['submit']['group']) ) );

    }
    
} 
