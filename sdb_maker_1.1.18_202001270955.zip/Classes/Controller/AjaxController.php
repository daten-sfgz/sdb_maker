<?php
namespace Sfgz\SdbMaker\Controller;
use \TYPO3\CMS\Core\Utility\GeneralUtility;
use \TYPO3\CMS\Core\Database\ConnectionPool;

/***
 *
 * This file is part of the "SDB Maker" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2019 Daniel Rueegg <colormixture@sfgz.ch>
 *  
 ***/

/**
 * AjaxController
 */
class AjaxController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{

    /**
        * pluginsUtility
        *
        * @var \Sfgz\SdbMaker\Utility\PluginsUtility
        */
    protected $pluginsUtility = null;

    /**
        * editorUtility
        *
        * @var \Sfgz\SdbMaker\Utility\EditorUtility
        */
    protected $editorUtility = null;

    /**
        * imagePath
        *
        * @var string
        */
    protected $imagePath = null;

    /**
    * pluginUid
    * 
    * @var int
    */
    protected $pluginUid = Null;
    
    /**
        * initializeAction
        *
        */
    public function initializeAction()
    {
            $this->pluginsUtility = GeneralUtility::makeInstance('Sfgz\\SdbMaker\\Utility\\PluginsUtility');
            $this->editorUtility = GeneralUtility::makeInstance('Sfgz\\SdbMaker\\Utility\\EditorUtility');

            // get main-control inputs
            if( $this->request->hasArgument('pluginUid') ) {
                $this->setPiSettings( $this->request->getArgument('pluginUid') );
            }
            
            $this->imagePath = $GLOBALS['TSFE']->tmpl->setup['config.']['baseURL'] . 'typo3conf/ext/sfgz_fetools/Resources/Public/Img/tablesorter_pager' ;
    }

    /**
        * action list
        *
        * @return void
        */
    public function listAction()
    {  
            // get filter inputs
            $arg['filter'] =  GeneralUtility::_POST('filter');
            
            $piSettings = $this->piSettings;
            $piSettings['main']['mainlist']['aSteps'] = explode( ',' , $piSettings['main']['mainlist']['steps'] );
            $piSettings['imagepath'] = $this->imagePath; 
            
            if( empty($piSettings['actualTable']['tablename']) ) return;
            
            // get configuration from incoming filter-array and delete the variable
            if( is_array($arg['filter']) && isset($arg['filter']['calledFromAction']) ) {
                // the 'calledFromAction' defines what happens on click
                $piSettings['calledFromAction'] = $arg['filter']['calledFromAction'];
                // remove this from filter
                unset( $arg['filter']['calledFromAction'] );
            }
            
            // create WHERE clause
            $aHavingClause = $this->prepareWhereArgumentsForMainTable( $arg['filter'] , $piSettings );
            // get data for listing
            $data = $this->editorUtility->getFilteredDataFromMainTables( $piSettings['actualTable']['tablename'] , $piSettings['actualTable']['key'] , $piSettings['fields'] , $aHavingClause );
            
            // length of label: evaluate the longest Text
            if( count($data) ){
                foreach( $data as $row) {
                    foreach( $row as $field => $content) {
                        if( !isset($piSettings['fields'][$field]['croplabel']) || $piSettings['fields'][$field]['croplabel'] < strlen($content) ) $piSettings['fields'][$field]['croplabel'] = strlen($content); 
                    }
                }
            }

            $this->view->assign( 'data' , $data );
            $this->view->assign( 'piSettings' , $piSettings );
            
    }

    /**
        * prepareWhereArgumentsForMainTable
        *
        * @param array $aFilter
        * @param array $piSettings
        * @return array
        */
    public function prepareWhereArgumentsForMainTable( $aFilter , $piSettings )
    {
            // every value from 'filter' goes to search statement
            $aHavingClause = [];
            if( !is_array($aFilter) ) return $aHavingClause;
            
            foreach( $aFilter as $fIdx => $searchvalue ){
                if( empty($searchvalue) ) continue;
                $aIdx = explode( '_' , $fIdx );
                
                if( $aIdx[0] == 'selectFilter' ){
                    $fieldname = $aIdx[2];
                    if( isset($piSettings['fields'][$fieldname]) ){
                        if( isset($piSettings['fields'][$fieldname]['REFERENCE_TO']) ){ 
                            // int AND-search on main-table:
                            // get Uid from main-table where maintable.filterField = filterFieldUid (field with foreign-index)
                            //$fieldname = $piSettings['fields'][$fieldname]['REFERENCE_TO']['REF_INDEX'];
                            $aHavingClause['index'][$fieldname] = $searchvalue;
                        }elseif( isset($piSettings['fields'][$fieldname]['REFERENCED_BY']) ){
                            // int AND-search on nm-table: ['REFERENCED_BY']['NM_TABLE']
                            // get keyParent from nm-table[ filterField ] where keyForeign = filterFieldUid
                            //$fieldname = $piSettings['fields'][$fieldname]['REFERENCED_BY']['REF_INDEX'];
                            $aHavingClause['index'][$fieldname] = $searchvalue;
                        }else{
                            // boolean yes/no field (edit as checkbox or radio or select)
                            $aHavingClause['boolean'][$fieldname] = $searchvalue;
                        }
                    }
                    
                }elseif( $aIdx[0] == 'textFilter' ){
                    // this is a text OR-search on 1n-table.textfield OR, maintable.textfield OR, 1m-table.textfield where text-chunks are in textfields.
                    //  Separe Chuncks from searchText by separing sentences with '+'.
                    //  Chunks are handled as OR clauses. Case insensitive-search, but whitespaces in a search-chunk must exist in fulltext to match. 
                    if( isset($piSettings['aFilterSearchTextFields']) ){
                        $aValueAtoms = explode( '+' , $searchvalue );
                        foreach( $piSettings['aFilterSearchTextFields'] as $fld ) {
                            foreach( $aValueAtoms as $word ){
                                if( !strlen(trim($word)) ) continue;
                                $aHavingClause['text'][$fld][] = $word;
                            }
                        }
                    }
                }
                
            }
            
            return $aHavingClause;
    }

    /**
        * action preview
        *
        * @return void
        */
    public function previewAction()
    {  
            $arg['filter'] =  GeneralUtility::_POST('filter');

            $piSettings = $this->piSettings;
            
            $aHavingClause['index'][$piSettings['actualTable']['key']] = $arg['filter']['id'];

            $data = $this->editorUtility->getFilteredDataFromMainTables( $piSettings['actualTable']['tablename'] , $piSettings['actualTable']['key'] , $piSettings['fields'] , $aHavingClause );
            $piSettings['data'] = $data[ $arg['filter']['id'] ];

            $this->view->assign( 'piSettings' , $piSettings );
    }
 
    /**
    * setPiSettings
    *
    * @param int $pluginUid
    * @return array
    */
    private function setPiSettings( $pluginUid )
    {
            $this->pluginUid = $pluginUid;
            $this->pluginsUtility->initiateSettings( $this->pluginUid );
            $aBodytext = $this->pluginsUtility->getPiSettings( $this->pluginUid );
            $aDbTables = $this->pluginsUtility->getDbFieldPropertiesOfMainTables( $aBodytext['dbname'] );

            $this->editorUtility->initiateSettings( $aBodytext ); 
            $piSettings =  $this->editorUtility->mergePiSettings( $aBodytext , $aDbTables );

            $piSettings['uid'] = $this->pluginUid;
            $piSettings['pluginUid'] = $this->pluginUid;
            $piSettings['actualTable'] = $piSettings['tablesList'][0];
            $piSettings['dbname'] = $aBodytext['dbname'];
            $piSettings['table_choise'] = $aBodytext['table_choise'];
            
            $this->piSettings = $piSettings;
    }
}
