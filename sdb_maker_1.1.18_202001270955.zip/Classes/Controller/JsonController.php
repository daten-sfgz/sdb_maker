<?php
namespace Sfgz\SdbMaker\Controller;

use \TYPO3\CMS\Core\Utility\GeneralUtility;
use \TYPO3\CMS\Extbase\Utility\LocalizationUtility;

/**
 * JsonController
 */
class JsonController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

    /**
    * @var string
    */
    protected $defaultViewObjectName = 'TYPO3\CMS\Extbase\Mvc\View\JsonView';

    /**
    * @var array
    */
    protected $incData = Null;

    /**
    * @var array
    */
    protected $piSettings = Null;

    /**
    * @var array
    */
    protected $settings = Null;

    /**
    * pluginUid
    * 
    * @var int
    */
    protected $pluginUid = Null;

    /**
        * pluginsUtility
        *
        * @var \Sfgz\SdbMaker\Utility\PluginsUtility
        */
    protected $pluginsUtility = null;

    /**
        * editorUtility
        *
        * @var \Sfgz\SdbMaker\Utility\EditorUtility
        */
    protected $editorUtility = null;

    /**
        * initializeAction
        *
        */
    public function initializeAction() 
    {
            $this->pluginsUtility = GeneralUtility::makeInstance('Sfgz\\SdbMaker\\Utility\\PluginsUtility');
            $this->editorUtility = GeneralUtility::makeInstance('Sfgz\\SdbMaker\\Utility\\EditorUtility');

            if( $this->request->hasArgument('pluginUid') ) {
                $this->setPiSettings( $this->request->getArgument('pluginUid') );
            }else{
                die( 'Json died: No pluginUid given' );
            }
            

            // get incomed values from GET-option 'data'
            $incData = GeneralUtility::_GET('data');
            // transform GET-parameter 'record' to array
            $parts = parse_url( $incData['record'] );
            parse_str( $parts['path'] , $resArr );

            // create array incData without old 'record' string-variable
            unset( $incData['record'] );
            $this->incData = $incData;
            // insert the new array-variable 'record' 
            $this->incData['record'] = $resArr['data'];
            
    }

    /**
    * Action parents
    * called by page type = 1563700000
    *  makes usage of incData[ id , subaction , record , table ]
    *
    * @return void
    */
    public function parentsAction()
    {
            // detect actual table
            $tableIndex = 0; // default is main-table: 0
            if( isset($this->incData['table']) && !empty($this->incData['table']) ){
                foreach( $this->piSettings['tablesList'] as $tableIndex => $tabDef ){
                    if( $tabDef['tablename'] == $this->incData['table'] ) break;
                }
            }
            $this->piSettings['actualTable'] = $this->piSettings['tablesList'][ $tableIndex ];
            
            switch( $this->incData['subaction'] ){
                case 'create':
                        $aListData = $this->parents_create( $this->incData['record'] );
                break;
                case 'update':
                        $aListData = $this->parents_update( $this->incData['id'] , $this->incData['record'] );
                break;
                case 'delete':
                        $aListData = $this->parents_delete( $this->incData['id'] );
                break;
            }

            $this->view->assign( 'value' , json_encode( $aListData ) );
    }

    /**
    * parents_create
    *
    * @param array $aRecord
    * @return array
    */
    private function parents_create( $aRecord )
    {
            // duplicate?
            $iFoundIndex = $this->parentsGetDuplications();
            
            $aListData = [
                'recordset' => $aRecord,
                'pluginUid' => $this->pluginUid ,
                'id'        => 0 ,
                'subaction' => 'create' ,
                'table' => $this->piSettings['actualTable']['tablename'] ,
                'answer'       => '' ,
                'error'       => 0 ,
                'sql'       => ''
            ];
            
            // duplicate?
            if( $iFoundIndex > 0 ){
                $aListData['error'] = 1;
                $aListData['answer'] = 'Nicht erstellt, Dublikat von Nr. &rarr;' . $iFoundIndex;
                $aListData['id'] = $iFoundIndex;
                return $aListData;
            }
            
            $aValues = [];
            $aFields = [];
            foreach($aRecord as $fieldname => $value ){
                if( $fieldname == $this->piSettings['actualTable']['key'] ) continue;
                $aFields[] = $fieldname;
                if( '' != trim($value) ) $aValues[] = utf8_decode(html_entity_decode( $value ) ) ;
            }
            
            // empty value?
            if( count($aValues) != count($aFields) ){
                $aListData['error'] = 2;
                $aListData['answer'] = 'Nicht erstellt, leeres Feld.';
                return $aListData;
            }
            
            $sqlQuery = 'INSERT INTO ' . $this->piSettings['actualTable']['tablename'] . ' (`' . implode( '`,`' , $aFields ) . '`) VALUES ("' . implode( '","' , $aValues ) . '");';
            $this->editorUtility->sqlUtility->resetAutoIncrement($this->piSettings['actualTable']['tablename'],$this->piSettings['actualTable']['key']);
            $workDone = $this->editorUtility->sqlUtility->execQuery($sqlQuery);
            $aListData['sql'] = utf8_encode( $sqlQuery );
            $aListData['id'] = $this->editorUtility->sqlUtility->getMaxValue( $this->piSettings['actualTable']['tablename'] , $this->piSettings['actualTable']['key'] );
            $aListData['recordset'][ $this->piSettings['actualTable']['key'] ] = $aListData['id'];
            
            // get the uid before the inserted uid
            $aRsAllContents = $this->editorUtility->getDataFromChoosenTable( $this->piSettings['actualTable']['tablename'] );
            $aListData['insertAfter'] = $aRsAllContents[0][ $this->piSettings['actualTable']['key'] ] == $aListData['id'] ? 0 : $aRsAllContents[0][ $this->piSettings['actualTable']['key'] ] ;
            foreach( $aRsAllContents as $ix => $row ){
                $actveUid = $row[ $this->piSettings['actualTable']['key'] ];
                if( $aListData['id'] == $actveUid ) break;
                $aListData['insertAfter'] = $actveUid;
            }
            $aListData['answer'] = 'Nr. ' . $aListData['id'] . ' "' . utf8_encode( implode( ', ' , $aValues ) ). '" erstellt' . ( $aListData['insertAfter'] ? ' unterhalb Nr. ' . $aListData['insertAfter'] . '.' : ' am Anfang.');
            
            return $aListData;
    }

    /**
    * parents_create
    *
    * @param int $id
    * @param array $aRecord
    * @return array
    */
    private function parents_update( $id , $aRecord )
    {
            // duplicate?
            $iFoundIndex = $this->parentsGetDuplications();
            
            $aListData = [
                'recordset' => $aRecord,
                'pluginUid' => $this->pluginUid ,
                'id'        => $id ,
                'subaction' => 'create' ,
                'table' => $this->piSettings['actualTable']['tablename'] ,
                'answer'       => '' ,
                'error'       => 0 ,
                'sql'       => ''
            ];
            
            // duplicate?
            if( !empty($iFoundIndex) ){
                if( $iFoundIndex != $id ){
                    $aListData['answer'] = 'Nr. "' . $id . '" nicht gespeichert, Dublikat von Nr. &rarr;' . $iFoundIndex;
                    $aListData['id'] = $iFoundIndex;
                    $aListData['error'] = 1;
                }else{
                    $aListData['answer'] = 'Nichts zu speichern in Nr. ' . $id;
                    $aListData['error'] = 2;
                }
                return $aListData;
            }
            
            $aValues = [];
            foreach($aRecord as $fieldname => $value ){
                if( '' != trim($value) && $fieldname != $this->piSettings['actualTable']['key'] ) $aValues[] = '`' . $fieldname . '` = "' .  utf8_decode(html_entity_decode( $value ) ) . '"';
            }
            
            // empty value?
            if( count($aValues) != count($aRecord)-1 ){
                $aListData['error'] = 3;
                $aListData['answer'] = 'Nr. &rarr;' . $id . ' nicht gespeichert, leeres Feld.';
                return $aListData;
            }

            $whereClause = 'WHERE `' . $this->piSettings['actualTable']['key'] . '`= ' . $id;
            $sqlQuery = 'UPDATE ' . $this->piSettings['actualTable']['tablename'] . ' SET ' . implode( ',' , $aValues ) . ' '  . $whereClause ;
            $workDone = $this->editorUtility->sqlUtility->execQuery($sqlQuery);
            $aListData['sql'] = utf8_encode( $sqlQuery );
            $aListData['answer'] = 'Gespeichert Nr. ' . $id;

            return $aListData;
    }

    /**
    * parents_create
    *
    * @param int $id
    * @return array
    */
    private function parents_delete( $id )
    {
            $aListData = [
                'pluginUid' => $this->pluginUid ,
                'id'        => $id ,
                'subaction' => 'delete' ,
                'table' => $this->piSettings['actualTable']['tablename'] ,
                'answer'       => '' ,
                'sql'       => ''
            ];
            $whereClause = 'WHERE `' . $this->piSettings['actualTable']['key'] . '`= ' . $this->incData['id'];
            $sqlQuery = 'DELETE FROM `' . $this->piSettings['actualTable']['tablename'] . '` ' . $whereClause ;
            $workDone = $this->editorUtility->sqlUtility->execQuery($sqlQuery);
            $aListData['sql'] = utf8_encode( $sqlQuery );
            $aListData['answer'] = 'Gelöscht Nr. ' . $this->incData['id'];
            return $aListData;
    }
    
    /**
    * parentsGetDuplications
    *
    * @return integer
    */
    private function parentsGetDuplications( )
    {
        if( !is_array($this->incData['record']) ) return 0;
        
        return $this->findDuplications(
            $this->incData['record'] , 
            $this->piSettings['actualTable']['tablename'] , 
            $this->piSettings['actualTable']['key'] , 
            $this->incData['id'] 
        );
    }
    
    /**
    * parentsGetDuplications
    *
    * @param array $aCompare
    * @param string $sTable
    * @param string $sKeyName
    * @param int $iKeyValue
    * @return integer
    */
    private function findDuplications( $aCompare , $sTable , $sKeyName , $iKeyValue = 0 )
    {
            $iFoundIndex = 0;
            
            $aCompairs = [];
            foreach($aCompare as $fieldname => $value ){
                if( $fieldname != $sKeyName ) $aCompairs[] = '`' . $fieldname . '` LIKE "' .  html_entity_decode( $value ) . '"';
            }
            
            if( !count($aCompairs) ) return $iFoundIndex;
            
            $whereClause = 'WHERE ' . implode( ' AND ' , $aCompairs ) . '';
            $aRsFoundContent = $this->editorUtility->getDataFromChoosenTable( $sTable , utf8_decode( $whereClause ) );
            
            if( !count($aRsFoundContent) ) return $iFoundIndex;
            
            // set index if value is found in table
            foreach( $aRsFoundContent as $ix => $row ){
                if( $iKeyValue != $row[$sKeyName] ){
                    $iFoundIndex = $row[$sKeyName];
                    break;
                }
            }
            
            if( $iFoundIndex ) return $iFoundIndex;
            
            // default: return own index if no other found
            $aFoundContent = array_shift($aRsFoundContent);
            $iFoundIndex = $aFoundContent[$sKeyName];
            
            return $iFoundIndex;
    }

    /**
    * Action children (formaly updateAction)
    * called by page type = 1563700000
    * subactions are: create children delete insertMn removeMn
    *  makes usage of incData[ uid_local , uid_foreign  , table  ] (auto detect subaction)
    *
    * @return void
    */
    public function childrenAction()
    {
            $this->piSettings['actualTable'] = $this->piSettings['tablesList'][0];
            
            $table = $this->piSettings['fields'][$this->incData['table']]['childTablename'];
            $where = 'WHERE `uid_local`= ' . $this->incData['uid_local'];
            $whereStatusQuo = ' AND `uid_foreign`=' .$this->incData['uid_foreign'] . ';';
            
            // search this specific recordset
            $aRsStatusQuo = $this->editorUtility->getDataFromChoosenTable( $table , $where . $whereStatusQuo );
            if( count($aRsStatusQuo) ){
                    // remove relation from main-record
                    $sqlStatement = 'DELETE FROM `' . $table . '` ' . $where . $whereStatusQuo ;
            }else{  
                    // add relation to main-record
                    $sqlStatement = 'INSERT INTO `' . $table . '` (`uid_local`,`uid_foreign`) VALUES (' .$this->incData['uid_local'] . ',' .$this->incData['uid_foreign'] . ');' ;
            }
            $workDone = $this->editorUtility->sqlUtility->execQuery($sqlStatement);

            $aListData = [
                'recordset' => $this->editorUtility->getDataFromChoosenTable( $table , $where ),
                'pluginUid' => $this->pluginUid ,
                'id'        => $this->incData['uid_local'] ,
                'table'       => $table ,
                'uid_foreign' => $this->incData['uid_foreign'] 
            ];

            $this->view->assign( 'value' , json_encode( $aListData ) );
    }

    /**
    * Action main
    * called by page type = 1563700000
    *  makes usage of incData[ id , record ]
    *
    * @return void
    */
    public function mainAction()
    {
            $this->piSettings['actualTable'] = $this->piSettings['tablesList'][0];
            $aListData = [];
            switch( $this->incData['subaction'] ){
                case 'clear':
                case 'add':
                    $aListData = $this->main_clear();
                break;
                case 'create':
                    $aListData = $this->main_create( $this->incData['record'] );
                break;
                case 'dupliz':
                    $aListData = $this->main_dupliz( $this->incData['id'] , $this->incData['record'] );
                break;
                case 'read':
                    $aListData = $this->main_read( $this->incData['id'] );
                break;
                case 'update':
                    $aListData = $this->main_update( $this->incData['id'] , $this->incData['record'] );
                break;
                case 'delete':
                    $aListData = $this->main_delete( $this->incData['id'] );
                break;
            }
            $aListData['subaction'] = $this->incData['subaction'];
            $this->view->assign( 'value' , json_encode( $aListData ) );
    }

    /**
    * main_clear (formaly addMain)
    *
    * @return array
    */
    private function main_clear()
    {
            $aListData = [
                'recordset' => [] ,
                'pluginUid' => $this->pluginUid ,
                'id'        => 0 ,
                'sql'       => ''
            ];
            // clear all fields
            if( is_array($this->piSettings['fields']) ) {
                foreach( $this->piSettings['fields'] as $fieldname => $fDef ) $aListData['recordset'][$fieldname] = '';
            }
            // clear suboridnated mn recordsets
            if( isset($this->piSettings['table']['REFERENCED_BY']) ) {
                foreach($this->piSettings['table']['REFERENCED_BY'] as $relName => $relDef ){
                    $subData = $this->editorUtility->getDataFromChoosenTable( $relDef['NM_TABLE'] , 'WHERE uid_local=' . $id );
                    if( is_array($subData) ){
                        $aListData['recordset'][$relName] = [];
                    }
                }
            }
            $aListData['recordset'][ $this->piSettings['actualTable']['key'] ] = 'Neu';
            return $aListData;
    }

    /**
    * main_create
    *
    * @param array $aRecord
    * @return array
    */
    private function main_create( $aRecord )
    {
            $aListData = [
                'recordset' => [] ,
                'pluginUid' => $this->pluginUid ,
                'id'        => 0 ,
                'sql'       => ''
            ];
            
            // verify and sanitize incomed values
            $aValues = [];
            $aFields = [];
            if( count($aRecord) ){
                foreach( $aRecord as $fieldname => $content ){
                    if( !isset($this->piSettings['fields'][$fieldname]) ) continue;
                        
                    $aSanitized = $this->sanitizeData( $content , $this->piSettings['fields'][$fieldname] );
                    if( $aSanitized['sanitizeError'] ) {
                        // error
                        $aListData['error'][$fieldname] = $aSanitized['sanitizeError'] ;
                        $aListData['recordset'][$fieldname] = $content ;
                        $aListData['sql'] .= $aSanitized['sanitizeError'] . ' ';
                    }else{
                        // successful
                        $aListData['recordset'][$fieldname] = $aSanitized['html'] ;
                        $aFields[] = $fieldname ;
                        $aValues[] = $aSanitized['db'];
                    }
                    
                }
            }
            
            // SQL-Call OR error handling
            $sqlStatement = 'No sql call done.';
            $workDone = false;
            if( !isset($aListData['error']) ){
                // reset unique key auto increment
                $this->editorUtility->sqlUtility->resetAutoIncrement($this->piSettings['actualTable']['tablename'],$this->piSettings['actualTable']['key']);
                // run SQL statement
                $sqlStatement = 'INSERT INTO ' . $this->piSettings['actualTable']['tablename'] . ' (`' . implode( '`,`' , $aFields ) . '`) VALUES (' . implode( ',' , $aValues ) . ');';
                $workDone = $this->editorUtility->sqlUtility->execQuery($sqlStatement);
            }
            
            // ID-handling: Read last unique key and insert it in js-variable AND in recordset
            if( $workDone ) { 
                // successful
                $aListData['id'] = $this->editorUtility->sqlUtility->getMaxValue( $this->piSettings['actualTable']['tablename'] , $this->piSettings['actualTable']['key'] );
                $aListData['recordset'][$this->piSettings['actualTable']['key']] = $aListData['id'];
            }else{ // error
                $aListData['sql'] .= ' Fehler beim erzeugen des Datensatzes. ';
            }
            // collect errors
            if( !$workDone  || strlen($aListData['sql']) ) $aListData['sql'] .= '  Fehler in SQL: ' . utf8_encode($sqlStatement);

            return $aListData;
    }

    /**
    * main_dupliz
    *
    * @param int $id
    * @param array $aRecord
    * @return array
    */
    private function main_dupliz( $id , $aRecord )
    {
            $aListData = $this->main_create( $aRecord );
            
            if( isset($aListData['error']) ) return $aListData;
            
            // new uid is in $aListData['id']
            
            // get suboridnated mn recordsets
            if( isset($this->piSettings['table']['REFERENCED_BY']) ) {
                foreach($this->piSettings['table']['REFERENCED_BY'] as $relName => $relDef ){
                    
                    $subData = $this->editorUtility->getDataFromChoosenTable( $relDef['NM_TABLE'] , 'WHERE uid_local=' . $id );
                    if( !is_array($subData) ) continue;
                    if( !count($subData) ) continue;
                    $aValues = [];
                    $workDone = false;
                    $aListData['recordset'][$relName] = [];
                    foreach( $subData as $i => $row ){
                        $aListData['recordset'][$relName][] = $row['uid_foreign'];
                        $aValues[] = '(' . $aListData['id'] . ',' . $row['uid_foreign'] . ')';
                    }
                    if( count( $aValues) ){
                        $sqlStatement = 'INSERT INTO `' . $relDef['NM_TABLE'] . '` (`uid_local`,`uid_foreign`) VALUES ' . implode( ',' , $aValues ) . ';' ;
                        $workDone = $this->editorUtility->sqlUtility->execQuery($sqlStatement);
                    }
                    if( !$workDone ) {
                        $aListData['error'][$relName] = 'Fehler in SQL ' . utf8_encode($sqlStatement);
                        $aListData['sql'] .= $aListData['error'][$relName];
                    }
                }
            
            }
            
            return $aListData;
    }
    
    /**
    * main_read
    *
    * @param int $id
    * @return array
    */
    private function main_read( $id )
    {
            $data = $this->editorUtility->getDataFromChoosenTable( $this->piSettings['actualTable']['tablename'] , 'WHERE ' . $this->piSettings['actualTable']['key'] . '=' . $id );
            $aListData = [
                'recordset' => array_shift($data) ,
                'pluginUid' => $this->pluginUid ,
                'id'        => $id
            ];
            
            // get suboridnated mn recordsets
            if( isset($this->piSettings['table']['REFERENCED_BY']) ) {
                foreach($this->piSettings['table']['REFERENCED_BY'] as $relName => $relDef ){
                    $subData = $this->editorUtility->getDataFromChoosenTable( $relDef['NM_TABLE'] , 'WHERE uid_local=' . $id );
                    if( is_array($subData) ){
                        $aListData['recordset'][$relName] = [];
                        foreach( $subData as $i => $row ){
                            $aListData['recordset'][$relName][]  = $row['uid_foreign'];
                        }
                    }
                }
            
            }
            return $aListData;
    }

    /**
    * main_update
    *
    * @param int $id
    * @param array $aRecord
    * @return array
    */
    private function main_update( $id , $aRecord )
    {
            $aListData = [
                'recordset' => [] ,
                'pluginUid' => $this->pluginUid ,
                'id'        => $id ,
                'sql'       => ''
            ];
            
            // get original records to reset on error-case (not really neccessary)
            $whereClause = $this->piSettings['actualTable']['key'] . '=' . $id ;
            $data = $this->editorUtility->getDataFromChoosenTable( $this->piSettings['actualTable']['tablename'] , 'WHERE ' . $whereClause );
            $dbRecordset = array_shift($data);

            // verify and sanitize incomed values
            $aValues = [];
            if( count($aRecord) ){
                foreach( $aRecord as $fieldname => $content ){
                    if( !isset($this->piSettings['fields'][$fieldname]) ) continue;
                        
                    $aSanitized = $this->sanitizeData( $content , $this->piSettings['fields'][$fieldname] );
                    if( $aSanitized['sanitizeError'] ) {
                        // error
                        $aListData['error'][$fieldname] = $aSanitized['sanitizeError'] ;
                        $aListData['recordset'][$fieldname] = isset($dbRecordset[$fieldname]) ? $dbRecordset[$fieldname] : $content;
                        $aListData['sql'] .= $aSanitized['sanitizeError'] . ' ';
                    }else{
                        // successful
                        $aListData['recordset'][$fieldname] = $aSanitized['html'] ;
                        $aValues[] = '`' . $fieldname . '` = ' . $aSanitized['db'];
                    }
                    
                }
            }
            
            // SQL-Call OR error handling
            $sqlStatement = 'No sql call done.';
            $workDone = false;
            if( !isset( $aListData['error'] ) ){
                // run SQL statement
                $sqlStatement = 'UPDATE ' . $this->piSettings['actualTable']['tablename'] . ' SET ' . implode( ',' , $aValues ) . ' WHERE '  . $whereClause ;
                $workDone = $this->editorUtility->sqlUtility->execQuery($sqlStatement);
            }
            // collect errors
            if( !$workDone  || strlen($aListData['sql']) ) $aListData['sql'] .= ' Fehler in SQL: ' . utf8_encode($sqlStatement);
            
            return $aListData;
    }

    /**
    * main_delete
    *
    * @param int $id
    * @return array
    */
    private function main_delete( $id )
    {
            // clear all fields
            $aListData = $this->main_clear();
            $aListData['id'] = $id;
            
            // delete recordset
            $where = 'WHERE `' . $this->piSettings['actualTable']['key'] . '`= ' . $id;
            $sqlStatement = 'DELETE FROM `' . $this->piSettings['actualTable']['tablename'] . '` ' . $where ;
            $workDone = $this->editorUtility->sqlUtility->execQuery($sqlStatement);
            
            return $aListData;
    }

    /**
    * sanitizeData
    * sanitizes and verifyes data before storing in db
    *  nullable = 0 means, the field must not be NULL NOR 0 (zero)
    *  nullable = 1 means, the field may contain NULL OR 0
    *  if nullable and there is a reference to 1n table: The field can be NULL, but NOT 0
    * 
    * @param string $value
    * @param array $fieldSettings
    * @return array
    */
    private function sanitizeData( $value , $fieldSettings )
    {
            $aResponse = [ 'db' => '' , 'html' => $value , 'sanitizeError' => null ];
            $isDate = substr( $fieldSettings['DATA_TYPE'] , 0 , 4 ) == 'date' ? 1 : 0;
            $isChar = substr( $fieldSettings['DATA_TYPE'] , -4 ) == 'char' ? 1 : 0;
            $isText = substr( $fieldSettings['DATA_TYPE'] , -4 ) == 'text' ? 1 : 0;
            $isInteger = !$isDate && !$isChar && !$isText ? 1 : 0; // int OR decimal OR float OR double
            
            if( empty($value) ){ //  '' OR NULL OR 0
                if( $fieldSettings['nullable']  ){
                    if( isset($fieldSettings['REFERENCE_TO']) ){ 
                        // nullable and reference to 1n table: not 0 but NULL
                        $aResponse['db'] = 'null';
                    }else{
                        if( $value === 0 ){ 
                            // nullable and is 0
                            $aResponse['db'] = $value;
                        }else{
                            if( $isInteger ){
                                // nullable and is empty integer
                                $aResponse['db'] = 'null';
                            }else{ 
                                // nullable and is empty text
                                $aResponse['db'] = '""';
                            }
                        }
                    }
                }else{ 
                    //  must not be NULL NOR 0, break and throw error
                    $aResponse['sanitizeError'] = 'darf nicht leer sein!' ;
                }
            }elseif( $isInteger ){
                // integer non empty value
                $aResponse['db'] = $value;
                
            }elseif( $isDate ){
                $englishDate =  $this->sanitizeDateTime( $value );
                $aResponse['db'] = "'" . $englishDate . "'";
                $aResponse['html'] = $englishDate;
                
            }else{ 
                // embrace text values
                $aResponse['db'] = "'" . utf8_decode( str_replace( "'" , '"' , $value ) ) . "'";
                
            }
            return $aResponse;
    }
    /**
    * sanitizeDateTime
    *  if value contains 2 dots . then its german date. Transform to english date.  Sanitize to 4 digits at first position
    *  if value contains 2 hyphen - then it is english date. Sanitize to 4 digits at first position
    *
    * @param str $value
    * @return str
    */
    private function sanitizeDateTime( $value )
    {
            $aDateTime = explode( ' ' , str_replace( 'T' , ' ' , $value ) );
            
            if( strpos( $value , '.' ) ){
                $aGermDate = explode( '.' , $aDateTime[0] );
                if( strlen( $aGermDate[2] ) == 2 ) $aGermDate[2] += 2000;
                $aDateTime[0] = $aGermDate[2] . '-' . $aGermDate[1] . '-' . $aGermDate[0] ;
                
            }elseif( strpos( $value , '-' ) ){
                $aEnglishDate = explode( '-' , $aDateTime[0] );
                if( strlen( $aEnglishDate[0] ) == 2 ) $aEnglishDate[0] += 2000;
                $aDateTime[0] = implode( '-' , $aEnglishDate );
                
            }else{
                return $value;
            }
            
            return implode( ' ' , $aDateTime );
    }

    /**
    * setPiSettings
    *
    * @param int $pluginUid
    * @return array
    */
    private function setPiSettings( $pluginUid )
    {
            $this->pluginUid = $pluginUid;
            $this->pluginsUtility->initiateSettings( $this->pluginUid );
            $aBodytext = $this->pluginsUtility->getPiSettings( $this->pluginUid );
            $aDbTables = $this->pluginsUtility->getDbFieldPropertiesOfMainTables( $aBodytext['dbname'] );

            $this->editorUtility->initiateSettings( $aBodytext ); 
            $piSettings =  $this->editorUtility->mergePiSettings( $aBodytext , $aDbTables );

            $piSettings['uid'] = $this->pluginUid;
            $piSettings['pluginUid'] = $this->pluginUid;
            $piSettings['actualTable'] = $piSettings['tablesList'][0];
            $piSettings['dbname'] = $aBodytext['dbname'];
            $piSettings['table_choise'] = $aBodytext['table_choise'];
            
            $this->piSettings = $piSettings;

    }

}
