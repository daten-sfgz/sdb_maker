<?php
namespace Sfgz\SdbMaker\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;
use \TYPO3\CMS\Core\Database\ConnectionPool;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2019 Daniel Rueegg <colormixture@verarbeitung.ch>,
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class TtContentUtility
 * 
 */

class TtContentUtility implements \TYPO3\CMS\Core\SingletonInterface
{

    /**
     * getPiSettings
     *  affored by AjaxController and JsonController
     * 
     * @param int $uid
     * @return array
     */
    Public function getPiSettings( $uid )
    {
            $aTtContent = $this->getSingleRow( $uid , ['pi_flexform','bodytext'] );
            
            $aFlexformData = $this->getFlexformData($aTtContent['pi_flexform']);
            
            $aBodytext = json_decode( $aTtContent['bodytext'] , true );
            $aBodytext['uid'] = $uid;
            $aBodytext['pluginUid'] = $uid;
            $aBodytext['dbname'] = $aFlexformData['dbname'];
            // for standalone sql
            $aBodytext['host'] = $aFlexformData['host'];
            $aBodytext['user'] = $aFlexformData['user'];
            $aBodytext['password'] = $aFlexformData['password'];
            
            return $aBodytext;
    }
    
    /**
        * getBodytextArray
        *
        * @param integer $uid
        * @return array
        */
    Public function getBodytextArray( $uid = 0 )
    {
            $aTtContent = $this->getSingleRow( $uid , ['bodytext'] );
            $aBodytext = json_decode( $aTtContent['bodytext'] , true );
            return $aBodytext;
    }
    
    /**
        * setBodytextArray
        *
        * @param array $aBodytext
        * @param integer $uid
        * @return array
        */
    Public function setBodytextArray( $aBodytext , $uid )
    {
            if( !$uid ) return false;
            $jsonString = json_encode($aBodytext);
            $aUpdate = [ 'bodytext' => $jsonString ];
            $aWhere = [ 'uid' => $uid ];
            return $this->updateWhere( $aUpdate , $aWhere );
    }

    /**
     * updateWhere
     * setValues
     *
     * @param array $aSet [ 'fieldname' => newValue , 'fieldname2' => newValue2 ]
     * @param array $aWhere ['fieldname'] => isValue
     * @return array
     */
    Private function updateWhere( $aSet , $aWhere )
    {
    
        $result = GeneralUtility::makeInstance(ConnectionPool::class)->getConnectionForTable('tt_content')
            ->update( 
                'tt_content' , 
                $aSet, // set
                $aWhere // where
            );
        return $result;
    }

    /**
     * getSingleRow
     *
     * @param int $uid
     * @param array $aFields optional 
     * @return array
     */
    Private function getSingleRow( $uid , $aFields = ['bodytext','pi_flexform'] )
    {
                $row = GeneralUtility::makeInstance(ConnectionPool::class)
                    ->getConnectionForTable('tt_content')
                    ->select(
                        $aFields, // fields to select
                        'tt_content', // from
                        [ 'uid' => (int)$uid ] // where
                    )
                    ->fetch();
                return $row;
    }

    /**
     * getFlexformData
     *
     * @param str $pi_flexform
     * @return array
     */
    Private function getFlexformData( $pi_flexform )
    {
		$flexformData = GeneralUtility::xml2array($pi_flexform);

		$foreignFlexform = array();
		$abstractPlugin = new \TYPO3\CMS\Frontend\Plugin\AbstractPlugin();
		if( isset($flexformData['data']) && is_array($flexformData['data']) && count($flexformData['data']) ){
			foreach ( $flexformData['data'] as $sheet => $data ) {
				if( is_array($data) && count($data) ){
					foreach ( $data as $lang => $value ) {
						if( is_array($value) && count($value) ){
							foreach ( $value as $key => $val ) {
								$strContent = $abstractPlugin->pi_getFFvalue($flexformData, $key, $sheet);
 								$execCommand = '$foreignFlexform["' . str_replace( '.' , '"]["' , $key ) . '"]=$strContent; ';
								eval( $execCommand );
							}
						}
					}
				}
			}
		}
		return $foreignFlexform['settings'];

    }
 
    /**
     * getTtContent TODO delete this unused method
     *
     * @param int $uid
     * @param array $aFields optional 
     * @return array
     */
    Private function Unused_getTtContent( $uid , $aFields = ['bodytext','pi_flexform'] )
    {
                $queryBuilderCnt = GeneralUtility::makeInstance(ConnectionPool::class)->getQueryBuilderForTable('tt_content');
                $queryBuilderCnt->getRestrictions()->removeAll();		
                $queryBuilderCnt->select(...$aFields)->from('tt_content');
                $restrictedStatement = $queryBuilderCnt->where( $queryBuilderCnt->expr()->eq( 'uid' , $queryBuilderCnt->createNamedParameter( $uid , \PDO::PARAM_INT ) ) );
                
                $rows = $restrictedStatement->execute()->fetchAll();
                $row = current($rows);
                return $row;
    }

}
