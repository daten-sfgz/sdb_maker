<?php
namespace Sfgz\SdbMaker\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2016 Daniel Rueegg <colormixture@verarbeitung.ch>,
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class SqlStandaloneUtility
 *   affored when extension sdb_adminer is not installed
 *   loads db-ingredients from flexform instead of table tx_sdbadminer_domain_model_accesspoints
 *   
 *   - settings came from ts-settings and contains sql-field definitions. 
 *     Autoloadable!
 *   
 *   - piSettings came from Plugin and contains db-ingredients.
 *     + holds the user-settings in the bodytex for presentation of fields, it overrides settings
 *     Needs pluginUid. Autoloadable by initiateWithPluginUid( pluginUid ).
 */

class SqlStandaloneUtility {

    /**
     * info
     *
     * @var array
     */
    Public $info = array();

    /**
     * ingredients
     *
     * @var array
     */
    Private $ingredients = [];
    
    /**
        * ttContentUtility
        *
        * @var \Sfgz\SdbMaker\Utility\TtContentUtility
        */
    protected $ttContentUtility = null;

    /**
     * constructor
     *
     * @return void
     */
    public function __construct()
    {
            $this->ttContentUtility = GeneralUtility::makeInstance('Sfgz\\SdbMaker\\Utility\\TtContentUtility');
            // append ts-settings
            $this->objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
            $configurationManager = $this->objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManagerInterface');
            $fullsettings = $configurationManager->getConfiguration( \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FULL_TYPOSCRIPT);
            $this->typoScriptService =  $this->objectManager->get('TYPO3\\CMS\\Extbase\\Service\\TypoScriptService');
            $pluginKey = 'tx_sdbmaker_model';
            $this->settings = $this->typoScriptService->convertTypoScriptArrayToPlainArray( $fullsettings['plugin.'][ $pluginKey . '.' ]['settings.']['sql_standalone.'] );
    }
	
	/**
	 * initiateWithPluginUid
	 * 
	 * @param int pluginUid
	 * @return boolean
	 */
    Public function initiateWithPluginUid( $pluginUid )
    {
            $piSettings = $this->ttContentUtility->getPiSettings($pluginUid);
            return $this->setIngedients( $piSettings );
    }
	
	/**
	 * setIngedients
	 * 
	 * @param array $aIngedients must contain at least the 4 fields below, could be eg settings
	 * @return boolean
	 */
    Public function setIngedients( $aIngedients )
    {
            $aFields = [ 'host' , 'user' , 'password' ,  'dbname' ];
            foreach( $aFields as $field ) {
                if( !isset($aIngedients[$field]) ) continue;
                $this->ingredients[$field] = $aIngedients[$field];
            }
            if( count($this->ingredients) != count($aFields) ) {
                $this->ingredients = [];
                return false;
            }
            return true;
    }

	/**
	 * connectToDatabase
	 * used in 
	 *  class.tx_sdbadminer_addFieldsToFlexForm.php
	 *  FilterController.php
	 * 
	 * @param string $dbname HINT unused in this class
	 * @return array 
	 */
	public function connectToDatabase( $dbname )
	{
        if( !count($this->ingredients) ) {
            $this->info['error'][] = 'no ingredients given.';
            return false;
        }
	    
		/* try to connect */
		$this->connection = @mysqli_connect( $this->ingredients['host'] , $this->ingredients['user'] , $this->ingredients['password'] , $this->ingredients['dbname'] );

		/* check connection */
		if( !$this->connection ){
			$this->info['error'][] = ' Connection failed(host:' .  $this->ingredients['host'] . ',user:' .  $this->ingredients['user'] . ',db:' .  $this->ingredients['dbname'] . ') ' ;
		
		}elseif ( $this->connection->connect_errno ) {
			$this->info['error'][] = sprintf("Connect failed: %s\n", $this->connection->connect_error);
			$this->connection = false;
		
		}
		if( isset($this->info['error']) && count($this->info['error']) ) return false;
		
 		return true;
	}
	
	/**
	 * closeDatabase
	 * used in 
	 *  EditorController.php
	 *  JsonController.php
	 *  FileActionsUtility.php
	 *  SqlUtility.php
	 * 
	 * @return void 
	 */
	public function closeDatabase()
	{
		if( $this->connection ) $this->connection->close();
		$this->connection = false;
	}
	
	/**
	 * getFieldProperties
	 * @param string $field
	 * @param string $table
	 * @param string $database
	 * @return array 
	 */
	public function getFieldProperties( $field = '' , $table , $database )
	{
		$sqlTableSchema = 'SELECT COLUMN_NAME , ';
		$sqlTableSchema .= 'CHARACTER_SET_NAME , ';
		$sqlTableSchema .= 'IS_NULLABLE , ';
		$sqlTableSchema .= 'EXTRA , ';
		$sqlTableSchema .= 'COLUMN_DEFAULT , ';
		$sqlTableSchema .= 'DATA_TYPE , ';
		$sqlTableSchema .= 'COLUMN_TYPE, ';
		$sqlTableSchema .= 'NUMERIC_SCALE, ';
		$sqlTableSchema .= 'COLUMN_COMMENT FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = "'.$database.'" AND  TABLE_NAME = "'.$table.'"';
		if( !empty($field) ) $sqlTableSchema .= ' AND COLUMN_NAME = "'.$field.'"';
		
		$aDefaults = $this->runQuery( $sqlTableSchema . ';' );
		
		$aFieldDefaults = [];
		
		foreach( $aDefaults as $aRow ){
			$aFieldDefaults[$aRow['COLUMN_NAME']] = $aRow;
			// define IS_NULLABLE
			$aFieldDefaults[$aRow['COLUMN_NAME']]['nullable'] = $aRow['IS_NULLABLE'] == 'YES' ? '1' : '';
		}
		
		foreach( $aFieldDefaults as $fld => $aRow ){
			// define default FIELD type
			$aFieldDefaults[$fld]['fieldtype'] = 'textfield';
			$aColType = explode( ' ' , $aRow['COLUMN_TYPE'] ); // we need the int(1) in 'int(1) unsigned'
				
			// detect specified FIELD type
			if( $aColType[0] == 'tinyint(1)' ){
				$aFieldDefaults[$fld]['fieldtype'] = $this->settings['render_tinyint_1'];
				
			}elseif( $aColType[0] == 'smallint(1)' ){
				$aFieldDefaults[$fld]['fieldtype'] = $this->settings['render_smallint_1'];
				
			}elseif( $aColType[0] == 'mediumint(1)' ){
				$aFieldDefaults[$fld]['fieldtype'] = $this->settings['render_mediumint_1'];
				
			}elseif( $aColType[0] == 'int(1)' ){
				$aFieldDefaults[$fld]['fieldtype'] = $this->settings['render_int_1'];
				
			}elseif( $aColType[0] == 'bit(1)' ){
				$aFieldDefaults[$fld]['fieldtype'] = $this->settings['render_bit_1'];
				
			}elseif( $aRow['EXTRA'] == 'on update CURRENT_TIMESTAMP' ){
				$aFieldDefaults[$fld]['fieldtype'] = $this->settings['render_current_timestamp'];
				
			}elseif( $aRow['DATA_TYPE'] == 'tinytext' ){
				$aFieldDefaults[$fld]['fieldtype'] = $this->settings['render_tinytext'];
				
			}elseif( $aRow['DATA_TYPE'] == 'text' ){
				$aFieldDefaults[$fld]['fieldtype'] = $this->settings['render_text'];
				
			}elseif( $aRow['DATA_TYPE'] == 'mediumtext' ){
				$aFieldDefaults[$fld]['fieldtype'] = $this->settings['render_richtext'];
				
			}elseif( $aRow['DATA_TYPE'] == 'longtext' ){
				$aFieldDefaults[$fld]['fieldtype'] = $this->settings['render_richtext'];
				
			}elseif( $aRow['DATA_TYPE'] == 'blob' ){
				$aFieldDefaults[$fld]['fieldtype'] = $this->settings['render_blob'];
				
			}elseif( $aRow['DATA_TYPE'] == 'mediumblob' ){
				$aFieldDefaults[$fld]['fieldtype'] = $this->settings['render_blob'];
				
			}elseif( $aRow['DATA_TYPE'] == 'longblob' ){
				$aFieldDefaults[$fld]['fieldtype'] = $this->settings['render_blob'];
				
			}elseif( $aRow['DATA_TYPE'] == 'date' ){
				$aFieldDefaults[$fld]['fieldtype'] = $this->settings['render_date'];
				
			}elseif( $aRow['DATA_TYPE'] == 'time' ){
				$aFieldDefaults[$fld]['fieldtype'] = $this->settings['render_time'];
				
			}elseif( $aRow['DATA_TYPE'] == 'enum' ){
				$aFieldDefaults[$fld]['fieldtype'] = $this->settings['render_enum'];
				
			}elseif( $aRow['DATA_TYPE'] == 'set' ){
				$aFieldDefaults[$fld]['fieldtype'] = $this->settings['render_set'];
				
			}
			
		}
		
		// return definition of one field only
		if( !empty($field) ) return isset($aFieldDefaults[$field]) ? $aFieldDefaults[$field] : [];
		
		// return definition of all fields
		return $aFieldDefaults;
	}

	/**
	 * readOnlyTabels
	 * returns only tables without views AND without mn-tables
	 * 
	 * @param string $dbname
	 * @return array 
	 */
	public function readOnlyTabels( $dbname )
	{
		if( !$this->connection ) return false;
		$this->info['tables'] = [];
		// get only tables with single PrimaryKey:
		if ($result = $this->connection->query('SELECT TABLE_NAME FROM information_schema.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA = "'.$dbname.'" AND CONSTRAINT_NAME = "PRIMARY" GROUP BY TABLE_NAME HAVING COUNT(COLUMN_NAME)<2 ;')) {
			while ($row = $result->fetch_assoc()) {
				foreach($row as $fld => $cnt ) $this->info['tables'][$cnt] = $cnt;
			}
			$result->free();
		}
		return $this->info['tables'];
	}

	/**
	 * readMnTabels
	 * returns only tables with referential constraints
	 * 
	 * @param string $dbname
	 * @return array 
	 */
	public function readMnTabels( $dbname )
	{
		if( !$this->connection ) return false;
		$this->info['tables'] = [];
        //returns only tables with 2 primary indexes (m:n subtables): 
        $sql = 'SELECT TABLE_NAME FROM information_schema.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA = "'.$dbname.'" AND CONSTRAINT_NAME = "PRIMARY" GROUP BY TABLE_NAME HAVING COUNT(COLUMN_NAME)=2 ;';
		// returns ctables with cascade-on-delete constraint: $sql = 'SELECT DISTINCT TABLE_NAME FROM  information_schema.REFERENTIAL_CONSTRAINTS WHERE UNIQUE_CONSTRAINT_SCHEMA = "'.$dbname.'" AND DELETE_RULE = "CASCADE"';
		if ($result = $this->connection->query($sql)) {
			while ($row = $result->fetch_assoc()) {
				foreach($row as $fld => $cnt ) $this->info['tables'][$cnt] = $cnt;
			}
			$result->free();
		}
		return $this->info['tables'];
	}
	
	
	/**
	 * readViews
	 * returns only views
	 *
	 * @param string $dbname
	 * @return array 
	 */
	public function readViews( $dbname )
	{
		if( !$this->connection ) return false;
		
		$this->info['tables'] = [];
		if ($result = $this->connection->query("SELECT TABLE_NAME,VIEW_DEFINITION FROM information_schema.VIEWS WHERE `TABLE_SCHEMA` = '" . $dbname . "';")) {
			while ($row = $result->fetch_assoc()) {
				$this->info['tables'][ $row['TABLE_NAME'] ] = $row['VIEW_DEFINITION'];
			}
			$result->free();
		}
		return $this->info['tables'];
	}
	
	/**
	 * execQuery
	 * @param string $query
	 * @return boolean 
	 */
	public function execQuery( $query )
	{
	    if( empty( $query ) ) return false;
	    if( !$this->connection ) return false;
		$result = $this->connection->query( $query );
		return $result;
	}
	
	/**
	 * singleQuery
	 * run query and return the fetched FIRST ROW
	 * 
	 * @param string $query
	 * @return array 
	 */
	public function singleQuery( $query )
	{
	    $result = $this->execQuery( $query );
		return $result ? $result->fetch_assoc() : [];
	}
	
	/**
	 * runQuery
	 * connect, run query and insert mutliple rows in 2-dim array
	 * 
	 * @param string $query
	 * @return array 
	 */
	public function runQuery( $query )
	{
	    $aQueryResult = [];
	    if( empty( $query ) ) return $aQueryResult;
	    
	    if( !strpos( $query , 'LIMIT' ) ) $query = rtrim( $query , ';' ) . '  LIMIT ' . $this->settings['sql_limit_fe'] . ';';
	    
		if ( $this->connection && $result = $this->connection->query( $query ) ) {
			$z=1;
			while ($row = $result->fetch_assoc()) {
				foreach($row as $fld => $cnt ) $aQueryResult[$z][$fld] = utf8_encode($cnt);
				$z+=1;
			}
			$result->free();
		}
	    return $aQueryResult;
	}

    /**
     * getMaxValue
     *
     * @param string $tablename
     * @param string $fieldname
     * @return int
     */
    Public function getMaxValue( $tablename , $fieldname )
    {
		if( !$this->connection ) return false;
        $aRecord = $this->singleQuery( "SELECT MAX(`" . $fieldname . "`) AS maximum FROM `" . $tablename . "`;" );
        return empty($aRecord['maximum']) ? 0 : $aRecord['maximum'];
    }

    /**
     * resetAutoIncrement
     *
     * @param string $tablename
     * @param string $unique
     * @return int
     */
    Public function resetAutoIncrement( $tablename , $unique )
    {
            $lastUid = $this->getMaxValue( $tablename , $unique );
            ++$lastUid;
            $this->execQuery( 'ALTER TABLE ' . $tablename . ' AUTO_INCREMENT=' . $lastUid . ';' );
            return $lastUid;
    }

    /**
     * getSqlSelect
     *  used for modelControler implemented over importUtility->createView()->getSqlSelect() without clause
     *  used for ajaxController implemented over editUtility->importUtility->getSqlSelect() with havingClause
     *
     * @param string $centralTable
     * @param string $mainKey
     * @param array $tableDef
     * @param array $aHavingClause optional [ srcInText | srcInIndex ][ srcInTablename ][ 'srcInFieldname' => compareValue ]
     * @return string
     */
    Public function getSqlSelect( $centralTable , $mainKey , $tableDef , $aHavingClause = [] )
    {       
        $sqlSelectQueryUtility = GeneralUtility::makeInstance('Sfgz\\SdbMaker\\Utility\\GetSelectQueryUtility');
        return $sqlSelectQueryUtility->getSqlSelect( $centralTable , $mainKey , $tableDef , $aHavingClause );
    }
}
