<?php
namespace Sfgz\SdbMaker\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2019 Daniel Rueegg <colormixture@verarbeitung.ch>,
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class GetSelectQueryUtility
 * 
 */

class GetSelectQueryUtility implements \TYPO3\CMS\Core\SingletonInterface
{

    /**
     * getSqlSelect
     *  used for modelControler implemented over importUtility->createView()->getSqlSelect() without clause
     *  used for ajaxController implemented over editUtility->importUtility->getSqlSelect() with havingClause
     *
     * @param string $centralTable
     * @param string $mainKey
     * @param array $tableDef
     * @param array $aHavingClause optional [ srcInText | srcInIndex ][ srcInTablename ][ 'srcInFieldname' => compareValue ]
     * @return string
     */
    Public function getSqlSelect( $centralTable , $mainKey , $tableDef , $aHavingClause = [] )
    {       
            // $aHavingClause [ text | index ][ 'srcInFieldnameAsKnownInMainTable' => compareValue ]
            $aFieldCol = [];
            $aTablesCol = [];
            if( !is_array($tableDef) || !count($tableDef) ) return false;
            
            foreach( $tableDef as $loopFieldName => $fieldsDef ){
                    if( $fieldsDef['tablename'] == $centralTable ){
                            $aFieldCol[$fieldsDef['tablename'] . "." . $fieldsDef['fieldname']] = $fieldsDef['tablename'] . "." . $fieldsDef['fieldname'];
                            
                    }elseif( isset($fieldsDef['separator']) && isset($fieldsDef['childTablename']) ){
                    // 1:m relation
                            $aFieldCol[$fieldsDef['tablename'] . "." . $fieldsDef['fieldname']] = "GROUP_CONCAT( DISTINCT " . $fieldsDef['tablename'] . "." . $fieldsDef['fieldname'] . " SEPARATOR '" . $fieldsDef['separator'] . " ' ) AS `" . $fieldsDef['fieldname'] . "`";
                            
                            $aTablesCol[] = "LEFT JOIN " . $fieldsDef['childTablename'] . " ON " . $centralTable . "." . $mainKey . " = " . $fieldsDef['childTablename'] . ".uid_local";
                            $aTablesCol[] = "LEFT JOIN " . $fieldsDef['tablename'] . " ON " . $fieldsDef['childTablename'] . ".uid_foreign = " . $fieldsDef['tablename'] . "." . $fieldsDef['foreignKeyname'] . "";
                    
                    }else{
                    // 1:n relation
                            $aFieldCol[$fieldsDef['tablename'] . "." . $fieldsDef['fieldname']] = " IF( " . $fieldsDef['tablename'] . "." . $fieldsDef['fieldname'] . " > '' , " . $fieldsDef['tablename'] . "." . $fieldsDef['fieldname'] . ",'-') AS " . $fieldsDef['fieldname'];
                            
                            $aTablesCol[] = "LEFT JOIN " . $fieldsDef['tablename'] . " ON " . $centralTable . "." . $fieldsDef['fieldname'] . " = " . $fieldsDef['tablename'] . "." . $fieldsDef['foreignKeyname'] . "";
                            
                    }
            }
            if( !count($aFieldCol) ) return false;
            // main key if not set jet
            if( !isset($aFieldCol[$centralTable . "." . $mainKey]) ) $aFieldCol[$centralTable . "." . $mainKey] = $centralTable . "." . $mainKey;
            
            $sqlFields = implode( ' , ' , $aFieldCol );
            
            $sqlTables = count($aTablesCol) ? implode( ' ' , $aTablesCol ) : '';
            
            $havingClause = $this->constructSqlHavingClause( $centralTable , $mainKey , $tableDef , $aHavingClause );

            $statement = "SELECT " . $sqlFields . " FROM ";
            $statement .= $centralTable . " " . $sqlTables;
            $statement .= " GROUP BY " . $centralTable . "." . $mainKey . " ";
            $statement .= $havingClause;
            
            return $statement ;
          
    }

    /**
     * constructSqlHavingClause
     *  used for ajaxController implemented over editUtility->importUtility->getSqlSelect() with havingClause
     *
     * @param string $centralTable
     * @param string $mainKey
     * @param array $tableDef
     * @param array $aHavingClause [ srcInText | srcInIndex ][ 'srcInFieldname' => compareValue ]
     * @return string
     */
    Private function constructSqlHavingClause( $centralTable , $mainKey , $tableDef , $aHavingClause = [] )
    {
            if( !count($aHavingClause) ) return;
//             [ text  ][ 'Fieldname' => needleString ]
//             [ index ][ 'Fieldname' => equalInteger ]
//             [ boolean ][ 'Fieldname' => 'zero'  1 ]
            
            $aTablesCol = [];
            $aAndClause = [];
            $aOrClause = [];
            // detect used tables
            // search for index-values
            if( isset($aHavingClause['index']) ){
                foreach( $aHavingClause['index'] as $fieldname => $untrimmedValue ){
                    if( !isset($tableDef[$fieldname]) ) continue;
                    $fd = $tableDef[$fieldname];
                    if( isset($fd['separator']) && isset($fd['childTablename']) ){
                        // index search in n:m relation
                        $aTablesCol[ $fd['childTablename'] ] = "LEFT JOIN " . $fd['childTablename'] . " ON " . $centralTable . "." . $mainKey . " = " . $fd['childTablename'] . ".uid_local";
                        $aAndClause[ $fieldname ] = $fd['childTablename'] . '.uid_foreign = ' . trim($untrimmedValue);
                    }else{
                        // index search in maintable
                        $aAndClause[ $fieldname ] = $centralTable . '.' . $fieldname . ' = ' . trim($untrimmedValue);
                    }
                }
            }
            
            // search for textes
            if( isset($aHavingClause['text']) ){
                foreach( $aHavingClause['text'] as $fieldname => $untrimmedValuesArr ){
                    if( !isset($tableDef[$fieldname]) ) continue;
                    $fd = $tableDef[$fieldname];

                    // table-setting: joins
                    if( isset($fd['separator']) && isset($fd['childTablename']) ){
                        // text search in 1:m relation
                        $aTablesCol[ $fd['childTablename'] ] = "LEFT JOIN " . $fd['childTablename'] . " ON " . $centralTable . "." . $mainKey . " = " . $fd['childTablename'] . ".uid_local";
                        $aTablesCol[ $fd['tablename'] ] = "LEFT JOIN " . $fd['tablename'] . " ON " . $fd['childTablename'] . ".uid_foreign = " . $fd['tablename'] . "." . $fd['foreignKeyname'] . "";
                    
                    }elseif( isset($fd['foreignKeyname']) ){
                        // text search in 1:n relation
                        $aTablesCol[ $fd['tablename'] ] = "LEFT JOIN " . $fd['tablename'] . " ON " . $centralTable . "." . $fd['fieldname'] . " = " . $fd['tablename'] . "." . $fd['foreignKeyname'] . "";
                    
                    }
                    
                    // else text search in maintable- without any joins
                    // Field-setting: text-search
                    if( is_array($untrimmedValuesArr) ){
                        $aUntrimmedValues = $untrimmedValuesArr;
                    }else{
                        $aUntrimmedValues = [ 0 => $untrimmedValuesArr ];
                    }
                    foreach( $aUntrimmedValues as $untrimmedValue ){
                        $word = strtolower( utf8_decode( trim($untrimmedValue) ) );
                        $aOrClause[$fieldname . '.' . $word ] = 'LOWER(' . $fd['tablename'] . '.' . $fieldname . ') LIKE "%' . $word . '%"';
                    }
                }
            }
            
            // search for booeans
            if( isset($aHavingClause['boolean']) ){
                foreach( $aHavingClause['boolean'] as $fieldname => $untrimmedValue ){
                    // search for zero (0)
                    if( $untrimmedValue == 'zero' ) $untrimmedValue = 0;
                    if( empty($untrimmedValue) ){
                        $aAndClause[$fieldname . '.' . $untrimmedValue] = '(' . $tableDef[$fieldname]['tablename'] . '.' . $fieldname . ' IS NULL OR ' . $tableDef[$fieldname]['tablename'] . '.' . $fieldname . ' = 0 )';
                    }else{
                        $aAndClause[$fieldname . '.' . $untrimmedValue] = '' . $tableDef[$fieldname]['tablename'] . '.' . $fieldname . ' >= 1';
                    }
                }
            }
            if( !count($aAndClause) && !count($aOrClause) ) return;

            $sStatement = 'SELECT DISTINCT ' . $mainKey . ' FROM ' . $centralTable . ' ';
            if( count($aTablesCol) ) $sStatement .= implode( ' ' , $aTablesCol ) . ' ';
            
            $sStatement .= 'WHERE ' ;
            if( count($aAndClause) ) $sStatement .= '(' . implode( ' AND ' , $aAndClause ) . ') ';
            if( count($aAndClause) && count($aOrClause) ) $sStatement .= 'AND ';
            if( count($aOrClause) ) $sStatement .= '(' . implode( ' OR ' , $aOrClause ) . ') ';
            
            $returnString = ' HAVING ' . $mainKey . ' IN (' . $sTables . $sStatement .')';
            
            return $returnString;
    }
 
}
