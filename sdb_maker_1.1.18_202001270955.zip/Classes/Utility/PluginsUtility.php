<?php
namespace Sfgz\SdbMaker\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2019 Daniel Rueegg <colormixture@verarbeitung.ch>,
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class PluginsUtility
 * referred by
 * - ModelController
 * - AjaxController
 * - JsonController
 * 
 */

class PluginsUtility extends \Sfgz\SdbMaker\Utility\TtContentUtility
{

    /**
        * errors
        *
        * @var array
        */
    Public $errors = [];

    /**
     * sqlUtility
     *
     * @var \Sfgz\SdbMaker\Utility\SqlStandaloneUtility
     */
    protected $sqlUtility = null;

    /**
     * initiateSettings
     *  // only pluginUid affored
     * @param int $pluginUid
     * @return boolean
     */
    Public function initiateSettings( $pluginUid )
    {
            $getSqlUtility = GeneralUtility::makeInstance('Sfgz\\SdbMaker\\Utility\\GetSqlUtility');
            $this->sqlUtility = $getSqlUtility->getSqlClass($pluginUid);

			if( !$this->sqlUtility ) return false;
			
			return true;
    }


    /**
     * getDbFieldPropertiesOfMainTables FIXME duplication from Sfgz\SdbAdminer\Controller\EditlistController
     *
     * @param string $dbname
     * @return array
     */
    Public function getDbFieldPropertiesOfMainTables( $dbname )
    {
			if( !$this->sqlUtility || !$dbname ) return [ 'tables' => null , 'views' => null ];
			
			$dbInfo = $this->getFieldInfosFromDB( $dbname );
			$aFieldDefaults = $dbInfo['properties'];
			
			// append index with unique-keys from KEY_COLUMN_USAGE-definition
            if( is_array($dbInfo['uniques']) ){
                foreach( $dbInfo['uniques'] as $fieldDef ){
                    if( isset( $aFieldDefaults[ $fieldDef['TABLE_NAME'] ][ $fieldDef['COLUMN_NAME'] ]) ){
                        $aFieldDefaults[ $fieldDef['TABLE_NAME'] ][ $fieldDef['COLUMN_NAME'] ]['IS_PRIMARY'] = $fieldDef['CONSTRAINT_NAME'];
                    }
                }
            }
            
            // Set constraintsDB.
            $constraintsDB = $this->detectReferences( $dbInfo['constraints'] , $aFieldDefaults );
            
            // detect references in main tables.
            if( is_array($aFieldDefaults ) ){
                foreach($aFieldDefaults as $tabnam => $tabDef ){
                    if( isset($constraintsDB[$tabnam]) ) { 
                        foreach( $tabDef as $fieldname => $fldDef ){
                            if( !isset($constraintsDB[$tabnam][$fieldname]) ) continue;
                            $aFieldDefaults[$tabnam][$fieldname]['REFERENCE_TO'] = $constraintsDB[$tabnam][$fieldname];
                            $aFieldDefaults[$tabnam]['REFERENCES'][$fieldname] = $constraintsDB[$tabnam][$fieldname]['REF_TABLE']; 
                        }
                        if( $aFieldDefaults[$tabnam]['REFERENCES'] ) $aFieldDefaults[$tabnam]['TABLE_TYPE'] = 'main';
                    }else{
                        $aFieldDefaults[$tabnam]['TABLE_TYPE'] = 'loose';
                    }
                }
            }
            
            if( is_array($constraintsDB ) ){
                foreach($constraintsDB as $tabnam => $tabDef ){
                    foreach($tabDef as $fldnam => $fldDef ){
                            if( isset($fldDef['LOCAL_INDEX']) ) {
                                    // 1:m table only, note this  nm relation in main table
                                    $aFieldDefaults[$tabnam]['REFERENCED_BY'][$fldnam] = $fldDef; 
                                    $aFieldDefaults[$tabnam]['REFERENCED_BY'][$fldnam]['REF_LABEL'] = ( $aFieldDefaults[$fldDef['REF_TABLE']][ $fldDef['REF_FIELD'] ]['COLUMN_COMMENT'] ? $aFieldDefaults[$fldDef['REF_TABLE']][ $fldDef['REF_FIELD'] ]['COLUMN_COMMENT'] : $fldDef['REF_FIELD'] );
                                    // note in 1:m table the index-field of the main-table
                                    $aFieldDefaults[$fldDef['REF_TABLE']]['REFERING_INDEX'] = $fldDef['LOCAL_INDEX'] ; 
                            }
                            // 1:m table only
                            if( isset($fldDef['NM_TABLE']) ) $aFieldDefaults[$fldDef['REF_TABLE']]['NM_TABLE'] = $fldDef['NM_TABLE'] ; 
                            // 1:n AND 1:m tables
                            $aFieldDefaults[$fldDef['REF_TABLE']]['REFERING_TABLE'] = $tabnam; 
                            $aFieldDefaults[$fldDef['REF_TABLE']]['LOCAL_INDEX'] = $fldDef['REF_INDEX']; 
                            $aFieldDefaults[$fldDef['REF_TABLE']]['LOCAL_FIELD'] = $fldDef['REF_FIELD']; 
                            $aFieldDefaults[$fldDef['REF_TABLE']]['TABLE_TYPE'] = isset($fldDef['NM_TABLE']) ? '1:m' : '1:n'; 
                    }
                    if( is_array($aFieldDefaults[$tabnam]['REFERENCED_BY']) ) $aFieldDefaults[$tabnam]['TABLE_TYPE'] = 'main';
                }
            }

			return [ 'tables' => $aFieldDefaults , 'views' => $dbInfo['views'] ];
			
    }
 
    /**
        * detectReferences FIXME duplication from Sfgz\SdbAdminer\Controller\EditlistController
        *
        * @param array $aDBconstraints
        * @param array $aFieldDefaults
        * @return array
        */
    Private function detectReferences( $aDBconstraints , $aFieldDefaults )
    {
            // Set constraintsDB. Bundle references informations in 2 arrays to hold the mn-tables separate
            $constraintsDB = [];
            $constraintsMn = [];
            // detect the label field in 1:n tables
            $labelsDb = [];
            if( is_array($aFieldDefaults ) ){
                foreach($aFieldDefaults as $tabnam => $tabDef ){
                    foreach($tabDef as $fldnam => $fldDef ){
                        if( !isset($fldDef['IS_PRIMARY']) ) { $labelsDb[$tabnam] = $fldnam; break; }
                    }
                }
            }
            if( is_array($aDBconstraints ) ){
                foreach( $aDBconstraints as $fieldDef ){
                        if( $fieldDef['COLUMN_NAME'] == 'uid_local' ){ // nm - main table
                            $constraintsMn[ $fieldDef['TABLE_NAME'] ][ 'localTable' ] =  $fieldDef['REFERENCED_TABLE_NAME'];
                            $constraintsMn[ $fieldDef['TABLE_NAME'] ][ 'localUid' ] = $fieldDef['REFERENCED_COLUMN_NAME'];
                        }elseif( $fieldDef['COLUMN_NAME'] == 'uid_foreign' ){ // mn - sibling
                            $constraintsMn[ $fieldDef['TABLE_NAME'] ][ 'labelField' ] = $labelsDb[$fieldDef['REFERENCED_TABLE_NAME']];
                            $constraintsMn[ $fieldDef['TABLE_NAME'] ][ 'REF_TABLE' ] = $fieldDef['REFERENCED_TABLE_NAME'];
                            $constraintsMn[ $fieldDef['TABLE_NAME'] ][ 'REF_INDEX' ] = $fieldDef['REFERENCED_COLUMN_NAME'];
                        }else{ // not nm table - sibling or main
                            $constraintsDB[ $fieldDef['TABLE_NAME'] ][ $fieldDef['COLUMN_NAME'] ] = [ 
                                    'REF_TABLE'=> $fieldDef['REFERENCED_TABLE_NAME'] , 
                                    'REF_INDEX'=> $fieldDef['REFERENCED_COLUMN_NAME'] , 
                                    'REF_FIELD'=> $labelsDb[$fieldDef['REFERENCED_TABLE_NAME']] 
                            ];
                        }
                }
            }
            // Reset constraintsDB. move the mn-constraint to corresponding main table referred by uid_local
            if( is_array($constraintsMn ) ){
                foreach( $constraintsMn as $tabnam => $tabConst ){
                    $constraintsDB[ $tabConst['localTable'] ][ $tabConst['labelField'] ] = [ 'LOCAL_INDEX'=>$tabConst['localUid'] , 'NM_TABLE'=>$tabnam , 'REF_TABLE'=>$tabConst['REF_TABLE'] , 'REF_INDEX'=>$tabConst['REF_INDEX'] , 'REF_FIELD'=> $tabConst['labelField'] ];
                }
            }
            return $constraintsDB;
    }
 
    /**
        * getFieldInfosFromDB FIXME duplication from Sfgz\SdbAdminer\Controller\EditlistController
        *
        * @param string $dbname
        * @return array
        */
    Private function getFieldInfosFromDB( $dbname )
    {
			if( !$this->sqlUtility->connectToDatabase( $dbname ) ) return [ 'properties' => null , 'constraints' => null , 'uniques' => null ];

			// read names of all main and sibling TABLES (with single unique) without M:N-TABLES and without VIEWS
            $dbTables = $this->sqlUtility->readOnlyTabels( $dbname );
            // read VIEWS
            $aDbViews = $this->sqlUtility->readViews( $dbname );
            // read M:N-TABLES
            $aDbMnTables = $this->sqlUtility->readMnTabels( $dbname );
            
            // add TABLE DEFINITIONS: 
			$aFieldDefaults = [];
            if( is_array($dbTables ) ){
                foreach($dbTables as $tabnam){
                    $aFieldDefaults[$tabnam] = $this->sqlUtility->getFieldProperties( '' , $tabnam , $dbname ) ;
                }
            }
			$aViewFieldDefaults = [];
            if( is_array($aDbViews ) ){
                foreach($aDbViews as $tabnam => $viewDef){
                    $aViewFieldDefaults[$tabnam]['viewdef'] = $viewDef ;
                    $aViewFieldDefaults[$tabnam]['fields'] = $this->sqlUtility->getFieldProperties( '' , $tabnam , $dbname ) ;
                }
            }
            
			// read REFERNCES
            $sqlColUsage = 'SELECT * FROM information_schema.KEY_COLUMN_USAGE WHERE `TABLE_SCHEMA` = "'.$dbname.'"';
            
            // used for detectReferences( $aConstraintsFromDB , $aFieldDefaults )
            // contains nm or main tables, NO 1n tables AND NO UNIQUE-constraints
            $whrForeignKeys = ' AND `REFERENCED_TABLE_SCHEMA` = "'.$dbname.'";';
            $aConstraintsFromDB = $this->sqlUtility->runQuery( $sqlColUsage.$whrForeignKeys );

			// detect UNIQUE KEYS 
            $whrUniques = ' AND `REFERENCED_TABLE_SCHEMA` IS NULL AND `CONSTRAINT_NAME` LIKE "PRIMARY";';
            $aUniquesFromDB = $this->sqlUtility->runQuery( $sqlColUsage.$whrUniques );

			$this->sqlUtility->closeDatabase();
			
			$aResult = [
                'properties' => $aFieldDefaults , 
                'views' => $aViewFieldDefaults , 
                'constraints' => $aConstraintsFromDB , 
                'uniques' => $aUniquesFromDB  
			];

			return $aResult;
    }

    /**
        * getRenderTypes
        *  callled from ModelController
        *
        * @param array $tabDef
        * @param array $settings
        * @return void
        */
    Public function getRenderTypes( $tabDef , $settings )
    {  
                $aTableFields = [];
                $z = 0;
                if( isset($tabDef) ) {
                    foreach($tabDef as $fieldname => $row ){
                        if( isset($row['COLUMN_NAME']) ) {
                            ++$z;
                            $aTableFields['fld'][$fieldname] = $row;
                            
                            $aTableFields['fld'][$fieldname]['CONFIG'] = [
                                'labeltext' => $row['COLUMN_COMMENT'] ? $row['COLUMN_COMMENT'] : $row['COLUMN_NAME'] ,
                                'size' => $this->coltype2size($row['COLUMN_TYPE']) ,
                                'fieldtype' => 0 , 
                                'orientation' => 0 , 
                                'search' => $settings['display_defaults']['search']['default'] , 
                                'list' => $settings['display_defaults']['list']['default'] ,
                                'position' => $z
                            ];
                            
                            if( $row['IS_PRIMARY'] ){
                                $aTableFields['fld'][$fieldname]['renderType'] = 'IS_PRIMARY';
                                
                            }elseif( $row['REFERENCE_TO'] ){
                                $aTableFields['fld'][$fieldname]['renderType'] = 'REFERENCE_TO';
                                $aTableFields['fld'][$fieldname]['CONFIG']['labeltext'] = $row['REFERENCE_TO']['REF_FIELD'] ;
                                
                            }elseif( $row['NM_TABLE'] ){
                                $aTableFields['fld'][$fieldname]['renderType'] = 'NM_TABLE';
                                
                            }elseif( $row['COLUMN_TYPE'] == 'mediumtext' ){
                                $aTableFields['fld'][$fieldname]['renderType'] = 'RICHTEXT';
                                $aTableFields['fld'][$fieldname]['CONFIG']['size'] = $settings['display_defaults']['size']['RICHTEXT'] ;
                                $aTableFields['fld'][$fieldname]['CONFIG']['search'] = 0;
                                $aTableFields['fld'][$fieldname]['CONFIG']['list'] = 0;
                                
                            }elseif( $row['COLUMN_TYPE'] == 'text' ){
                                $aTableFields['fld'][$fieldname]['renderType'] = 'TEXTAREA';
                                $aTableFields['fld'][$fieldname]['CONFIG']['size'] = $settings['display_defaults']['size']['TEXTAREA'];
                                $aTableFields['fld'][$fieldname]['CONFIG']['search'] = 0;
                                $aTableFields['fld'][$fieldname]['CONFIG']['list'] = 0;
                                
                            }elseif( substr( $row['COLUMN_TYPE'] , -6 , 6 ) == 'int(1)' ){
                                $aTableFields['fld'][$fieldname]['renderType'] = 'BOOLEAN';
                                
                            }else{
                                $aTableFields['fld'][$fieldname]['renderType'] = 'CHARS';
                            }
                            
                            $aTableFields['fld'][$fieldname]['size'] = $aTableFields['fld'][$fieldname]['CONFIG']['size'];
                            
                        }else{
                            $aTableFields['tab'][$fieldname] = $row;
                        }
                    }
                }
                if( isset($tabDef['REFERENCED_BY']) ){
                    foreach($tabDef['REFERENCED_BY'] as $fieldname => $row ){
                        ++$z;
                        $aTableFields['fld'][$fieldname] = $row;
                        $aTableFields['fld'][$fieldname]['renderType'] = 'NM_TABLE';
                        $aTableFields['fld'][$fieldname]['CONFIG'] = [
                            'labeltext' => $row['REF_LABEL'] , 'size' => $settings['display_defaults']['size']['NM_TABLE'] , 'fieldtype' => 0 , 'orientation' => 0 , 'search' => 1 , 'list' => 1 , 'position' => $z
                        ];
                        $aTableFields['fld'][$fieldname]['size'] = $aTableFields['fld'][$fieldname]['CONFIG']['size'];
                    }
                }
                $aTableFields['filter']['edit'] = [ 'enable' => 1 , 'startsearch' => 2 ];
                $aTableFields['filter']['preview'] = [ 'enable' => 1 , 'startsearch' => 2 ];
                $aTableFields['main']['title'] = [ 'text' => 'Ansicht' , 'label' => 'Datenbank Ansicht' ];
                return $aTableFields;
    }

    /**
        * coltype2size
        *
        * @param string $coltype
        * @return void
        */
    private function coltype2size( $coltype )
    {  
        $strPos = strpos( ' ' . $coltype , '(' );
        if( !$strPos ) return '';
        $strEnd = strpos( $coltype , ')' );
        if( !$strEnd ) return '';
        $contentBetweenEmbracement = substr( $coltype , $strPos , $strEnd-$strPos );
        return $contentBetweenEmbracement;
    }
} 

    /**
     * ttContentUtility
     *
     * @var \Sfgz\SdbMaker\Utility\TtContentUtility
     */
//     protected $ttContentUtility = null;

//             $this->ttContentUtility = GeneralUtility::makeInstance('Sfgz\\SdbMaker\\Utility\\TtContentUtility');

//     /**
//         * getBodytextArray
//         *
//         * @param integer $uid
//         * @return array
//         */
//     Public function getBodytextArray( $uid )
//     {
//                 return $this->ttContentUtility->getBodytextArray( $uid  );
//     }
//     
//     /**
//         * setBodytextArray
//         *
//         * @param array $aBodytext
//         * @param integer $uid
//         * @return array
//         */
//     Public function setBodytextArray( $aBodytext , $uid )
//     {
//                 return $this->ttContentUtility->setBodytextArray( $aBodytext , $uid );
//                 
//     }
//  
//     /**
//         * getPiSettings
//         *
//         * @param integer $PluginUid
//         * @return array
//         */
//     Public function getPiSettings( $PluginUid )
//     {
//                 return $this->ttContentUtility->getPiSettings( $PluginUid  );
//     }


 
