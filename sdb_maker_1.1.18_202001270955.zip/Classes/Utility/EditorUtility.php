<?php
namespace Sfgz\SdbMaker\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2019 Daniel Rueegg <colormixture@verarbeitung.ch>,
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class EditorUtility
 * referred by
 * - ModelController
 * - AjaxController
 * - JsonController
 * 
 */

class EditorUtility implements \TYPO3\CMS\Core\SingletonInterface
{

    /**
        * lastSqlStatement
        *
        * @var string
        */
    Public $lastSqlStatement = null;

    /**
        * errors
        *
        * @var array
        */
    Public $errors = [];

    /**
     * sqlUtility
     *
     * @var \Sfgz\SdbMaker\Utility\SqlStandaloneUtility
     */
    Public $sqlUtility = null;

    /**
        * settings
        *
        * @var array
        */
    protected $settings = null;

    /**
     * initiateSettings
     *  affored is settings: dbname and pluginUid
     *
     * @param array $settings
     * @return boolean
     */
    Public function initiateSettings( $settings )
    {
			$this->settings = $settings;
			
            $getSqlUtility = GeneralUtility::makeInstance('Sfgz\\SdbMaker\\Utility\\GetSqlUtility');
            $this->sqlUtility = $getSqlUtility->getSqlClass($settings['pluginUid']);

 			if( !$this->sqlUtility ){
                die( 'Editor ended in mode: ' . $ini . ' pluginUid:' . $this->settings['pluginUid'] . '' );return false;
 			}
 			 
			$success = $this->sqlUtility->connectToDatabase( $this->settings['dbname'] );
			if( is_array($this->sqlUtility->info['error']) ){
                $info = implode( ', ' , $this->sqlUtility->info['error'] );
                if( !$success ) die('Editor init ended');// 'EditorUtility init (' . $this->settings['pluginUid'] . '-' . $this->settings['dbname'] . ')  info: (' . $info . ')  ini: ' . $ini );
			}
			return $success;
    }

    /**
        * getDataFromChoosenTable
        *
        * @param string $sTablename
        * @param string $sWhere optional full where statement
        * @return array
        */
    Public function getDataFromChoosenTable( $sTablename , $sWhere = '' )
    {
            $this->lastSqlStatement = trim( 'SELECT * FROM ' . $this->settings['dbname'] . '.' . $sTablename . ' ' . $sWhere) . ';';
            $aQueryResult = $this->sqlUtility->runQuery( $this->lastSqlStatement );
			return $aQueryResult;
    }

    /**
        * getFilteredDataFromMainTables
        *
        * @param string $centralTable
        * @param string $mainKey
        * @param array $tableDef
        * @param array $aHavingClause optional
        * @return array
        */
    Public function getFilteredDataFromMainTables( $centralTable , $mainKey , $tableDef , $aHavingClause = [] )
    {
            $this->lastSqlStatement = $this->sqlUtility->getSqlSelect( $centralTable , $mainKey , $tableDef , $aHavingClause ) . ';';
            $data = $this->sqlUtility->runQuery( $this->lastSqlStatement );
			//set the main key as index
			$aDataWithKey = [];
			foreach( $data as $row ){
                $aDataWithKey[$row[$mainKey]] = $row;
			}
			return $aDataWithKey;
    }

    /**
     * getTablesList FIXME duplication from part of \Sfgz\SdbAdminer\Controller\EditlistController
     *
     * @return array
     */
    Public function getTablesList()
    {
        $aDbTables = $this->sqlUtility->readOnlyTabels( $this->settings['dbname'] );
        if( is_array($aDbTables ) ){
            foreach($aDbTables as $tabnam){
                $aFieldDefaults[$tabnam] = $this->sqlUtility->getFieldProperties( '' , $tabnam , $this->settings['dbname'] ) ;
                if( count($aFieldDefaults[$tabnam]) != 2 ) unset($aDbTables[$tabnam]);
            }
        }
        array_unshift($aDbTables,'Wählen...');
        return $aDbTables;
    }

    /**
        * mergePiSettings
        *  append attributes from default-settings 
        *  to the individual configuration stored in bodytext
        *
        * @param array $aBodytext individual configuration
        * @param array $aDbTables attributes from default-settings 
        * @return array
        */
    Public function mergePiSettings( $aBodytext , $aDbTables )
    {
            // assign own stored values from $aDbTables to $piSettings
            $tabNam = isset( $aBodytext['table_choise'] ) ? $aBodytext['table_choise'] : '';
            $piSettings = !empty($tabNam) && isset($aBodytext[ $tabNam ]) ? $aBodytext[ $tabNam ] : [];
            
            // assign default values from $aDbTables to $tabdef
            $tablesList = [];
            if( isset($aDbTables['tables'][$tabNam]) ){
                $tabdef = $aDbTables['tables'][$tabNam];
            }
            
            $editFieldTypes = [ 0=>'select' , 1=>'filterselect' , 2=>'radiogroup' , 3=>'textarea' , 4=>'richtext'  , 5=>'text' , 6=>'checkbox' ];
            
            // append default field settings to $piSettings fields-array
            if( is_array($piSettings['fields']) ){
                foreach($piSettings['fields'] as $fieldname => $aFieldDef ){
                    // set the default type  text
                    $piSettings['fields'][$fieldname]['edittype'] = $editFieldTypes[5];
                    // overwrite the default type with user-setting
                    if( isset($aFieldDef['fieldtype']) ) {
                        // fieldtype is a numeric field 
                        $piSettings['fields'][$fieldname]['edittype'] = $editFieldTypes[$aFieldDef['fieldtype']];
                        $piSettings['fields'][$fieldname]['fieldtypeOrig'] = $aFieldDef['fieldtype'];
                    }
                    // get the size from user-settings
                    if( isset($aFieldDef['size']) ) {
                        $piSettings['fields'][$fieldname]['aSizes'] = explode( 'x' , strtolower($aFieldDef['size']) );
                    }
                    // get values from db-table-definition
                    if( isset($tabdef[$fieldname]) ) {
                        // take all given values
                        foreach($tabdef[$fieldname] as $attr => $val ) $piSettings['fields'][$fieldname][$attr] = $val;
                        // add special values
                        $piSettings['fields'][$fieldname]['fieldname'] = $fieldname;
                        if( isset($tabdef[$fieldname]['REFERENCE_TO']) ) {
                            $piSettings['fields'][$fieldname]['tablename'] = $tabdef[$fieldname]['REFERENCE_TO']['REF_TABLE'];
                            $piSettings['fields'][$fieldname]['foreignKeyname'] = $tabdef[$fieldname]['REFERENCE_TO']['REF_INDEX'];
                        }else{
                            $piSettings['fields'][$fieldname]['tablename'] = $tabNam;
                        }
                        unset($tabdef[$fieldname]);
                    }
                }
            }
            // append settings from 1:m tables to table-array
            // this fields are not in main-table definition
            if( is_array($tabdef) ){
                foreach($tabdef as $fieldname => $val ){
                        if( $fieldname == 'REFERENCED_BY' ){
                            foreach($val as $fld => $defs ){
                                $piSettings['fields'][$fld]['REFERENCED_BY'] = $defs;
                                // special values
                                $piSettings['fields'][$fld]['tablename'] = $defs['REF_TABLE'];
                                $piSettings['fields'][$fld]['fieldname'] = $defs['REF_FIELD'];
                                $piSettings['fields'][$fld]['foreignKeyname'] = $defs['REF_INDEX'];
                                $piSettings['fields'][$fld]['childTablename'] = $defs['NM_TABLE'];
                                $piSettings['fields'][$fld]['separator'] = ',';
                            }
                        }
                        $piSettings['table'][$fieldname]= $val;
                }
            }
            // create array for filter-lists in referenced fields
            if( is_array($piSettings['fields']) ){
                $aFilterSelectOptions = [];
                foreach( $piSettings['fields'] as $fieldName => $fldDef ){
                    $tabletypes = [ 'REFERENCE_TO' , 'REFERENCED_BY' ];
                    foreach( $tabletypes as $type ){
                        if( isset($fldDef[$type]['REF_TABLE']) ){
                            $table1nData = $this->getDataFromChoosenTable( $fldDef[$type]['REF_TABLE'] );
                            foreach( $table1nData as $row ){
                                    $index = $row[ $fldDef[$type]['REF_INDEX'] ];
                                    $value = $row[ $fldDef[$type]['REF_FIELD'] ];
                                    $aFilterSelectOptions[$fieldName][$index] = $value;
                            }
                        }
                    }
                    if( $fldDef['search'] == 1 ) {
                        // search in this field for text
                        $piSettings['aFilterSearchTextFields'][$fieldName] = $fieldName;
                    }elseif( $fldDef['search'] > 1 && !isset($aFilterSelectOptions[$fieldName]) ){
                        // search as selectfield, but no list given: 
                        // this happens on 1/0 fields, they are not in relational tables
                        $aFilterSelectOptions[$fieldName] = [ 0 => 'Nein' , 1 => 'Ja' ];
                    }
                }
                if( count($aFilterSelectOptions) ) $piSettings['aFilterSelectOptions'] = $aFilterSelectOptions;
            }
            // append main settings to table-array. 'tablename' contains the name of the main-table
            $piSettings['table']['tablename'] = $aBodytext['table_choise'];
            $piSettings['table']['dbname'] = $this->settings['dbname'];
            
            $piSettings['tablesList'] = $this->getRelatedTablesList( $piSettings['table']['tablename'] , $aDbTables );
            return $piSettings;
    }

    /**
     * getRelatedTablesList 
     *
     * @param string $mainTableName
     * @param array $aDbTables
     * @return array
     */
    Private function getRelatedTablesList( $mainTableName , $aDbTables )
    {
        $tabIx = 0;
        $tablesList = [ $tabIx => [ 'key' => '' , 'value' => $tabIx , 'label' => $mainTableName . ' Haupttabelle' , 'tablename' => $mainTableName , 'type' => 'Haupttabelle' ] ];
        if( !isset($aDbTables['tables'][$mainTableName]) ) return $tablesList;

        foreach($aDbTables['tables'][$mainTableName] as $fieldname => $fldConf ){
            if( !isset($fldConf['IS_PRIMARY']) || empty($fldConf['IS_PRIMARY']) ) continue;
                $tablesList[$tabIx]['key'] = $fieldname;
            break;
        }
        ++$tabIx;
        
        $tabDef =  $aDbTables['tables'][$mainTableName];
        
        if( is_array($tabDef['REFERENCES']) ){
            foreach($tabDef['REFERENCES'] as $relTabFieldname => $tableToDelete ){
                $tablesList[$tabIx] = [ 'key' => $aDbTables['tables'][$tableToDelete]['LOCAL_INDEX'] , 'value' => $tabIx , 'label' => $tableToDelete . ' 1:n' , 'tablename' => $tableToDelete , 'type' => '1:n' ];
                ++$tabIx;
            }
        }
        
        if( is_array($tabDef['REFERENCED_BY']) ){
            foreach($tabDef['REFERENCED_BY'] as $relTabFieldname => $refTabDef ){
                if( isset($refTabDef['REF_TABLE']) ) {
                    $tablesList[$tabIx] = [ 'key' => $refTabDef['REF_INDEX'] , 'value' => $tabIx , 'label' => $refTabDef['REF_TABLE'] . ' 1:m' , 'tablename' => $refTabDef['REF_TABLE'] , 'type' => '1:m' ];
                    ++$tabIx;
                }
            }
        }
        return $tablesList;
    }

}
