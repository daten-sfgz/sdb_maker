<?php
namespace Sfgz\SdbMaker\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2019 Daniel Rueegg <colormixture@verarbeitung.ch>,
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class PreImportUtility
 * 
 */

class PreImportUtility implements \TYPO3\CMS\Core\SingletonInterface
{

    /**
     * info
     *
     * @var string
     */
    Public $info = '';

    /**
        * workDB
        *
        * @var array
        */
    Public $workDB = null;

    /**
        * errors
        *
        * @var array
        */
    Public $errors = [];

    /**
     * sqlUtility
     *
     * @var \Sfgz\SdbMaker\Utility\SqlStandaloneUtility
     */
    protected $sqlUtility = null;

    /**
        * settings
        *
        * @var array
        */
    protected $settings = null;

    /**
        * constructor
        *
        * @return void
        */
    Public function __construct()
    {
    }

    /**
        * initiateSettings
        *  affored is settings: sql_config ! dbname and pluginUid
        *  
        * @param array $settings
        * @return void
        */
    Public function initiateSettings( $settings )
    {
			$this->settings = $settings;

            $getSqlUtility = GeneralUtility::makeInstance('Sfgz\\SdbMaker\\Utility\\GetSqlUtility');
            $this->sqlUtility = $getSqlUtility->getSqlClass($settings['pluginUid']);

			if( !$this->sqlUtility ) return false;
			
			return true;
    }

    /**
        * detectConflicts
        * when stateId is < 10 then no tables, else some tables existing
        * 0 = no connection
        * 1 = ok import in empty db
        * 10 = no import tablename-conflicts with table(s) "tablename1 , name2"
        * 11 = ok import althought some other tables existing
        * 12 = try to syncronyze
        * 20 = no sync cause field(s) not matching in [1|n] table(s)
        * 21 = ok sync
        *
        * @param array $aTablesDefinition   field-definitions as defined by excel-sheet
        * @param array $aGroupOptions       users choise on how fields should be splitted
        * @param array $aNullableOptions    users choise whether the field is nullable or not
        * @param string $renamedTablename
        * @return int
        */
    Public function detectConflicts( $aTablesDefinition , $aGroupOptions , $aNullableOptions , $renamedTablename )
    {
            if( !count($aTablesDefinition) ){
                $this->errors[] = 'Tabellendefinition fehlt in PreImportUtility->detectConflicts';
                return 0;
            }
            
            if( empty($renamedTablename) ){
                $this->errors[] = 'Tabellenname fehlt in PreImportUtility->detectConflicts';
                return 0;
            }
            
            $usedTablenames  = $this->normalizeTableAndFieldNames( $aTablesDefinition , $aGroupOptions , $aNullableOptions , $renamedTablename );
            
            $dbData =$this->getDbFieldPropertiesOfUsedTables( $this->settings['dbname'] , $usedTablenames );

            // detect conflict id
            $statusInfo = $this->detectConflictStatusNr(  $dbData , $usedTablenames  );
            
            $this->workDB  = [ 'usedTablenames'=>$usedTablenames , 'fieldDefinition'=>$dbData['fieldDefinition'] , 'database'=>$dbData['database'] , 'errors' => $this->errors ];
            
            // build array conflict info
			// set the integer stateId if a connection is stablished
            $aConflictInfo = [ 'stateId' =>  $statusInfo , 'usedTables' => $usedTablenames  , 'dbname' => $this->settings['dbname'] , 'countAllTables'=> $dbData['countAllTables'] , 'listConflictTables'=>$listConflictTables ];
			
			// set the message text for specific stateId
            $this->info = $this->getConflictMessage($aConflictInfo);
            
            // return the integer stateId
            return $statusInfo;
    }

    /**
     * getDbFieldPropertiesOfUsedTables
     *
     * @param string $dbname
     * @param array $usedTablenames tables structure of main table with related tables
     * @return array
     */
    Private function getDbFieldPropertiesOfUsedTables( $dbname , $usedTablenames )
    {
			if( !$this->sqlUtility || !$dbname ) return [ 'fieldDefinition' => null , 'countAllTables' => null , 'database' => null ];
			
			$connected = $this->sqlUtility->connectToDatabase( $dbname );
			
            // read names of all main and sibling TABLES (with single unique) without M:N-TABLES and without VIEWS
            $aDbTables = $this->sqlUtility->readOnlyTabels( $dbname );
            
            // read M:N-TABLES
            $aDbMnTables = $this->sqlUtility->readMnTabels( $dbname );
            
			// read VIEWS AND TABLES
			$aDbViews = $this->sqlUtility->readViews( $dbname );
            
            // add sub tables (with composed unique)
            if( count($aDbMnTables) ) {
                foreach( $aDbMnTables as $tablename ){ $aDbTables[$tablename] = $tablename; }
            }
            // add TABLE DEFINITIONS: 
			$aFieldDefaults = [];
            if( count($aDbTables) ) {
                ksort($aFieldDefaults);
                foreach($aDbTables as $tablename){
                    if( isset( $usedTablenames[$tablename] ) ) $aFieldDefaults[$tablename] = $this->sqlUtility->getFieldProperties( '' , $tablename , $dbname ) ;
                }
            }
			$this->sqlUtility->closeDatabase();
            
            
            // remove VIEWS: subtract table names from names of views and tables
            if( count($aDbViews) ) {
                foreach( $aDbViews as $tablename ){ 
                    if( isset($aDbTables[$tablename]) ) unset($aDbViews[$tablename]); 
                }
            }

			$aResult = [
                'fieldDefinition' => $aFieldDefaults , 
                'countAllTables' => count($aDbTables) , 
                'database' => [ 'Tabellen'=>$aDbTables , 'Views'=>$aDbViews ]
			];

			return $aResult;
    }


    /**
        * normalizeTableAndFieldNames
        *
        * @param array $aTablesDefinition   field-definitions as defined by excel-sheet dim2array[ FIELDNAME ]['maxZeichen','separer','typ','leereZellen','multipleValues']
        * @param array $aGroupOptions       users choise on how fields should be splitted for table-def: dim2array[0][unique=>field-index , 'tablename'] and for fields: dim2array[1...n][ 'check'=>nr , 'fieldname' ]
        * @param array $aNullableOptions
        * @param string $renamedTablename
        * @return array
        */
    Private function normalizeTableAndFieldNames( $aTablesDefinition , $aGroupOptions , $aNullableOptions , $renamedTablename )
    {
            $sqlCnf = $this->settings['sql_config'];
            
            $newTablename = $this->sanitizeFieldname( $renamedTablename , $sqlCnf['bTableNamesConcatCamelCase'] , $sqlCnf['bTableNamesLowercase'] , $sqlCnf['bTableNamesUppercaseFirst'] );
            
            $uniqueKey = '';
            $aNewFieldnames = [];
            $newTable = [];
            
            /*
             * step 1/2: enrich incomed array $aTablesDefinition
             */
            
            // merge analysed field-definitions from $aTablesDefinition 
            // with choosen group-options from $aGroupOptions
            //   unforunately the array $aGroupOptions is indexed by number ($fieldIndex) instead of fieldnames, 
            //   so map them here
            $fieldIndex = 0;
                if( count($aTablesDefinition) ) {
                foreach( $aTablesDefinition as $fieldname => $aFieldDef ){
                        ++$fieldIndex;
                        
                        // field in main table selected as unique
                        if( $aGroupOptions[0]['unique'] == $fieldIndex ){
                            $uniqueKey =  $fieldname;
                            $tableType = 'main';
                        }else{
                            // field in 1:n , 1:m or main table 
                            $tableType = $aFieldDef['multipleValues'] ? '1m' : ( $aGroupOptions[$fieldIndex]['check'] ? '1n' : 'main' );
                        }
                        
                        // renamed the field manually?
                        $aNewFieldnames[$tableType][$fieldname] = $aGroupOptions[$fieldIndex]['fieldname'] ? $aGroupOptions[$fieldIndex]['fieldname'] : $fieldname;
                        
                        $aTablesDefinition[$fieldname]['position'] = $fieldIndex;
                        $aTablesDefinition[$fieldname]['notnullable'] = $aNullableOptions[$fieldIndex]['check'] ? 1 : 0;
                        $aTablesDefinition[$fieldname]['tabletype'] = $tableType;
                        $aTablesDefinition[$fieldname]['possibleNewFieldname'] = $aGroupOptions[$fieldIndex]['fieldname'] ? $aGroupOptions[$fieldIndex]['fieldname'] : $fieldname;
                        $aTablesDefinition[$fieldname]['source'] = $fieldname;
                        $aTablesDefinition[$fieldname]['comment'] = $aGroupOptions[$fieldIndex]['fieldname'];
                }
            }

            // if unique is empty create name for unique key from  default
            if(empty($uniqueKey)){
                    $uniqueKey = $this->uniquizeFieldname( $this->settings['sql_config']['sNameDefaultUniqueKey'] , $aTablesDefinition , '' );
                    $aTablesDefinition[$uniqueKey] = [
                        'tabletype'   => 'main',
                        'typ'   => 'int',
                        'maxZeichen' => 11,
                        'notnullable' => 1 ,
                        'position' => 0 ,
                        'possibleNewFieldname' => $uniqueKey ,
                        'increase'  => 'auto_increment' 
                    ];
            }
            
            // sanitize all fieldnames
            $fieldUsage = [];
            foreach( $aTablesDefinition as $fieldname => $aFieldDef ){
                    $newFieldname = $this->uniquizeFieldname( $this->sanitizeFieldname( $aFieldDef['possibleNewFieldname'] , $sqlCnf['bFieldNamesConcatCamelCase'] , $sqlCnf['bFieldNamesLowercase'] , $sqlCnf['bFieldNamesUppercaseFirst'] ) , $fieldUsage , '' ) ;
                    $fieldUsage[$newFieldname] = $newFieldname;
                    $aTablesDefinition[$fieldname]['fieldname'] = $newFieldname;
            }
            
            // re-define unique - sanitized
            $defUnique = $aTablesDefinition[$uniqueKey]['fieldname'];
            
            /*
             * step 2/2: buid new array $newTable
             */

            // create maintable and append as first the uniqueKey field (without configuration)
            $newTable[$newTablename] = [
                'tabletype' => 'main' ,
                'tablename' => $newTablename ,
                'maintable' => $newTablename ,
                'unique' => $defUnique ,
                'fields' => [ $defUnique => [] ] ,
                
            ];
            
            // tablenames for all 1:n and 1:m and n:m tables
            // define the name-order by creating new tablenames for related tables
            $aTabnames = [ $newTablename ];
            $tabNamesOrderPrim = $sqlCnf['iNamesOrderTableField']; // 0 = tablename_fieldname, 1 = fieldname_tablename
            $tabNamesOrderSec = ( $tabNamesOrderPrim - 1 ) * (-1);
            
            // append the rest of fields to maintable
            $fieldUsage = [];
            foreach( $aTablesDefinition as $fieldname => $aFieldDef ){
                
                if( $aFieldDef['tabletype'] == 'main' ) {
                    $newTable[$newTablename]['fields'][$aFieldDef['fieldname']] = [
                        'tabletype' => 'main',
                        'tablename' => $newTablename,
                        'maintable' => $newTablename,
                        'fieldname' => $aFieldDef['fieldname'] ,
                        'position' => $aFieldDef['position'],
                        'type'   => $aFieldDef['typ'],
                        'length' => $aFieldDef['maxZeichen'],
                        'notnullable' => $aFieldDef['notnullable'],
//                         'notnullable' => empty($aFieldDef['leereZellen']) ? 1 : 0,
                        'comment' => $aFieldDef['comment']
                    ];
                    if( isset($aFieldDef['source']) ) $newTable[$newTablename]['fields'][$aFieldDef['fieldname']]['source'] = $aFieldDef['source'];
                    if( isset($aFieldDef['increase']) ) $newTable[$newTablename]['fields'][$aFieldDef['fieldname']]['increase'] = $aFieldDef['increase'];
                    
                }else{
                
                    // create definitions for 1:n table
                    $aTabnames[1] = $this->uniquizeFieldname( $this->sanitizeFieldname( $aFieldDef['possibleNewFieldname'] , $sqlCnf['bTableNamesConcatCamelCase'] , $sqlCnf['bTableNamesLowercase'] , $sqlCnf['bTableNamesUppercaseFirst'] ) , $fieldUsage , $sqlCnf['sNameDefaultUniqueKey'] ) ;
                    $fieldUsage[$aTabnames[1]] = $aTabnames[1];
                    $nameOfForeignTable = $aTabnames[$tabNamesOrderPrim] . $sqlCnf['sTableSeparer1n'] . $aTabnames[$tabNamesOrderSec];
                    
                    if( $sqlCnf['bPrependOrAppendFieldnameToKey'] == 1 ){
                        $rawForeignKeyname = $aFieldDef['fieldname'] . ' ' . $this->settings['sql_config']['sNameDefaultUniqueKey'];
                    }elseif( $sqlCnf['bPrependOrAppendFieldnameToKey'] == 2 ){
                        $rawForeignKeyname = $this->settings['sql_config']['sNameDefaultUniqueKey'] . ' ' . $aFieldDef['fieldname'];
                    }else{
                        $rawForeignKeyname = $this->settings['sql_config']['sNameDefaultUniqueKey'];
                    }
                    $foreignKeyname = $this->uniquizeFieldname( $this->sanitizeFieldname( $rawForeignKeyname , $sqlCnf['bFieldNamesConcatCamelCase'] , $sqlCnf['bFieldNamesLowercase'] , $sqlCnf['bFieldNamesUppercaseFirst'] ) , $fieldUsage , '' ) ;
                    
                    if( $aFieldDef['tabletype'] == '1n' ){
                        
                        $newTable[$newTablename]['fields'][$aFieldDef['fieldname']] = [
                            'tabletype' => 'main',
                            'tablename' => $newTablename,
                            'maintable' => $newTablename,
                            'fieldname' => $aFieldDef['fieldname'] ,
                            'source'    => $aFieldDef['source'],
                            'position'  => $aFieldDef['position'],
                            'relType'   => '1n',
                            'foreignTablename' => $nameOfForeignTable,
                            'foreignKeyname' => $foreignKeyname,
                            'type'   => 'int',
                            'length' => 11,
                            'notnullable' => $aFieldDef['notnullable'],
                            //'notnullable' => empty($aFieldDef['leereZellen']) ? 1 : 0 ,
                            'comment' => $aFieldDef['comment']
                        ];
                        
                        $newTable[$nameOfForeignTable] = [
                            'tabletype' => '1n',
                            'tablename' => $nameOfForeignTable,
                            'maintable' => $newTablename,
                            'fieldname' => $aFieldDef['fieldname'] ,
                            'keyname'   => $foreignKeyname,
                            'source'    => $aFieldDef['source'],
                            'position' => $aFieldDef['position'],
                            'type'     => $aFieldDef['typ'],
                            'length'   => $aFieldDef['maxZeichen'],
                            'notnullable' => 1 ,
                            'comment' => $aFieldDef['comment']
                        ];
                    }elseif( $aFieldDef['tabletype'] == '1m' ){
                        // create name for n:m table
                        $nameOfNmTable = $aTabnames[$tabNamesOrderPrim]. $sqlCnf['sTableSeparerNm'] . $aTabnames[$tabNamesOrderSec];
                        
                        $newTable[$nameOfForeignTable] = [
                            'tabletype' => '1m',
                            'tablename' => $nameOfForeignTable,
                            'maintable' => $newTablename,
                            'childTablename' => $nameOfNmTable,
                            'fieldname' => $aFieldDef['fieldname'] ,
                            'keyname' => $foreignKeyname,
                            'source' => $aFieldDef['source'],
                            'position' => $aFieldDef['position'],
                            'separer' => $aFieldDef['separer'],
                            'type'   => $aFieldDef['typ'],
                            'length' => $aFieldDef['maxZeichen'],
                            'notnullable' => 1,
                            'comment' => $aFieldDef['comment']
                        ];
                        
                        // create definitions for n:m table
                        $newTable[$nameOfNmTable] = [
                            'tabletype' => 'nm',
                            'tablename' => $nameOfNmTable,
                            'maintable' => $newTablename,
                            'fieldname' => $aFieldDef['fieldname'] ,
                            'source' => $aFieldDef['source'],
                            'localTablename' => $newTablename,
                            'localUid' => $defUnique ,
                            'foreignTablename' => $nameOfForeignTable,
                            'foreignKeyname' => $foreignKeyname ,
                        ];
                    }
                }
            }
            return $newTable;
    }

    /**
     * uniquizeFieldname
     *  make fieldname unique by appending a trailing number
     *  returns valid fieldname
     *
     * @param string $fieldname needle
     * @param array $aPool haystack
     * @param string $lockUid optional the name of default unique-key, if set then it will be added to the pool
     * @return string renamed fieldname
     */
    Private function uniquizeFieldname( $fieldname , $aPool , $lockUid = '' )
    {
        // Lock 'index': Prevent the usage of fieldname 'index' or similar (uppercase, ucFirst etc.)
        if( strtolower($fieldname) == 'index' ) $aPool[$fieldname] = 1;
        
        // Add special fieldname of unique-key to lock
        if( !empty($lockUid) ) $aPool[$lockUid] = 1;
        
        // if not locked, return fieldname as valid
        if( !isset($aPool[$fieldname]) ) return $fieldname;
        
         // Set new counter to 1 as default - ca be overwritten
        $newCounter = 1;
         // Search for last appearence of underscore or similar: sNamesCounterSeparer is like '_' followed by a number
        $posOfSeparer = strrpos( $fieldname , $this->settings['sql_config']['sNamesCounterSeparer'] );
        if( $posOfSeparer ){
            $lastChars = substr( $fieldname , $posOfSeparer+1 );
            if( is_numeric($lastChars) && is_integer($lastChars) ) {
                $newCounter = $lastChars;
                $fieldname = substr( $fieldname , 0 , $posOfSeparer );
            }
        }
        // Rename the fieldname by appending suffix with counter
        $newFieldname = $fieldname . $this->settings['sql_config']['sNamesCounterSeparer'] . $newCounter;
        
        // Function calls itself recursively
        return $this->uniquizeFieldname( $newFieldname , $aPool , $lockUid );
    }

    /**
     * sanitizeFieldname
     *  get rid of spaces, umlauds and uppercase
     *
     * @param string $fieldname
     * @param boolean $bNamesConcatCamelCase
     * @param boolean $bNamesLowercase
     * @param boolean $bNamesUppercaseFirst
     * @return void
     */
    Private function sanitizeFieldname( $fieldname , $bNamesConcatCamelCase , $bNamesLowercase , $bNamesUppercaseFirst )
    {
			// lowercase as default
			if( $bNamesLowercase ) $fieldname = strtolower( $fieldname );
			if( $bNamesUppercaseFirst ) $fieldname = ucFirst( $fieldname );
			
			// replace blank with lowerCamelCase
			if( $bNamesConcatCamelCase ){
                $aAtoms = explode( ' ' , $fieldname );
                $fieldname = $aAtoms[0];
                for( $z=1 ; $z < count($aAtoms) ; ++$z ){
                    $fieldname .= ucFirst($aAtoms[$z]);
                }
			}
			
			// replace blank with underscore and special chars to unicode
			$sr = [];
            $sr['replace'] = $this->settings['sql_config']['searchChrRepString'];
			foreach( array_keys($this->settings['sql_config']['searchChrRepString']) as $unicodeNr ) $sr['search'][$unicodeNr] = chr($unicodeNr);
			$fieldname = str_replace(  $sr['search'] , $sr['replace'] , $fieldname );
			return $fieldname;
			
			// replace unknown chars with underscore
            $aAsciiRanges = $this->settings['sql_config']['searchRepAsciiRanges'];
            foreach( $aAsciiRanges as $start => $end ){
                for( $x = $start ; $x <= $end ; ++$x ) $aAllowedChrs[$x] = chr($x);
            }
            
            $newName = '';
            for( $pos = 0 ; $pos <= strlen($fieldname) ; ++$pos ){
                    $chr = substr( $fieldname , $pos , 1 );
                    $newName .= isset($aAllowedChrs[ord($chr)]) ? $chr : '_';
            }
			
			$newName = str_replace(  '__' , '_' , str_replace(  '__' , '_' , str_replace(  '__' , '_' , str_replace(  '__' , '_' , $newName ) ) ) );
			
			return $newName;
    }

    /**
        * compareFields
        * detectConflicts in fields
        *  return tabel-fieldSets $aFieldDefaults containing fields exisiting in file but not in database
        *
        * @param array $aFieldDefaults db fields
        * @param array $usedTablenames excel fields
        * @return int
        */
    Private function compareFields(  $aFieldDefaults , $usedTablenames  )
    {
                foreach( $aFieldDefaults as $tablename => $aFieldsDef ){
                    $error = 0;
                    if( isset( $usedTablenames[$tablename] ) ){
                        if( is_array($usedTablenames[$tablename]['fields']) && $usedTablenames[$tablename]['tabletype'] == 'main' ){
                                foreach( array_keys($usedTablenames[$tablename]['fields']) as $fieldName ){
                                    if( !isset($aFieldsDef[$fieldName]) ){
                                        ++$error;
                                        $this->errors[] = ' Feld "' . $tablename . '.' . $fieldName . '" fehlt in der Datenbank';
                                    }
                                }
                        }elseif(  $usedTablenames[$tablename]['tabletype'] == '1n' || $usedTablenames[$tablename]['tabletype'] == '1m' ){
                                if( !isset($aFieldsDef[$usedTablenames[$tablename]['fieldname']]) ){
                                    ++$error;
                                    $this->errors[] = ' Feld "' . $tablename . '.' . $usedTablenames[$tablename]['fieldname'] . '" fehlt in der Datenbank';
                                }
                        }elseif(  $usedTablenames[$tablename]['tabletype'] != 'nm' ){
                                ++$error;
                                $this->errors[] = 'Tabelle "' . $tablename . '" fehlt in der Datenbank';
                        }
                    }
                    // some fields exisiting in file but not in database
                    // mark the whole table as invalid
                    if($error) continue;
                    
                    $compared = 0;
                    foreach( $aFieldsDef as $fieldName => $fldDef ){
                        switch( $usedTablenames[$tablename]['tabletype'] ){
                            case 'main':
                                // Compare only fieldname (disabled):
                                // if( isset( $usedTablenames[$tablename]['fields'][$fieldName] ) ) ++$compared;
                                
                                // Compare fieldname AND type (enabled):
                                if( isset( $usedTablenames[$tablename]['fields'][$fieldName] ) &&
                                   $usedTablenames[ $tablename ]['fields'][ $fieldName ]['type'] == $aFieldDefaults[ $tablename ][ $fieldName ]['DATA_TYPE']
                                ){
                                    ++$compared;
                                }else{
                                    $this->errors[] = 'Datentyp des Felds "' . $tablename . '.' . $fieldName . '" ist in der Datei "' . $usedTablenames[ $tablename ]['fields'][ $fieldName ]['type'] . '", aber in der Datenbank "' . $aFieldDefaults[ $tablename ][ $fieldName ]['DATA_TYPE'] . '"';
                                }
                                
                            break;
                            case '1n':
                            case '1m':
                                if( $usedTablenames[$tablename]['keyname'] == $fieldName || $usedTablenames[$tablename]['fieldname'] == $fieldName ) {
                                    ++$compared;
                                }else{
                                    $this->errors[] = 'Feld "' . $tablename . '.' . $fieldName . '" fehlt in der Datei';
                                }
                            break;
                            case 'nm':
                                 ++$compared;
                            break;
                        }
                    }
                    if( $compared == count($aFieldsDef) ) unset($aFieldDefaults[$tablename]);
                }
                return $aFieldDefaults;
    }

    /**
        * detectConflictStatusNr
        * when stateId is < 10 then no tables, else some tables existing
        * 0 = no connection
        * 1 = ok import in empty db
        * 10 = no import tablename-conflicts with table(s) "tablename1 , name2"
        * 11 = ok import althought some other tables existing
        * 12 = try to syncronyze
        * 20 = no sync cause field(s) not matching in [1|n] table(s)
        * 21 = ok sync
        *
        * @param array $dbData
        * @param array $usedTablenames
        * @return int
        */
    Private function detectConflictStatusNr(  $dbData , $usedTablenames  )
    {
            if( !$dbData['countAllTables'] ){ // no tables existing but connection is ok
                 $statusInfo = 1;
                 
            }elseif( count($dbData['fieldDefinition']) == count($usedTablenames) ) { // ok: all affored tables existing
                $aFieldDefaults = $this->compareFields(  $dbData['fieldDefinition'] , $usedTablenames  );
                $listConflictTables = count($aFieldDefaults) ? implode( ', ' , array_keys($aFieldDefaults)) : '';
                $statusInfo = !count($aFieldDefaults) ? 12 : 20;
                
            }elseif( !count($dbData['fieldDefinition']) ){ // ok: only other tables existing
                $statusInfo = 11;
                
            }else{ // error: only some of the tables existing
                $statusInfo = 10;
            }
            return $statusInfo;
    }

    /**
        * getConflictMessage
        *
        * @param array $aConflictInfo
        * @return string
        */
    Private function getConflictMessage(  $aConflictInfo  )
    {
			
            $text = count($aConflictInfo['usedTables']) == 1 ? 'Tabelle "' . array_shift(array_keys($aConflictInfo['usedTables'])) . '"' : count($aConflictInfo['usedTables']) . ' Tabellen';
			
			$title = '<h4 title="' . implode( ', ' , array_keys($aConflictInfo['usedTables']) ) . '">Import von ' . $text . '</h4>';
			
			$span = '<span class="state_' . $aConflictInfo['stateId'] . '">';
			
			switch( $aConflictInfo['stateId'] ){
                case 0:
                        return $title . $span . 'Keine Datenbankverbindung.</span>' ; // goBack
                    break;
                case 1:
                        return $title . $span . 'Die Datenbank »' . $aConflictInfo['dbname'] . '« ist leer und bereit zum Import der ' . $text . ' ...</span>'; // fwdImport or goBack
                    break;
			}
			
			
			$dbTableStatus = $aConflictInfo['countAllTables'] . ' Tabellen in Datenbank »' . $aConflictInfo['dbname'] . '« gefunden.<br> ';
			
			switch( $aConflictInfo['stateId'] ){
                case 10:
                        $span = '<span class="attention state_' . $aConflictInfo['stateId'] . '"> ';
                        if( $aConflictInfo['listConflictTables'] ) {
                            $msg = 'Es bestehen Konflikte mit vorhandenen Tabellen:</span> ' . $aConflictInfo['listConflictTables'] . '. '; // delete-db-table or goBack
                        }else{
                            $msg = 'Die Tabellen stimmen nicht überein, nötige Tabellen:</span> ' . implode( ', ' , array_keys($aConflictInfo['usedTables']) ) . '. '; // delete-db-table or goBack
                        }
                    break;
                case 20:
                        $span = '<span class="attention state_' . $aConflictInfo['stateId'] . '"> ';
                        $msg = 'Die Feldnamen stimmen nicht überein...</span> ' . $aConflictInfo['listConflictTables'] . ' '; // delete-db-table or goBack
                    break;
                case 11:
                        $msg = 'Keine Konflikte mit vorhandenen Tabellen.</span>'; // fwdImport or delete-db-table or goBack
                    break;
                case 12;
                        $span = '<span title="' . implode( ', ' , array_keys($aConflictInfo['usedTables']) ) . '" class="info state_' . $aConflictInfo['stateId'] . '"> ';
                        $msg = 'Die Tabellen bestehen alle</span>, die Daten können abgeglichen werden.'; // fwdSync or delete-db-table or goBack
                    break;
                default:
                        $msg = 'Keine Datenbank gefunden.</span>';
			}
            if( count($this->errors) ) $msg .= '<i>' . implode( ', ' , $this->errors ) . '</i>.';
			return trim( $title . $dbTableStatus . ' ' . $span . $msg ) . ' ' ;
    }

    /**
        * collectDataForMainView
        *
        * @param array $aUsedTablenames dim4array[ subtable_name ][ tabletype => 'main' , ... , childTablename => 'subtable_nm_name' , fields => [ fldNam => [ source => 'FIELDNAME'  ] ] ]
        * @return array
        */
    Public function collectDataForMainView( $aUsedTablenames )
    {
            foreach( $aUsedTablenames as $loopTablename => $tableDef ){
                if( $loopTablename == $tableDef['maintable'] ){
                        $centralTable = $loopTablename;
                        $mainKey = $tableDef['unique'];
                        foreach( $tableDef['fields'] as $loopFldNam => $fieldsDef ){
                            $viewDef['fields'][$fieldsDef['position']]['fieldname'] = $loopFldNam;
                            if( isset($fieldsDef['foreignTablename']) ){
                                $viewDef['fields'][$fieldsDef['position']]['tablename'] = $fieldsDef['foreignTablename'] ;
                                $viewDef['fields'][$fieldsDef['position']]['foreignKeyname'] = $fieldsDef['foreignKeyname'] ;
                            }else{
                                $viewDef['fields'][$fieldsDef['position']]['tablename'] = $fieldsDef['tablename'];
                            }
                        }
                }elseif( isset($tableDef['childTablename'])){ // 1m table
                        ksort( $tableDef['separer'] );
                        $sFirstSeparer = array_shift($tableDef['separer']);
                        $viewDef['fields'][$tableDef['position']] = [ 'separator'=> $sFirstSeparer , 'childTablename'=> $tableDef['childTablename'] , 'foreignKeyname'=> $tableDef['keyname'] , 'fieldname'=> $tableDef['fieldname'], 'tablename'=>$tableDef['tablename'] ];
                }
            }
            $viewDef['unique'] =  $mainKey ;
            $viewDef['maintable'] =  $centralTable ;
            
            if( is_array($viewDef['fields']) ) ksort($viewDef['fields']);
            return $viewDef;
            
    }
 
}
