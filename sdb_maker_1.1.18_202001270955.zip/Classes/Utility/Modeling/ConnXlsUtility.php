<?php
namespace Sfgz\SdbMaker\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2019 Daniel Rueegg <colormixture@verarbeitung.ch>,
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class ConnXlsUtility
 * 
 */

class ConnXlsUtility implements \TYPO3\CMS\Core\SingletonInterface
{

    /**
        * fileNames
        *
        * @var array
        */
    Public $fileNames = null;

    /**
        * fileSuffixes
        *
        * @var array
        */
    protected $fileSuffixes = [ 'xlsx' , 'ods' ];

    /**
        * fileFieldname
        *
        * @var string
        */
    protected $fileFieldname = 'csv_table';

    /**
        * uploadpath
        *
        * @var string
        */
    protected $uploadpath = 'uploads/tx_sdbmaker';

    /**
        * tableMarker
        *
        * @var string
        */
    protected $tableMarker = null;

    /**
        * spreadsheetUtility
        *
        * @var \Sfgz\SfgzFetools\Utility\SpreadsheetUtility
        */
    protected $spreadsheetUtility = null;

    /**
        * initializeAction
        *
        */
    Public function __construct()
    {
            $this->spreadsheetUtility = GeneralUtility::makeInstance('Sfgz\\SfgzFetools\\Utility\\SpreadsheetUtility');
    }

    /**
        * initiateSettings
        *
        * @param string $trailingPathSequence eg. pluginUid
        * @return void
        */
    Public function appendToUploadPath( $trailingPathSequence )
    {
           $uploadpath = trim( $this->uploadpath , '/' ) . '/' . trim( $trailingPathSequence , '/' );
           $rootDirectory = rtrim( realpath('') , '/' ) . '/';
           $displayDirectory = GeneralUtility::getFileAbsFileName( $rootDirectory . $uploadpath );
           if( !is_dir($displayDirectory) && is_dir( $rootDirectory . $this->uploadpath ) ) mkdir($displayDirectory);
           $this->uploadpath = $uploadpath;
    }

    /**
        * dispatchJobs
        *
        * @param array $submit array[ delete | upload | download | selected ] = filename;
        * @return array
        */
    Public function dispatchJobs( $submit )
    {
            $isUpload = null;
            
            $this->fileNames = $this->readFilesInDir( $this->uploadpath );
            
            // dispatch jobs
            if( isset( $submit['delete'] ) ) {
                $this->fileHandler_delete( $submit['delete'] );
                // remove this file from list after deletion. 
                if( isset($this->fileNames[ $submit['delete'] ]) ) unset( $this->fileNames[ $submit['delete'] ] );

            }elseif( isset( $submit['upload'] ) ) {
                $uploadedFile = $this->fileHandler_upload();
                // reload filelist after successful upload
                if($uploadedFile) $this->fileNames = $this->readFilesInDir( $this->uploadpath );
                $isUpload = $this->markFile( pathinfo( $uploadedFile , PATHINFO_BASENAME ) );
            }
            
            // detect selected file and set as marked
            if($isUpload) {
                $submit['selected'] = $isUpload;
                
            }elseif( isset( $submit['download'] ) ) {
                $submit['selected'] = $this->markFile( $submit['download'] );
                
            }elseif( isset( $submit['selected'] ) ) {
                    $submit['selected'] = $this->markFile( $submit['selected'] );
            }
            
            return $submit;
    }

    /**
        * readData
        *   detect total records, total fields
        *   each field: max-field-length, amount of empty values, amount of different values without empty (groups) , max in group (biggest group)
        *
        * @param string $encodeCharset
        * @return array
        */
    Public function readData( $encodeCharset = 'utf8' )
    {
            if( !$this->fileNames ) $this->fileNames = $this->readFilesInDir( $this->uploadpath );
            $aTableRecords = [];
            
            if( $this->tableMarker && isset($this->fileNames[ $this->tableMarker ]) ){
                    $aTableRecords[ $this->tableMarker ] = $this->readRecords( $this->fileNames[ $this->tableMarker ]['path'] );
            }else{
                    foreach( $this->fileNames  as $tablename => $fileInfo ){
                        $aTableRecords[ $tablename ] = $this->readRecords( $fileInfo['path'] );
                    }
            }
            return $this->readEnd( $aTableRecords , $encodeCharset );

    }

    /**
        * exportTables
        * export to xslx or csv
        *
        * @param array $aResult
        * @param string $filename including suffix eg. myDocument.xlsx or myTable.csv
        * @return void
        */
    Public function exportTables( $aResult , $filename )
    {
            
            $prependColumnNames = true;
            $this->spreadsheetUtility->arrayToSpreadSheet( $aResult ,  $filename , $prependColumnNames );
            // at this point the download should be started, the method above forces the exit for PHP.
            return true;
    }

    /**
        * readFilesInDir
        *
        * @param string $dirname
        * @return array
        */
    Protected function readFilesInDir( $dirname )
    {
            $aFileInfo = [];
            if( empty($dirname) ) return $aFileInfo;
            
            // get all files in dir
            $typo3DocumentRoot = rtrim( realpath('') , '/' ) . '/';
            $displayDirectory = rtrim( GeneralUtility::getFileAbsFileName( $typo3DocumentRoot . trim($dirname) ) , '/' );

            // get all files in dirs and store filePathName in an array with filenames as keys
            
            foreach ( $this->fileSuffixes as $aExtName ) {
                $aExtFil =  glob( $displayDirectory . '/*.' . $aExtName );
                if( !is_array($aExtFil) ) continue;
                foreach ( $aExtFil as $filename ) {
                    $basename = pathinfo( $filename , PATHINFO_BASENAME );
                    if( trim($basename) != '' && filetype($filename) == 'file' ) {
                        $aFileInfo[$basename]['path'] = $dirname . '/' . $basename ;
                        $aFileInfo[$basename]['date'] = filectime($filename) ;
                        $aFileInfo[$basename]['size'] = round( filesize($filename) / 1000 , 3 );
                    }
                }
            }
            
            return $aFileInfo;
    }

    /**
        * markFile
        *
        * @param string $fileName
        * @return string
        */
    Protected function markFile( $fileName )
    {
            $this->tableMarker = $fileName && isset($this->fileNames[ $fileName ]) ? $fileName : null ;
            return $this->tableMarker;
    }


    /**
        * readRecords
        *
        * @param string $filePathName
        * @return array
        */
    Protected function readRecords( $filePathName )
    {
            $prependHeadrow = true; 
            $aRecords = $this->spreadsheetUtility->spreadsheetToArray( $filePathName , $prependHeadrow ) ;
            if( !is_array($aRecords) || !count($aRecords) ) return [];
            return $aRecords;
    }

    /**
        * readEnd
        * render data and/or close connection
        * flattenate 3-dim array to 2-dim array
        *
        * @param array $aSpreadSheets
        * @param string $encodeCharset
        * @return void
        */
    Protected function readEnd( $aSpreadSheets , $encodeCharset )
    {
            if( $this->arrayDepth($aSpreadSheets) == 3 ) return $this->decodeArray($aSpreadSheets , $encodeCharset);
            
            $aTableRecords = [];
            foreach( $aSpreadSheets as $tablename => $aSpreadSheets ){
                foreach( $aSpreadSheets as $sheetName => $sheetBody ) $aTableRecords[  $sheetName ] = $sheetBody;
            }

            return  $this->decodeArray($aTableRecords , $encodeCharset );
    }

    /**
     * decodeArray
     *  sheets are utf8
     *  utf8_decode Converts a string with ISO-8859-1 characters encoded with UTF-8 to single-byte ISO-8859-1 
     *
     * @param array $aEcoded
     * @param string $encodeCharset
     * @return array
     */
    Private function decodeArray( $aEcoded , $encodeCharset )
    {
            if( empty($encodeCharset) || strtolower( $encodeCharset ) == 'utf8' ) return $aEcoded;
            
            $aDecoded = [];
            foreach( $aEcoded as $sheetname => $aTable ){
                foreach( $aTable as $ix => $row ){
                    foreach( $row as $field => $chars ) {
                        $aDecoded[$sheetname][$ix][$field] = $this->decodeString( $chars , $encodeCharset );
                    }
                }
            }
            return $aDecoded;
    }

    /**
     * decodeString
     *
     * @param string $sEcoded
     * @param string $encodeCharset
     * @return array
     */
    Private function decodeString( $sEcoded , $encodeCharset )
    {
            if( empty($sEcoded) || is_numeric($sEcoded) ) return $sEcoded;
            
            $newValue =  iconv( 'utf8' , $encodeCharset , $sEcoded );
            
            if( empty($newValue) ){
                $newValue = utf8_decode($sEcoded);
            }

            if( empty($newValue) ) return $sEcoded;
            
            return $newValue;
    }

    /**
        * arrayDepth
        *  evaluates the dimensions of a given array
        *
        * @param array $aGivenArray
        * @param int $deep default starts with 0
        * @param int $maxLoops default loops maximal 4 times
        * @return void
        */
    Private function arrayDepth( $aGivenArray , $deep = 0 , $maxLoops = 6 )
    {
        if( !is_array($aGivenArray) || $deep >= $maxLoops ) return $deep;
        foreach( $aGivenArray as $key => $voidContent ) return $this->arrayDepth( $voidContent , $deep +1 );
    }

    /**
        * fileHandler_delete
        *
        * @param string $uploadPathFileName
        * @return boolean
        */
    Protected function fileHandler_delete( $uploadPathFileName = '' )
    {
            $displayDirectory =  rtrim( GeneralUtility::getFileAbsFileName( rtrim( realpath('') , '/' ) . '/' . $this->uploadpath ) , '/' );
            if( !is_dir($displayDirectory) ) return false;
            if( !file_exists($displayDirectory . '/' . $uploadPathFileName) ) return false;
            @unlink( $displayDirectory . '/' . $uploadPathFileName );
                return true;
    }

    /**
        * fileHandler_upload
        *
        * @return string with /relativePath/filename.suffix OR false
        */
    Protected function fileHandler_upload()
    {
            // is any upload-action given?
            if( 
                !isset($_FILES['tx_sdbmaker_model']['tmp_name'][ 'file' ][$this->fileFieldname]) || 
                empty($_FILES['tx_sdbmaker_model']['tmp_name'][ 'file' ][$this->fileFieldname]) || 
                empty($_FILES['tx_sdbmaker_model']['name'][ 'file' ][$this->fileFieldname]) 
            ) return false;

            $fileName = $_FILES['tx_sdbmaker_model']['name'][ 'file' ][$this->fileFieldname];
            
            // is suffix allowed?
            $suffix = strtolower( pathinfo( $fileName , PATHINFO_EXTENSION ) );
            if( !in_array( $suffix , $this->fileSuffixes ) ) return false;

            // is upload-path defined?
            $typo3DocumentRoot = rtrim( realpath('') , '/' );
            $uploadPath = rtrim( $this->uploadpath , '/' );
            $displayDirectory = GeneralUtility::getFileAbsFileName( $typo3DocumentRoot . '/' . $uploadPath );
            if( !is_dir($displayDirectory) ) return false;
            
            
            if( file_exists( $displayDirectory . '/' . $fileName ) ) @unlink($displayDirectory . '/' . $fileName);
            $res = GeneralUtility::upload_copy_move( $_FILES['tx_sdbmaker_model']['tmp_name'][ 'file' ][$this->fileFieldname] , $displayDirectory . '/' . $fileName );
            if( $res ) return $uploadPath . '/' . $fileName;
            return false;
    }
    
} 
