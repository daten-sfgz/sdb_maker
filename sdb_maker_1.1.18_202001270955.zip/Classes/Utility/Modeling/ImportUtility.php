<?php
namespace Sfgz\SdbMaker\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2019 Daniel Rueegg <colormixture@verarbeitung.ch>,
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class ImportUtility
 * 
 */

class ImportUtility implements \TYPO3\CMS\Core\SingletonInterface
{

    /**
     * sqlStatements
     *
     * @var array
     */
    Public $sqlStatements = null;

    /**
     * dbName
     *
     * @var string
     */
    protected $dbName = null;

    /**
     * sqlUtility
     *
     * @var \Sfgz\SdbMaker\Utility\SqlStandaloneUtility
     */
    protected $sqlUtility = null;

    /**
        * settings
        *
        * @var array
        */
    protected $settings = null;
    
    /**
        * initiateSettings
        *  affored is settings: sql_config ! dbname and pluginUid
        *
        * @param array $settings
        * @return void
        */
    Public function initiateSettings( $settings )
    {
			$this->settings = $settings;

            $getSqlUtility = GeneralUtility::makeInstance('Sfgz\\SdbMaker\\Utility\\GetSqlUtility');
            $this->sqlUtility = $getSqlUtility->getSqlClass($settings['pluginUid']);

			if( !$this->sqlUtility ) return false;
			
			return true;
    }

    /**
     * deleteTable
     *
     * @param string $dbname
     * @param string $tablename
     * @return void
     */
    Public function deleteTable( $dbname , $tablename )
    {
        if( !$this->sqlUtility ) return 'Keine Datenbank Verbindungen möglich';
        $connected = $this->sqlUtility->connectToDatabase( $dbname );
        if( !$connected )  return 'Keine Verbindung zur Datenbank "' . $dbname . '" möglich';
        
        $result = $this->sqlUtility->execQuery( 'DROP TABLE ' . $tablename . ';' );
        if( !$result ) $result = $this->sqlUtility->execQuery( 'DROP VIEW ' . $tablename . ';' );
        
        $this->sqlUtility->closeDatabase();
        return $result;
    }

    /**
     * getSqlToCreateTables
     *
     * @param string $dbname
     * @param array $aTables tables structure of main table with related tables
     * @return array
     */
    Public function getSqlToCreateTables( $dbname , $aTables )
    {
        if( !$this->sqlUtility ) return 'Keine Datenbank Verbindungen möglich';
        if( !is_array($aTables) || !count($aTables) ) return 'Keine Tabellendefinition';
        
        $this->dbName = $dbname;
        
        $aText = [];
        foreach( $aTables as $tableDef ){
            if( $tableDef['tabletype'] == '1n' || $tableDef['tabletype'] == '1m' ) $aText[$tableDef['tablename']] = $this->getSqlToCreateSiblingTable( $tableDef );
        }
        foreach( $aTables as $tableDef ){
            if( $tableDef['tabletype'] == 'main' ) $aText[$tableDef['tablename']] = $this->getSqlToCreateMainTable( $tableDef );
        }
        foreach( $aTables as $tableDef ){
            if( $tableDef['tabletype'] == 'nm' ) $aText[$tableDef['tablename']] = $this->getSqlToCreateChildTable( $tableDef );
        }
        return $aText ;
    }

    /**
     * execMultipleQueries
     *
     * @param string $dbname
     * @param string $sqlText
     * @return void
     */
    Public function execMultipleQueries( $dbname , $sqlText )
    {
        $aSqlTexts = explode( ';' , trim($sqlText,';') );
        $result = 1;
        foreach( $aSqlTexts as $stat ) {
            $result = $result && $this->sqlUtility->execQuery( $stat ) ? 1 : 0;
        }
        return $result;
    }

    /**
     * readStart
     *
     * @param string $dbname
     * @return void
     */
    Public function readStart( $dbname )
    {
        if( !$this->sqlUtility ) return 'Keine Datenbank Verbindungen möglich';
        $connected = $this->sqlUtility->connectToDatabase( $dbname );
        if( !$connected )  return 'Keine Verbindung zur Datenbank "' . $dbname . '" möglich';
        return 1;
    }

    /**
        * importIntoParentTables
        * returns inserted values for later use
        *   
        *   $aRelationalTablesIndex[Bibo_Signatur]['separer'] => Array( [2]=>';' , [1]=>',' )
        *   $aRelationalTablesIndex[Bibo_Signatur]['data'] => Array( [KUN:310] => 1 , [KUN:Jetti] => 2 , [KUN:Architektur] => 3 , ...)
        *
        * @param array $aUsedTablenames
        * @param array $aRelatedTableData
        * @return array
        */
    Public function importIntoParentTables( $aUsedTablenames , $aRelatedTableData )
    {
            $importDB = [];
            if( !count($aUsedTablenames) ) return $importDB;
            
            $aRelationalTablesIndex = [];
            foreach( $aUsedTablenames as $tablename => $tabDef ){
                if( substr( $tabDef['tabletype'] , 0 , 1 ) != '1' ) continue; // we need only 1n and 1m
                if( !isset($aRelatedTableData[ $tabDef['source'] ]['data']) || !count($aRelatedTableData[ $tabDef['source'] ]['data']) ) continue;
                
                $this->resetAutoIncrement( $tablename , $tabDef['keyname'] );

                // insert in database here
                $aInAndNot = $this->createAndGetUidFromRelTableByFieldContent( $tablename , $tabDef['fieldname'] , $tabDef['keyname'] , $aRelatedTableData[ $tabDef['source'] ]['data'] );
                
                // collect result and add separer to output
                $aRelationalTablesIndex[$tablename]['data'] = $aInAndNot['isInTable'];
                if( isset($aRelatedTableData[ $tabDef['source'] ]['separer']) ) $aRelationalTablesIndex[$tablename]['separer'] = $aRelatedTableData[ $tabDef['source'] ]['separer'];
            }

            return $aRelationalTablesIndex;
    }

    /**
        * importIntoMainTable
        *
        * @param array $aFieldRecord mixed dim3 and dim4 dim3array['main'][nextUid][newFieldName] , dim4array['nm'][childTablename][nextUid][foundIndex] = foundIndex;
        * @param array $aUsedTablenames dim4array[ subtable_name ][ tabletype => 'main' , ... , childTablename => 'subtable_nm_name' , fields => [ fldNam => [ source => 'FIELDNAME'  ] ] ]
        * @return array
        */
    Public function importIntoMainTable( $aFieldRecord , $aUsedTablenames )
    {
            $aCfg = $aUsedTablenames;
            $aFirst = array_shift(array_keys($aCfg)); // get the first random table 
            $mainTableName = $aUsedTablenames[$aFirst]['maintable']; // get name of maintable from random table
            $aFieldConfig = $aUsedTablenames[$mainTableName]; // get all field configs from maintable
            $mainUniqueKey = $aFieldConfig['unique']; // get unique key from maintable's config
            
            $this->resetAutoIncrement( $mainTableName , $mainUniqueKey );
            foreach( $aFieldRecord['main'] as $nextUid => $row ){
                    // insert recordset one by one into main-table
                    $createdIndex = $this->createAndGetUidFromMainRecord( $mainTableName , $row , $mainUniqueKey);
                    if( $createdIndex ) $aNewIndex[$nextUid] = $createdIndex;
            }
            // insert all records at once for each nm table
            if( !isset( $aFieldRecord['nm'] ) ) return false;
            foreach( $aFieldRecord['nm'] as $sSubtableName => $row ){
                    $aLocalAndForeignUids = [];
                    foreach( $row as $nextUid => $aForeignUids ){
                        if( isset($aNewIndex[$nextUid]) && is_array($aForeignUids) ){
                            $aLocalAndForeignUids[$aNewIndex[$nextUid]] = $aForeignUids;
                        }
                    }
                    $this->createMnRecords( $sSubtableName , $aLocalAndForeignUids );
            }
            
            return $aFieldRecord;
    }

    /**
        * collectDataForMainTableImport
        *
        * @param array $aTableRecords dim2array[n][ FIELDNAME ] = value
        * @param array $aRelationalTablesIndex  dim3array[ subtable_name ][ source => 'FIELDNAME' , fieldname => 'fieldname' ,  data => [ 'content' => uid ] , separer => [ ';' , ',' ] ]
        * @param array $aUsedTablenames dim4array[ subtable_name ][ tabletype => 'main' , ... , childTablename => 'subtable_nm_name' , fields => [ fldNam => [ source => 'FIELDNAME'  ] ] ]
        * @return array
        */
    Public function collectDataForMainTableImport( $aTableRecords , $aRelationalTablesIndex , $aUsedTablenames )
    {
            // remove first row with fieldnames
            array_shift($aTableRecords);
            
            $aFieldConfBySourcename = [];
            // $fldDef[ fieldname | tabletype | tablename | source | .. ]
            foreach( $aUsedTablenames as $tabDef ){
                if( $tabDef['tabletype'] == '1n' || $tabDef['tabletype'] == '1m' ) { // 1n and 1m tables, NO nm tables! (they would overwrite the key by same fieldname)
                    $aFieldConfBySourcename[ $tabDef['source'] ] = $tabDef ;
                }elseif( isset($tabDef['fields']) && is_array($tabDef['fields']) ){
                    foreach( $tabDef['fields'] as $newFieldName => $fldDef ){ if($fldDef['source']) $aFieldConfBySourcename[ $fldDef['source'] ] = $fldDef ; }
                }
            }

            $aFieldRecord = [];
            foreach( $aTableRecords as $nextUid => $row ){
                    foreach( $row as $origFieldNam => $content ) {
                    
                        if( empty($content) ) continue;
                        
                        // 1n fields appearing in two tables, in the maintable they have a relType attribute.
                        $tableType = $aFieldConfBySourcename[$origFieldNam]['relType'] ? $aFieldConfBySourcename[$origFieldNam]['relType'] : $aFieldConfBySourcename[$origFieldNam]['tabletype'];
                        
                        if($tableType == 'main'){
                            // main table, insert value from sheet
                            $newFieldName = $aFieldConfBySourcename[$origFieldNam]['fieldname'];
                            $aFieldRecord['main'][$nextUid][$newFieldName] = str_replace( "'" , "\'" , $content );
                            
                        }elseif($tableType == '1n'){
                            // 1:n find uid of foreign table and insert it in to this field
                            $fieldBelongsToTable = $aFieldConfBySourcename[$origFieldNam]['tablename'];
                            $newFieldName = $aFieldConfBySourcename[$origFieldNam]['fieldname'];
                            $foundIndex = $aRelationalTablesIndex[ $fieldBelongsToTable ]['data'][ trim($content) ];
                            if( $foundIndex ) $aFieldRecord['main'][$nextUid][$newFieldName] = $foundIndex;

                        }elseif($tableType == '1m'){
                            // 1:m find uid's of foreign table and create a array for later insertion
                            $fieldBelongsToTable = $aFieldConfBySourcename[$origFieldNam]['tablename'];
                            $aFieldSeparers = $aRelationalTablesIndex[ $fieldBelongsToTable ]['separer'] ;
                            $firtSeparer = array_shift( $aFieldSeparers );
                            $aCntAtoms = explode( $firtSeparer , str_replace( $aFieldSeparers , $firtSeparer , $content ) );
                            $childTablename = $aFieldConfBySourcename[$origFieldNam]['childTablename'];
                            foreach( $aCntAtoms as $word ){
                                    $foundIndex = $aRelationalTablesIndex[ $fieldBelongsToTable ]['data'][ trim($word) ];
                                    if( $foundIndex ) $aFieldRecord['nm'][$childTablename][$nextUid][$foundIndex] = $foundIndex;
                            }
                            
                        }
                    }
            }
            return $aFieldRecord;
    }

    /**
     * createView
     *
     * @param string $viewName
     * @param string $centralTable
     * @param string $mainKey
     * @param array $tableDef
     * @return void
     */
    Public function createView( $viewName , $centralTable , $mainKey , $tableDef )
    {
            $sqlPrepare = "DROP VIEW IF EXISTS `" . $viewName . "`; ";

            $sqlStat = "CREATE VIEW `" . $viewName . "` AS ";
            $sqlStat .= $this->sqlUtility->getSqlSelect( $centralTable , $mainKey , $tableDef );
            
            $this->sqlUtility->execQuery( $sqlPrepare );
            $result = $this->sqlUtility->execQuery( $sqlStat . ';' );
            
            return $sqlStat;
    }

    /**
     * readEnd
     *
     * @param mixed $output
     * @return void
     */
    Public function readEnd( $output = '' )
    {
        $this->sqlUtility->closeDatabase();
        return $output;
    }

    /**
     * createAndGetUidFromMainRecord
     *
     * @param string $tablename
     * @param array $aFieldContents
     * @param string $uniqueKeyname
     * @return integer
     */
    Private function createAndGetUidFromMainRecord( $tablename , $aFieldContents , $uniqueKeyname )
    {
            $existingUid = $this->getRecordByFieldContent( $tablename , $aFieldContents , $uniqueKeyname );
            if( $existingUid ) return false;
            
            // insert values in database maintable here
            $result = $this->createRecords( $tablename , [ $aFieldContents ] );
            if( !$result ) return false;
            
            // get last created uid
            return  $this->getMaxValue( $tablename , $uniqueKeyname );
    }

    /**
     * createMnRecords
     *
     * @param string $sTablename
     * @param array $aLocalAndForeignUids
     * @return array
     */
    Private function createMnRecords( $sTablename , $aLocalAndForeignUids )
    {
            if( !is_array($aLocalAndForeignUids) ) return false;
            
            $addToMn = [];
            foreach( $aLocalAndForeignUids as $iLocalUid => $aForeignUids ){
                if( !is_array($aForeignUids) ) continue;
                foreach( $aForeignUids as $uid_foreign ) {
                    if( !empty($iLocalUid) && !empty($uid_foreign) ) $addToMn[] = [ 'uid_local' => $iLocalUid , 'uid_foreign' => $uid_foreign ];
                }
            }
            $this->createRecords( $sTablename , $addToMn );
            return true;
    }

    /**
     * resetAutoIncrement
     *
     * @param string $tablename
     * @param string $unique
     * @return int
     */
    Private function resetAutoIncrement( $tablename , $unique )
    {
            return $this->sqlUtility->resetAutoIncrement( $tablename , $unique );
    }

    /**
     * getSqlToCreateMainTable
     *
     * @param array $tableDef table structure of main table
     * @return string
     */
    Private function getSqlToCreateMainTable( $tableDef )
    {
        if( !is_array( $tableDef['fields'] ) ) return null;
        
        $aCreateTable = [];
        $aCreateTable['start'] = 'DROP TABLE IF EXISTS ' . $tableDef['tablename'] . '; ' . "\n";
        $aCreateTable['start'].= 'CREATE TABLE ' . $tableDef['tablename'] . ' (' . "\n";
        
        // define unique field, if set
        $uniqueFieldDef = $tableDef['fields'][ $tableDef['unique'] ];
       
        $defUnique  =  '`' . $tableDef['unique'] . '`';
        $defUnique .= ' ' . $uniqueFieldDef['type'] ;
        $defUnique .= '(' . $uniqueFieldDef['length'] . ') NOT NULL' ;
        $defUnique .= ( isset($uniqueFieldDef['increase']) ? ' AUTO_INCREMENT' : '');
        if( !empty($uniqueFieldDef['comment']) ) $defUnique .= ' COMMENT "' . $uniqueFieldDef['comment'] . '"';
       
        $aCreateTable['field'][$tableDef['unique']] = $defUnique;
        
        // bring the fields in right order
        foreach($tableDef['fields'] as $fieldName => $fieldDef ){ $fldSort[ $fieldDef['position'] ] = $fieldName; }
        ksort($fldSort);
        
        // loop through fields and collect them for db table
        foreach($fldSort as $fieldName ){
            $fieldDef = $tableDef['fields'][$fieldName];
            // dont overwrite unique key, if already was defined before
            if( isset($aCreateTable['field'][$fieldName]) )  continue;
            
            $defField = '`' . $fieldName. '` ' ;
            $defField .= $fieldDef['type'] ;
            $defField .= $fieldDef['type'] != 'mediumtext' ? '(' . $fieldDef['length'] . ')' : '';
            $defField .= ( $fieldDef['notnullable'] ? ' NOT NULL' : '') ;
            if( !empty($fieldDef['comment'])  ) $defField .= ' COMMENT "' . $fieldDef['comment'] . '"';
            
            $aCreateTable['field'][$fieldName] = $defField;
            
        }
        
        // loop through fields and collect them for constraints
        $constraints = '';
        $z = 100;
        foreach($fldSort as $fieldName ){
            $fieldDef = $tableDef['fields'][$fieldName];
            if( $fieldDef['relType'] == '1n' ){
                ++$z;
                $constraints .= ", \n";
                $constraints .= "CONSTRAINT `" . $tableDef['tablename'] . "_" . $fieldName . "_" . $z . "`";
                $constraints .= " FOREIGN KEY (`" . $fieldName . "`) REFERENCES `" . $fieldDef['foreignTablename'] . "`"; ;
                $constraints .= " (`" . $fieldDef['foreignKeyname'] . "`)";
                $constraints .= " ON DELETE " ;
                $constraints .=  $fieldDef['notnullable'] ? "CASCADE" : "SET NULL" ;
                $constraints .= " ON UPDATE CASCADE ";
            }
        }
        
        $aCreateTable['end'] = ' PRIMARY KEY (`' . $tableDef['unique'] . '`)' ;
        $aCreateTable['end'].= $constraints;
        $aCreateTable['end'].= "\n" . ') ' . $this->settings['sql_config']['sSqlTableDefaults'] . ';';
        
        $sqlStatement = $aCreateTable['start'] . "\t" . implode( ',' . "\n\t" , $aCreateTable['field'] ) . ',' . "\n" . "\t" . $aCreateTable['end'];
        
        return $sqlStatement;
    }

    /**
     * getSqlToCreateSiblingTable
     *
     * @param array $tableDef table structure of 1:n table
     * @return string
     */
    Private function getSqlToCreateSiblingTable( $tableDef )
    {
        if( !is_array( $tableDef ) ) return null;
        
        $aCreateTable = [];
        $aCreateTable['start'] = 'DROP TABLE IF EXISTS ' . $tableDef['tablename'] . '; ' . "\n";
        $aCreateTable['start'].= 'CREATE TABLE ' . $tableDef['tablename'] . ' (' . "\n";
        
        $aCreateTable['field'][$tableDef['keyname']] = "\t`" . $tableDef['keyname'] . "` int(11) NOT NULL AUTO_INCREMENT";
        $aFields = [];
        if($tableDef['keyname'] != $tableDef['fieldname'] ) {
            $aCreateTable['field'][$tableDef['fieldname']] = "\t" ;
            $aCreateTable['field'][$tableDef['fieldname']] .= '`' . $tableDef['fieldname'] . '` ' ;
            $aCreateTable['field'][$tableDef['fieldname']] .= $tableDef['type'] . '(' . $tableDef['length'] . ') NOT NULL' ;
            if( !empty($tableDef['comment']) ) $aCreateTable['field'][$tableDef['fieldname']] .= ' COMMENT "' . $tableDef['comment'] . '"';
            $aFields[] = $tableDef['fieldname'];
        }
        
        $aCreateTable['end'] = ' PRIMARY KEY (`' . $tableDef['keyname'] . '`),' . "\n";
        $aCreateTable['end'].= ' UNIQUE KEY `Unique_' . $tableDef['tablename'] . '` (`' . implode( '`,`' , $aFields ) . '`)' . "\n";
        $aCreateTable['end'].= ') ' . $this->settings['sql_config']['sSqlTableDefaults'] . ';';
        
        $sqlStatement = $aCreateTable['start'] . implode( ',' . "\n" , $aCreateTable['field'] ) . ',' . "\n" . "\t" . $aCreateTable['end'];
        
        return $sqlStatement;
    }

    /**
     * getSqlToCreateChildTable
     *
     * @param array $tableDef table structure of m:n table
     * @return string
     */
    Private function getSqlToCreateChildTable( $tableDef )
    {
        if( !is_array( $tableDef ) ) return null;
        
//        $nameUniqueKey = $this->settings['sql_config']['sNameDefaultUniqueKey'];
        
        $aCreateTable = [];
        $aCreateTable['start'] = 'DROP TABLE IF EXISTS ' . $tableDef['tablename'] . '; ' . "\n";
        $aCreateTable['start'].= 'CREATE TABLE ' . $tableDef['tablename'] . ' (' . "\n";
        
//        $aCreateTable['field'][$nameUniqueKey] = "\t" . $nameUniqueKey . ' int(11) NOT NULL AUTO_INCREMENT';
        
        $aCreateTable['field']['uid_local'] = "\t`uid_local` int(11) NOT NULL";
        $aCreateTable['field']['uid_foreign'] = "\t`uid_foreign` int(11) NOT NULL";
        
       // $aCreateTable['end'] = ' PRIMARY KEY (' . $nameUniqueKey . '),' . "\n";
        $aCreateTable['end'] = ' PRIMARY KEY (`uid_local`,`uid_foreign`),' . "\n";
        $aCreateTable['end'].= ' FOREIGN KEY (`uid_local`) REFERENCES `'.$tableDef['localTablename'].'` (`'.$tableDef['localUid'].'`) ON DELETE CASCADE ON UPDATE CASCADE,' . "\n";
        $aCreateTable['end'].= ' FOREIGN KEY (`uid_foreign`) REFERENCES `'.$tableDef['foreignTablename'].'` (`'.$tableDef['foreignKeyname'].'`) ON DELETE CASCADE ON UPDATE CASCADE' . "\n";
        $aCreateTable['end'].= ') ' . $this->settings['sql_config']['sSqlTableDefaults'] . ';';
        
        $sqlStatement = $aCreateTable['start'] . implode( ',' . "\n" , $aCreateTable['field'] ) . ',' . "\n" . "\t" . $aCreateTable['end'];
        
        return $sqlStatement;
    }

    /**
     * getMaxValue
     *
     * @param string $tablename
     * @param string $fieldname
     * @return int
     */
    Private function getMaxValue( $tablename , $fieldname )
    {
        if( !$this->sqlUtility ) return 'Keine Datenbank Verbindungen möglich';
        return $this->sqlUtility->getMaxValue( $tablename , $fieldname );
    }

    /**
     * createAndGetUidFromRelTableByFieldContent
     *
     * @param string $tablename
     * @param string $fieldname
     * @param string $keyname
     * @param array $aFieldContents
     * @return array
     */
    Private function createAndGetUidFromRelTableByFieldContent( $tablename , $fieldname , $keyname , $aFieldContents )
    {
            
            $aContent = $this->getReltableRecordsByFieldContents( $tablename , $fieldname , $keyname , $aFieldContents );
            
            if( count( $aContent['addToTable'] ) ){
                
                // set auto increment to 1 in case of records where deleted before
                $this->resetAutoIncrement( $tablename , $keyname );
                
                // make shure we import only unique contents.
                // This is done by strtolower() on Key!
                $uniqueTable = [];
                foreach( $aContent['addToTable'] as $ix => $val ){ $uniqueTable[strtolower(trim($val))] = trim($val); }
                // bring the records in alphabetical Order and ...
                ksort( $uniqueTable );
                // ... change kyenames to indizes (no more associate keys)
                sort( $uniqueTable , SORT_LOCALE_STRING );
                $aContent['addToTable'] = $uniqueTable;
                
                // insert values in database here
                $sqlStat = "INSERT INTO " . $tablename . " (`" . $fieldname . "`) VALUES ";
                $sqlStat .= "('" .  implode( "'),('" , $aContent['addToTable'] ) . "');";
                
                $this->sqlUtility->execQuery( $sqlStat );
                
                $aSecondContent = $this->getReltableRecordsByFieldContents( $tablename , $fieldname , $keyname , $aFieldContents );
                $aContent['isInTable'] = $aSecondContent['isInTable'];
            }

            return $aContent;
    }

    /**
     * getReltableRecordsByFieldContents
     *
     * @param string $tablename
     * @param string $fieldname
     * @param string $keyname
     * @param array $aFieldContents
     * @return array
     */
    Private function getReltableRecordsByFieldContents( $tablename , $fieldname , $keyname , $aFieldContents )
    {
            $aContent = [ 'addToTable' => [] , 'isInTable' => [] ];
            if( !count($aFieldContents) ) return $aContent;
            
            foreach( $aFieldContents as $content ){ 
                
                $foundUid = $this->getRecordByFieldContent( $tablename , [ $fieldname => $content ] , $keyname );
                
                if(!$foundUid){
                    $aContent['addToTable'][] =  $content ;
                }else{
                    $aContent['isInTable'][ trim($content) ] = $foundUid;
                }
                
            }

            return $aContent;
    }

    /**
     * getRecordByFieldContent
     *
     * @param string $tablename
     * @param array $aFieldContents
     * @param string $uniqueKeyname
     * @return array
     */
    Private function getRecordByFieldContent( $tablename , $aFieldContents , $uniqueKeyname )
    {
            if( !count($aFieldContents) ) return false;
            
            foreach( $aFieldContents as $fieldname => $content ){
                $aWhere[] = " `" . $fieldname . "` = '" . trim($content) . "' ";
            }
            $aRecord = $this->sqlUtility->singleQuery( "SELECT `" . $uniqueKeyname . "` FROM `" . $tablename . "` WHERE " . implode( ' AND ' , $aWhere ) . ";" );
            
            return empty($aRecord[$uniqueKeyname]) ? 0 : $aRecord[$uniqueKeyname];
            
    }

    /**
     * createRecords
     *
     * @param string $tablename
     * @param array $aTableContents [ uid => [ fieldname1 => value , ... ] ]
     * @return boolean
     */
    Private function createRecords( $tablename , $aTableContents )
    {
            if( empty($tablename) || !count($aTableContents) ) return false;
            
            $aSqlLine = [];
            foreach($aTableContents  as $aRowContents ) {
                if( is_array($aRowContents) && count($aRowContents) ) $aSqlLine[] = "('" . implode( "','" , $aRowContents ) . "')"; 
            }
            if( !count($aSqlLine) ) return false;
            
            $aFirstRow = array_shift($aTableContents);
            if( !is_array($aFirstRow) || !count($aFirstRow) ) return false;
            
            $sqlStatement = "INSERT INTO " . $tablename . " (`" . implode( "`,`" , array_keys( $aFirstRow ) ) . "`) VALUES ";
            $sqlStatement .= implode( ' , ' ,  $aSqlLine );
            $sqlStatement .= ";";

            // insert values in database
            return $this->sqlUtility->execQuery( $sqlStatement );
    }

}
