<?php
namespace Sfgz\SdbMaker\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2019 Daniel Rueegg <colormixture@verarbeitung.ch>,
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class AnalyseUtility
 * 
 */

class AnalyseUtility implements \TYPO3\CMS\Core\SingletonInterface
{

    /**
        * aFieldSeparers
        *
        * @var array
        */
    Public $aFieldSeparers = [];

    /**
        * aPossibleFieldSeparer
        *
        * @var array
        */
    Private $aPossibleFieldSeparer = [ 1 => ',' , 2 => ':' , 3 => ';' ];

    /**
        * aHtmlDetectChars
        *
        * @var array
        */
    Private $aHtmlDetectChars = [ 0 => '<' , 1 => '>' ];

    /**
        * aFieldsToSubstitute
        *   Do not store following fields: nurEinzigartigeWerte , maxGleicheZellen , trennbar
        *
        * @var array
        */
    Private $aFieldsToSubstitute = ['zumGruppierenGeeignet','anzahlGruppen','anzGleicheZellen','nichtLeereZellen','typ','leereZellen','maxZeichen'];

    /**
        * constructor
        *
        * @return void
        */
    Public function __construct()
    {
    }

    /**
        * displaySelectedFile
        *  returns the original content of all sheets in given table
        * 
        * @param array $aTableRecords
        * @return array
        */
    Public function displaySelectedFile( $aTableRecords )
    {
            $aTables = [];
            foreach( $aTableRecords as $sheetname => $aRecords ) {
                
                $aRes = $this->analyseAndConvertRecords( $aRecords , [] );
                
                // display only original table
                
                $aTables[$sheetname]['inTable'] = $aRes['inTable'];
                $aTables[$sheetname]['inTable']['tablename'] = $sheetname;
            }
            return $aTables;
    }

    /**
        * displayConvertedSheet
        *  returns the original and splitted (converted) content of a given sheet
        * 
        * @param array $aTableRecords
        * @param array $aSeparer
        * @return array
        */
    Public function displayConvertedSheet( $aTableRecords , $aSeparer )
    {
            $aTables = [];
            $aRes = $this->analyseAndConvertRecords( $aTableRecords , $aSeparer );
            
            // display both tabTypes: original and splitted table
            foreach( $aRes as $tabType => $tabCont ) {
                $aTables[$tabType] = $tabCont;
            }
            return $aTables;
    }

    /**
        * getValuesForParentTables
        *
        * @param array $aTabAnalyseFeldDefinitionen
        * @return void
        */
    public function getValuesForParentTables( $aTabAnalyseFeldDefinitionen )
    {
            $aData = [];
            if( !isset( $aTabAnalyseFeldDefinitionen ) ) return $aData;
            foreach( $aTabAnalyseFeldDefinitionen as $fieldname => $fldDef ) {
                
                if( !isset($fldDef['anzGleicheZellen']) ) continue;
                foreach( $fldDef['anzGleicheZellen'] as $row ) {
                    foreach( $row as $fld ) {
                        $aData[ $fieldname ]['data'][trim($fld)] = trim($fld) ;
                    }
                }

                if( !is_array($this->aFieldSeparers[$fieldname]) || !count($this->aFieldSeparers[$fieldname]) ) continue;
                $aData[ $fieldname ]['separer'] = $this->aFieldSeparers[$fieldname];
            }
            return $aData;
    }

    /**
        * analyseAndConvertRecords
        *  analyze once, then analyze again with field-spearers
        *  take all properties of the specific field(s) from first analyse except int zumGruppierenGeeignet , int anzahlGruppen, array anzGleicheZellen
        * 
        * @param array $aRecords
        * @param array $aSeparer
        * @return array
        */
    Private function analyseAndConvertRecords( $aRecords , $aSeparer )
    {
            $info = [];
            if( !is_array($aRecords) || !count($aRecords) ) return $info;
            $info = $this->analyseRecords( $aRecords );
            if( !count($info) ) return $info;
            
            $info['umbrochen'] = 0;
           
            $aUsedFieldSeparers = $this->detectSelectedSeparer( $aSeparer , $info ); // needs info[ feldDefinitionen ]
            // no separer checked, return without transormation
            if( !count($aUsedFieldSeparers) ) {
                return [ 'inTable'=> $info , 'outTable' => $info   ];
            }
            
            $info['umbrochen'] = 1;
            $aNewInfo = $info;
            foreach( $aUsedFieldSeparers as $fieldName => $aSeparersForOneField ){
                $progressRecords = $this->splitTableFieldWithChar( $aRecords , $fieldName , $aSeparersForOneField);
                $aAnalyseConvertedRepport = $this->analyseRecords( $progressRecords );
                foreach( $this->aFieldsToSubstitute as $substProperty ){
                    $aNewInfo['feldDefinitionen'][$fieldName][trim($substProperty)] = $aAnalyseConvertedRepport['feldDefinitionen'][$fieldName][trim($substProperty)];
                }
                $aNewInfo['feldDefinitionen'][$fieldName]['multipleValues'] = 1;
                $aNewInfo['feldDefinitionen'][$fieldName]['separer'] = $aSeparersForOneField;
                $info['feldDefinitionen'][$fieldName]['multipleValues'] = 1;
            }
            
            return [ 'inTable'=> $info , 'outTable' => $aNewInfo ];
    }

    /**
        * analyseRecords
        *
        * @param array $aRecords
        * @return array
        */
    Private function analyseRecords( $aRecords )
    {
            $aAnalyseRepport = [];
            if( !count($aRecords) ) return $aAnalyseRepport;
            
            $aCountFieldRecords = $this->countValuesInRecords( $aRecords );
            if( !count($aCountFieldRecords) ) return $aAnalyseRepport;
            
            $aAnalyseRepport['zeilenzahl'] = count($aRecords)-1;
            
            $aFieldRecords = $this->buildSummas($aCountFieldRecords);
            
            foreach( $aFieldRecords  as $fieldname => $fConf ){
                $aFldProp = $this->setFieldProperties( $fConf , $aAnalyseRepport['zeilenzahl'] );
                if( is_array($aFldProp) ) $aAnalyseRepport['feldDefinitionen'][$fieldname] = $aFldProp;
            }
            return $aAnalyseRepport;
    }

    /**
        * setFieldProperties
        *
        * @param array $fConf fieldProperties
        * @param int $totalRows
        * @return array
        */
    Private function setFieldProperties( $fConf , $totalRows )
    {
                    if( !isset($fConf['equalValues']) ) return false;
                    $aFieldDef['typ'] = $this->detectDataType($fConf);
                    $aFieldDef['maxZeichen'] = $fConf['maxLength'];
                    if( count($fConf['equalValues']) == $totalRows ){
                        // index candidate detected
                        $aFieldDef['nurEinzigartigeWerte'] = 1;
                    }else{
                        $maxEqualCells = max($fConf['equalValues']);
                        $valideCount =  $totalRows - $fConf['emptyValues'] ;
                        $percentGroupable = $maxEqualCells <= 1 ? 0 : ( 100 - round( array_sum($fConf['equalValCounts']) *100 / $valideCount ) );
                        $percentEmptyCells = round( $fConf['emptyValues'] * 100 / $totalRows , 1 );
                        
                        $aFieldDef['leereZellen'] = $percentEmptyCells;
                        $aFieldDef['nichtLeereZellen'] = $valideCount;
                        $aFieldDef['maxGleicheZellen'] = $maxEqualCells;
                        $aFieldDef['anzGleicheZellen'] = $fConf['equalValGroups'];
                        $aFieldDef['zumGruppierenGeeignet'] = $percentGroupable;
                        $aFieldDef['anzahlGruppen'] = 0;
                        foreach( $fConf['equalValGroups'] as $anz => $aRows ) { if($anz>1) $aFieldDef['anzahlGruppen'] += count($aRows);}
                    }
                    $aFieldDef['trennbar'] = strpos( ' ' . $aFieldDef['typ'] , 'text' ) ? null : $fConf['ixList']; // ixList[ index | zeichen | anzahl ]
                    return $aFieldDef;
    }

    /**
        * countValuesInRecords
        *
        * @param array $aRecords
        * @return array
        */
    Private function countValuesInRecords( $aRecords )
    {
            $aFieldRecords = [];
            foreach( $aRecords  as $ix => $row ){
                    foreach( $row  as $fieldname => $content ){
                        if( $ix == 1 ){
                            // first row: Do not count values in here, just initialize variables.
                            if( !isset($aFieldRecords[$fieldname]['emptyValues']) ) $aFieldRecords[$fieldname]['emptyValues'] = 0;
                            if( !isset($aFieldRecords[$fieldname]['maxLength']) ) $aFieldRecords[$fieldname]['maxLength'] = 0;
                            if( !isset($aFieldRecords[$fieldname]['isList']) ) {
                                foreach( $this->aPossibleFieldSeparer as $chr ) $aFieldRecords[$fieldname]['isList'][$chr] = 0;
                            }
                            // Disable hasHtml, it will be enabled if any html is detected by < and >.
                            if( !isset($aFieldRecords[$fieldname]['hasHtml']) ) $aFieldRecords[$fieldname]['hasHtml'] = 0;
                            // Enable isNumeric and IsInteger as default. Disable them later if a value is not compatible.
                            if( !isset($aFieldRecords[$fieldname]['isNumeric']) ) $aFieldRecords[$fieldname]['isNumeric'] = 1;
                            if( !isset($aFieldRecords[$fieldname]['isInteger']) ) $aFieldRecords[$fieldname]['isInteger'] = 1;
                            continue;
                        }
                        // not first rows: count values from here on
                        if( '' == trim($content) || empty($content) ) {
                                // count empty values and leave this loop
                                $aFieldRecords[$fieldname]['emptyValues'] += 1;
                                continue;
                        }
                        
                        // initiate the content-specific counter
                        if( !isset($aFieldRecords[$fieldname]['equalValues'][$content]) ) $aFieldRecords[$fieldname]['equalValues'][$content] = 0;
                        // count equal values and detect maximum amount
                        $aFieldRecords[$fieldname]['equalValues'][$content] += 1;
                        if( strlen($content) > $aFieldRecords[$fieldname]['maxLength'] ) $aFieldRecords[$fieldname]['maxLength'] = strlen($content);
                        
                        // detect datatype
                        if( is_numeric( $content ) ) {
                            // datatype is some sort of numeric
                            if( !is_integer( 0 + $content ) ) $aFieldRecords[$fieldname]['isInteger'] = 0;
                            
                        }else{
                            // datatype is string
                            $aFieldRecords[$fieldname]['isNumeric'] = 0;
                            $aFieldRecords[$fieldname]['isInteger'] = 0;
                            // count all separer in this content
                            $aPos = [ 0 , 0 ];
                            foreach( $this->aHtmlDetectChars as $i => $chr ) $aPos[$i] = strpos( ' ' . $content , $chr );
                            if( $aPos[0] > 0 && $aPos[1] >  $aPos[0] ) $aFieldRecords[$fieldname]['hasHtml'] +=1;
                                
                            foreach( $this->aPossibleFieldSeparer as $sep ) {
                                if(strpos( $content , $sep )){
                                    $aCnt = explode( $sep , $content );
                                    $aFieldRecords[$fieldname]['isList'][$sep] += ( count($aCnt)-1 );
                                }
                            }
                        }
                        
                    }
                
            }
            
            // unset empty split entries (;.:)
            foreach( $aFieldRecords  as $fieldname => $row ){
                    if( !isset($row['isList']) ) continue;
                    // list the most popular first
                    arsort($row['isList']);
                    foreach( $row['isList']  as $separer => $counter ){
                            // include only found separers
                            if( !$counter ) continue;
                            $index = array_search( $separer , $this->aPossibleFieldSeparer );
                            $aFieldRecords[$fieldname]['ixList'][$index] = [ 'index' => $index , 'zeichen'=>$separer , 'anzahl'=>$aFieldRecords[$fieldname]['isList'][$separer] ];
                    }
            }
            
            return $aFieldRecords;
    }

    /**
        * buildSummas
        *
        * @param array $aFieldRecords
        * @return array
        */
    Private function buildSummas( $aFieldRecords )
    {
            // build sum
            foreach( $aFieldRecords  as $fieldname => $fConf ){
                if( !isset($fConf['equalValues']) || !is_array($fConf['equalValues']) ) continue;
                arsort($fConf['equalValues']);
                foreach($fConf['equalValues'] as $content => $amount ) {
                    $ix = 'kommen-'.$amount.'x-vor';
                    if( !isset($aFieldRecords[$fieldname]['equalValCounts'][$ix]) ) $aFieldRecords[$fieldname]['equalValCounts'][$ix]=0;
                    $aFieldRecords[$fieldname]['equalValCounts'][$ix]+=1;
                     $aFieldRecords[$fieldname]['equalValGroups'][$amount][] =  $content ;
                }
            }
            
            return $aFieldRecords;
    }

    /**
        * convertRecords
        *
        * @param array $aSeparer
        * @param array $aInfo
        * @return array
        */
    Public function detectSelectedSeparer( $aSeparer , $aInfo )
    {
            $aUsedFieldSeparers = [];
            if( !is_array($aInfo['feldDefinitionen']) ) return $aUsedFieldSeparers;
            $FeldNr = 0;
            foreach( $aInfo['feldDefinitionen'] as $fieldname => $fldDef ){
                ++$FeldNr;
                if( !isset( $aSeparer[$FeldNr] ) ) continue; // no convert command given
                if( !is_array($fldDef['trennbar']) ) continue; // no separer string for this field
                // detect field separer and store them with numeric index
                foreach( $fldDef['trennbar'] as $fzIx => $feldTrennung ){
                    if( !isset( $aSeparer[$FeldNr][$fzIx] ) ) continue;
                    if( $fzIx != $aSeparer[$FeldNr][$fzIx] ) continue;
                    $aUsedFieldSeparers[$fieldname][$fzIx] = $feldTrennung['zeichen'];
                }
            }
            $this->aFieldSeparers = $aUsedFieldSeparers;
            return $aUsedFieldSeparers ;
    }

    /**
        * convertRecords
        *
        * @param array $aTable
        * @param string $sFieldname
        * @param array $aSeparersForOneField
        * @return array
        */
    Private function splitTableFieldWithChar( $aTable , $sFieldname , $aSeparersForOneField)
    {   
        $aFlatTable = [];
        // fill the outArray $aFlatTable with all (also 'other') tables from $aTable
        $nIx = 1;
        foreach( $aTable as $ix => $row ){
                $aFlatTable[$nIx] = $row;
                ++$nIx;
        }
        // get the last separer, and replace all others with this
        $sRpl = array_pop($aSeparersForOneField);
        
        // loop through $aTable and work on rows with own fieldname, skip other fields
        $nIx = 1;
        foreach( $aTable as $ix => $row ){
            if( !isset($row[$sFieldname]) || empty($row[$sFieldname]) ) continue; // skip other fields
            
            // split content of given field with all split-chars at once into fragments
            $replacedVal = str_replace( $aSeparersForOneField , $sRpl , trim($row[$sFieldname]) );
            $aFieldFragments = explode( $sRpl , trim($replacedVal) );
            // build new rows for each fragment and substitute the fieldcontent
            foreach( $aFieldFragments as $words ){
                if( trim($words) == '' ) continue;
                $aFlatTable[$nIx][$sFieldname] = trim($words); // overwrite the actual table of outArray
                ++$nIx;
            }
            
        }
        
        return $aFlatTable;
    }

    /**
        * detectDataType
        *
        * @param str $aFieldAttributes
        * @return void
        */
    Private function detectDataType( $aFieldAttributes )
    {
        if( $aFieldAttributes['isInteger'] ){
            // some type of integer detected: int or tinyint
            $type = $aFieldAttributes['maxLength'] > 1 ? 'int' : 'tinyint';
            
        }elseif( $aFieldAttributes['isNumeric'] ){
            // type numeric detected
            $type = 'numeric';
            
        }elseif( $aFieldAttributes['maxLength'] > 255 ){
            // some type of text detected: html-text or simple text
            $type = $aFieldAttributes['hasHtml'] ? 'mediumtext' : 'text';
                
        }else{
            // fallback if no type detected: set varchar
            $type = 'varchar';
        }
        
        return $type;
    }
}
