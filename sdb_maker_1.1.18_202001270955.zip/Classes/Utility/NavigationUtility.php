<?php
namespace Sfgz\SdbMaker\Utility;

use \TYPO3\CMS\Core\Utility\GeneralUtility;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2019 Daniel Rueegg <colormixture@verarbeitung.ch>,
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Class NavigationUtility
 * 
 */

class NavigationUtility implements \TYPO3\CMS\Core\SingletonInterface
{
    
    /**
    * report
    *
    * @var array
    */
    protected $report = null;
    
    /**
    * actionConfig
    *
    * @var array
    */
    protected $actionConfig = [
        'action2button' => [
                'display'     => 'display' ,
                'base'        => 'base' ,
                'settings'    => 'settings' ,
                'database'    => 'database' ,
                'analyse'     => 'analyse' ,
                'preflight'   => 'analyse' ,
                'syncronize' => 'analyse' 
        ] ,
        'buttonConfig' => [
                0 => [ 'action' => 'display'  , 'value' => 'Vorschau'     , 'admin' => 0 ] ,
                1 => [ 'action' => 'base'     , 'value' => 'Editor'       , 'admin' => 1 ] ,
                2 => [ 'action' => 'settings' , 'value' => 'Konfiguration', 'admin' => 1 ] ,
                3 => [ 'action' => 'database' , 'value' => 'Datenbank'    , 'admin' => 1 ] ,
                4 => [ 'action' => 'analyse'  , 'value' => 'Import'       , 'admin' => 1 ]
        ]
    ];
   
    /**
     * getNavigation 
     *
     * @param string $requestAction
     * @param array $settings
     * @return array
     */
    Public function getNavigation( $requestAction , $settings )
    {
            // no admin group defined or not logged in or user is in no group:
            // Only displayAction is allowed, admin-Actions are ignored

            $isAdmin = $this->isAdmin( $settings );
            if( !$isAdmin ){ 
                // no action defined for admins but admin-groups are defined: show all actions for admin
                $aButtons = $this->getDefaultButtons();
                
            }else{
                if( '' == trim($settings['allowedactions']) ) {
                    // get all actions if not even 0 is selected
                    $aButtons = $this->getDefaultButtons( true );
                    
                }else{
                    // detect selected actions
                    $aButtons = $this->getAdminButtons( $settings['allowedactions'] );
                }
            }
            
            $sanitizedAction = $this->getVerfiedAction( $requestAction , $aButtons );
            $recomendRedirect = ( $requestAction != $sanitizedAction ? 1 : 0 );
            
            $actualButton = $this->actionConfig['action2button'][$sanitizedAction];
            
            
            
            $this->report[ 'getNavigation' ] = 'Requested Action: ' . $requestAction . ( $recomendRedirect ? ' Redir to:' . $sanitizedAction : ' allowed.' ) . ' button: ' . $aButtons[$actualButton];
            
            if( count($aButtons) == 1 ) $aButtons = [];
            
            $aAllowedActions = [
                'redirect' =>  $recomendRedirect, 
                'callAction' => $sanitizedAction , 
                'actualButton' => $actualButton , 
                'buttons' => $aButtons , 
                'request' => [] , 
                'report' => $this->report 
            ];

            return $aAllowedActions;
    }
    
    /**
     * isAdmin 
     *
     * @param array $settings
     * @return int 0 or 1
     */
    Private function isAdmin($settings)
    {
            if( empty($GLOBALS['TSFE']->fe_user->user['usergroup']) ) return 0;
            if( empty($settings['admingroup']) ) return 0;

            // group detection
            // does a user-group match with a admin-group?
            $aUserGroups    = array_flip( explode( ',' , $GLOBALS['TSFE']->fe_user->user['usergroup'] ) );
            $aAllowedGroups = explode( ',' , $settings['admingroup'] );

            foreach($aAllowedGroups as $autorizedGroup ){
                if( isset($aUserGroups[$autorizedGroup]) ) return 1;
            }
            return 0;
    }
   
    /**
     * getAdminButtons 
     *
     * @param string $allowedactions
     * @return boolean
     */
    Private function getAdminButtons( $allowedactions )
    {
            $aAllowedButtons = [];
            $aButConf = $this->actionConfig['buttonConfig'];
            $aAdminActions  = explode( ',' , $allowedactions );
            
            foreach( $aAdminActions as $i  ){
                $aAllowedButtons[ $aButConf[$i]['action'] ] = $aButConf[$i]['value'];
            }
            $this->report[ 'AdminButtons' ] = count($aAllowedButtons) . ' Buttons: [' . implode( ' | ' , $aAllowedButtons ) . ']';
            
            return $aAllowedButtons;
    }
   
    /**
     * getDefaultButtons 
     *
     * @param boolean $all
     * @return boolean
     */
    Private function getDefaultButtons( $all = false )
    {
            $aAllowedButtons = [];
            foreach( $this->actionConfig['buttonConfig'] as $i => $aButConf ){
                    if( empty($aButConf['admin']) || $all ) $aAllowedButtons[ $aButConf['action'] ] = $aButConf['value'];
            }
            $this->report[ 'DefaultButtons_as_' . ( $all ? 'admin' : 'user' ) ] = count($aAllowedButtons) . ' Buttons: [' . implode( ' | ' , $aAllowedButtons ) . ']';
            return $aAllowedButtons;
    }
  
    /**
     * getVerfiedAction 
     *
     * @param string $requestAction
     * @param array $aButtons
     * @return string
     */
    Private function getVerfiedAction( $requestAction , $aButtons )
    {
            $actualButton = $this->actionConfig['action2button'][$requestAction];
            
            if( count($aButtons) && !isset($aButtons[ $actualButton ]) ){
                    $aTmp = array_keys($aButtons);
                    $changedAction = array_shift( $aTmp );
                    $this->report[ 'VerfiedAction' ] = 'Action ' . $requestAction . ' changed to ' . $changedAction . ': Button ' . $actualButton . ' is not in [' . implode( ' | ' , array_keys($aButtons) ) . ']';
                    return $changedAction;
            }
            return $requestAction;
    }
}
