<?php
defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
    function()
    {

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
            'Sfgz.SdbMaker',
            'Model',
            [
                'Model' => 'display,base,settings,analyse,preflight,syncronize,database',
                'Ajax' => 'list,preview',
                'Json' => 'main,parents,children'
            ],
            // non-cacheable actions
            [
                'Model' => 'display,base,settings,analyse,preflight,syncronize,database',
                'Ajax' => 'list,preview',
                'Json' => 'main,parents,children'
            ]
        );

    // wizards
    \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPageTSConfig(
        'mod {
            wizards.newContentElement.wizardItems.plugins {
                elements {
                    model {
                        iconIdentifier = sdb_maker-plugin-model
                        title = LLL:EXT:sdb_maker/Resources/Private/Language/locallang_db.xlf:tx_sdb_maker_model.name
                        description = LLL:EXT:sdb_maker/Resources/Private/Language/locallang_db.xlf:tx_sdb_maker_model.description
                        tt_content_defValues {
                            CType = list
                            list_type = sdbmaker_model
                        }
                    }
                }
                show = *
            }
       }'
    );
		$iconRegistry = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(\TYPO3\CMS\Core\Imaging\IconRegistry::class);
		
			$iconRegistry->registerIcon(
				'sdb_maker-plugin-model',
				\TYPO3\CMS\Core\Imaging\IconProvider\SvgIconProvider::class,
				['source' => 'EXT:sdb_maker/Resources/Public/Icons/user_plugin_model.svg']
			);
		
    }
);
