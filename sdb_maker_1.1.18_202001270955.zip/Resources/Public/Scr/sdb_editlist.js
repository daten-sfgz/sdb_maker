function bindEditListEvents(  URI , pluginUid ){
        // set default view 
        clearEditListObjects( pluginUid );
        
        bindEventsForList( pluginUid );
        bindEventsForButton_update(  URI , pluginUid );
        bindEventsForButton_create(  URI , pluginUid );
        bindEventsForButton_delete(  URI , pluginUid );
        bindEventsForButton_abort(  URI , pluginUid );
}

function bindEventsForList( pluginUid ){
        // set css-pointer and bind events triggered by click on list-items:
        $( '#listContainer_' + pluginUid + ' TABLE.editListTable TBODY TR' ).css('cursor','pointer');
        // bind general on all tr
        $('#listContainer_' + pluginUid + ' TABLE.editListTable TBODY').on('click', 'TR' , function(){
            bindEventsForList_row( this , pluginUid );
        });
}

function bindEventsForList_row( thisObj , pluginUid ){
            // unfortunaly the unbind does not work cause we bound general on all tr
            if( $( thisObj ).hasClass('old') ) return;
            
            // change to edit view
            $(  '#listContainer_' + pluginUid + ' .editListResponse' ).html( '' );
            toggleEditListObjects( pluginUid, 1 );
            // insert values from list in editor fields - and labels if exists
            $( thisObj ).find( 'TD' ).each(function( i ){
                     // IMPORTANT get text() not html() !
                    $( '.indexedValue_' + pluginUid + '_' + i ).val( $( this ).text() );
                    if( 'hidden' == $( '.indexedValue_' + pluginUid + '_' + i ).attr('type') ){
                        $( '.indexedLabel_' + pluginUid + '_' + i ).html( $( this ).html() );
                    }
            });
}


function bindEventsForButton_abort(  URI , pluginUid ){
        $( '#listContainer_' + pluginUid + ' .editListObjects SPAN.arrowleft' ).css('cursor','pointer').on( 'click', function() {
            clearEditListObjects( pluginUid );
        });
}

function bindEventsForButton_create(  URI , pluginUid ){
        $( '#listContainer_' + pluginUid + ' .editListObjects SPAN.add_record' ).css('cursor','pointer').on( 'click', function() {
            usroption = {};
            usroption['table'] = $( '#indexfield_' + pluginUid ).data('tablename');
            usroption['record'] = $( '#formular_' + pluginUid ).serialize();
            usroption['subaction'] = 'create';
            jsonParentsCallAndDigest( URI , pluginUid , usroption , 'Create' );
        });
}

function bindEventsForButton_update(  URI , pluginUid ){
        
        $( '#listContainer_' + pluginUid + ' .editListObjects SPAN.save' ).css('cursor','pointer').on( 'click', function() {
            usroption = {};
            usroption['id'] = $( '#indexfield_' + pluginUid ).val();
            usroption['table'] = $( '#indexfield_' + pluginUid ).data('tablename');
            usroption['record'] = $( '#formular_' + pluginUid ).serialize();
            usroption['subaction'] = 'update';
            jsonParentsCallAndDigest( URI , pluginUid , usroption , 'Update' );
        });
}

function bindEventsForButton_delete(  URI , pluginUid ){
        
        $( '#listContainer_' + pluginUid + ' .editListObjects SPAN.delete' ).css('cursor','pointer').on( 'click', function() {
            usroption = {};
            usroption['id'] = $( '#indexfield_' + pluginUid ).val();
            usroption['table'] = $( '#indexfield_' + pluginUid ).data('tablename');
            usroption['subaction'] = 'delete';
            $( '#listContainer_' + pluginUid + ' TABLE.editListTable TBODY TR.r' + usroption['id'] ).addClass('old').removeClass('new');
            if (window.confirm('Datensatz Nr. "' + usroption['id'] + '" wirklich löschen?')){
                jsonParentsCallAndDigest( URI , pluginUid , usroption , 'Delete' );
            }else{
                $( '#listContainer_' + pluginUid + ' TABLE.editListTable TBODY TR.r' + usroption['id'] ).removeClass('old');
            }
        });
}

function jsonParentsCallAndDigest( URI , pluginUid , usroption , digest ){
    $.ajax({
        url : URI,
        type : 'GET',
		data: { 'data': usroption },
        dataType:'json',
        success : function(value) {
            var obj = JSON.parse( value );
            window[ 'digestJsonCall_' + digest ]( obj , pluginUid );
            return true;
        },
        error : function(request,error)
        {
            if( request['status'] > 0 ){
                alert('error: ' + URI + ' Request ' + error + ': '+JSON.stringify(request));
            }
            $(  '#listContainer_' + pluginUid + ' .editListResponse' ).html( JSON.stringify(request) );
            return true;
        }
    });
}

function digestJsonCall_Create( obj , pluginUid ){
            
            if( obj.error < 1 ){
                var newCells = '';
                $.each(obj.recordset,function( fieldname, datarow) {
                    newCells += '<td>' + datarow + '</td>';
                });
                if( newCells.length > 0 ) {
                    var newRow = '<tr class="r' + obj.id + ' new">' + newCells + '</tr>';
                    if( obj.insertAfter > 0){
                        $( '#listContainer_' + pluginUid + ' TABLE.editListTable TBODY TR.r' + obj.insertAfter ).after( newRow );
                    }else{
                        $( '#listContainer_' + pluginUid + ' TABLE.editListTable TBODY' ).prepend( newRow );
                    }
                }
            }else{
                console.log( 'Subaction: ' + obj.subaction + ' Table: ' + obj.table + ' id: ' + obj.id );
                console.log( 'insertAfter: ' + obj.insertAfter );
                console.log( 'Answer: ' + obj.answer + ' sql: ' + obj.sql );
            }
            
            clearEditListObjects( pluginUid );
            if( obj.id > 0 ){
                var responsetext = '<span class="pointer" onClick="scrollToIdInSpecifiedBox(\'.r'+obj.id+'\',\'#table-scroll_'+pluginUid+'\')">' + obj.answer + '</span>';
                scrollToIdInSpecifiedBox( '.r' + obj.id , '#table-scroll_' + pluginUid );
            }else{
                var responsetext = obj.answer;
            }
            $( '#listContainer_' + pluginUid + ' .editListResponse' ).html( responsetext );
} 

function digestJsonCall_Update( obj , pluginUid ){
            
            if( obj.error < 1 ){
                $( '#listContainer_' + pluginUid + ' TABLE.editListTable TBODY TR.r' + obj.id ).find( 'TD' ).each(function( cell ){
                        i = 0;
                        value ='';
                        $.each(obj.recordset,function( fieldname, datarow) {
                            if( i === cell ) value = datarow ;
                            i = i+1;
                        });
                        $( this ).html( value );
                });
                $( '#listContainer_' + pluginUid + ' TABLE.editListTable TBODY TR.r' + obj.id ).addClass('edited');
            }else{
                console.log( 'Subaction: ' + obj.subaction + ' Table: ' + obj.table + ' id: ' + obj.id );
                console.log( 'Answer: ' + obj.answer + ' sql: ' + obj.sql );
            }
            var responsetext = '<span class="pointer" onClick="scrollToIdInSpecifiedBox(\'.r'+obj.id+'\',\'#table-scroll_'+pluginUid+'\')">' + obj.answer + '</span>';
            clearEditListObjects( pluginUid );
            $(  '#listContainer_' + pluginUid + ' .editListResponse' ).html( responsetext );
}

function digestJsonCall_Delete( obj , pluginUid ){
//             console.log( 'Subaction: ' + obj.subaction + ' Table: ' + obj.table + ' id: ' + obj.id );
//             console.log( 'Answer: ' + obj.answer + ' sql: ' + obj.sql );
            
            clearEditListObjects( pluginUid );
            $(  '#listContainer_' + pluginUid + ' .editListResponse' ).html( obj.answer );
            // unfortunaly the unbind does not work cause we bound general on all tr
            $( '#listContainer_' + pluginUid + ' TABLE.editListTable TBODY TR.r' + obj.id ).fadeTo( 1000 , 0.5 ).css('cursor','').addClass('old');
}


function clearEditListObjects( pluginUid ){
            $( '#listContainer_' + pluginUid + ' .editListResponse' ).html( '' );
            $( '#listContainer_' + pluginUid + ' .editListLabels' ).html('');
            $( '#listContainer_' + pluginUid + ' .editListValues' ).val('');
            toggleEditListObjects( pluginUid, 0 );
} 

function toggleEditListObjects( pluginUid, edit ){
        if( edit ){
            $( '#listContainer_' + pluginUid + ' .aAdd' ).hide();
            $( '#listContainer_' + pluginUid + ' .aEdit' ).show();
        }else{
            $( '#listContainer_' + pluginUid + ' .aEdit' ).hide();
            $( '#listContainer_' + pluginUid + ' .aAdd' ).show();
        }
}
