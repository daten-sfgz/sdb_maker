/*!
 * sdb_maker.js
 * 
 * Licensed MIT © Daniel Rueegg
 */

// start of Model->base (edit)
// onChange event for selector to choose maintanle in Base.html
function str_replace( searchPattern , replaceValue , patternedUri ){
    return  patternedUri.replace( searchPattern , replaceValue );
}
//end  of Model->base (edit)


// start of ajax call from Model->display and base (edit)
function clearListSearchValues(  URI , pluginUid , minChars , calledFromAction ){
    var filterClass = 'selectFilter_' + pluginUid;
    var searchTextId = 'textFilter_' + pluginUid;
    if( $( '#' + searchTextId ).length ) {
        $( '#' + searchTextId ).val('');
        localStorage.setItem( searchTextId , null );
    };
    $( '.' + filterClass ).each(function () {
        $( this ).val(0);
        localStorage.setItem( $( this ).attr('id') , null );
    });
    $( '#singlePagerContainer_' + pluginUid ).html('');
    tryLoadListFromAjax( URI , pluginUid , minChars , calledFromAction );
}
function initiateLoadListFromAjax( URI , pluginUid , minChars , calledFromAction ){
    var filterClass = 'selectFilter_' + pluginUid;
    var searchTextId = 'textFilter_' + pluginUid;
    
    // initiate text-search: get value from local storage, bind input-event
    if( $( '#' + searchTextId ).length ) {
        $( '#' + searchTextId ).val( localStorage.getItem( searchTextId ) );
        $( '#' + searchTextId ).on('input', function() {
            tryLoadListFromAjax( URI , pluginUid , minChars , calledFromAction );
        });
    };
    
    // initiate search by select: get value from local storage, bind onchange event
    $( '.' + filterClass ).each(function () {
        var storedValue = localStorage.getItem( $( this ).attr('id') );
        if( typeof storedValue === 'undefined' || storedValue == 'null' ){ storedValue = 0; }
        $( this ).val( storedValue );
    });
    $( '.' + filterClass ).on('change', function() {
        tryLoadListFromAjax( URI , pluginUid , minChars , calledFromAction );
    });
    
    //bind events on buttons reload and clear filter
    $( '.reloadFilterButton_' + pluginUid ).addClass( 'refresh' ).on('click', function() {
        tryLoadListFromAjax( URI , pluginUid , minChars , calledFromAction );
    });
    $( '.clearFilterButton_' + pluginUid ).addClass( 'delete' ).on('click', function() {
        clearListSearchValues( URI , pluginUid , minChars , calledFromAction );
    });

    tryLoadListFromAjax( URI , pluginUid , minChars , calledFromAction );
}

function tryLoadListFromAjax( URI , pluginUid , minChars , calledFromAction ){
    var responseId = 'ajaxFoundRows_' + pluginUid;
    var filterClass = 'selectFilter_' + pluginUid;
    var searchTextId = 'textFilter_' + pluginUid;
    
    switchEditForm( pluginUid ,  0 );
	$( '#' + responseId ).html( '<span class="blinker">...</span>' );
	
    usroption = {};
	usroption['filter'] = {};
	usroption['filter']['calledFromAction'] = calledFromAction;
    var breakSearch = 1;
    var counter = 0;
    // search by text
    if( $( '#' + searchTextId ).length ){
        ++counter;
        if( minChars <= $( '#' + searchTextId ).val().length ){
            usroption['filter'][searchTextId] = $( '#' + searchTextId ).val();
            breakSearch = 0;
        }
        localStorage.setItem( searchTextId , $( '#' + searchTextId ).val() );
    }
    // search by select-fields
    $( '.' + filterClass ).each(function () {
            ++counter;
            usroption['filter'][$( this ).attr('id')] = $( this ).val();
            localStorage.setItem( $( this ).attr('id') , $( this ).val() );
            if( $( this ).val() > 0 ){ breakSearch = 0; }
            if( $( this ).val() == 'zero' ){ breakSearch = 0; }
    });
    
    // start search
    if( breakSearch == 0 || counter == 0 || minChars == 0 ){
        ajaxCall( URI , responseId , usroption );
        
    }else{
    // dont search if restricted by minChars
		$( '#' + responseId ).fadeTo( 1 , 1 );
        var startText = '<p>Mindestens ';
        var charsText = '' + minChars + ' Zeichen eingeben';
        var selectText = 'eine Auswahl treffen';
        var endText = ' um die Suche zu starten.</p>';
        if( $( '#' + searchTextId ).length  ){
            if( counter == 1 ){
                $( '#' + responseId ).html( startText + charsText + endText );
            }else{
                $( '#' + responseId ).html( startText + charsText + ' oder ' + selectText + endText );
            }
        }else{
            $( '#' + responseId ).html( startText + selectText + endText );
        }
        
    }
}
//end  of Model->base (edit)

// start of ajax call from Model->display and base (edit)
function ajaxCall( URI , responseId , usroption ){
    $.ajax({
        url : URI,
        type : 'POST',
		data: usroption,
        dataType:'text',
        success : function(data) {
            $( '#' + responseId ).data( 'recordid' , usroption['filter']['id'] );
            $( '#' + responseId ).html( data );
			$( '#' + responseId ).fadeTo( 1 , 1 );
            return true;
        },
        error : function(request,error)
        {
            if( request['status'] > 0 ){
                $( '#' + responseId ).html( 'Fehler beim Aufruf von Ajax: ' + JSON.stringify(request) );
                return false;
            }
			$( '#' + responseId ).fadeTo( 1 , 1 );
            return true;
        }
    });
}
// end of ajax call from Model->display and base (edit)

// called from view Datalist to fill selectFilter 
// prepare edit form: fill option lists and bind events to them
function fillOptionsLists( objIdPrefix , pluginUid ){
            var optionlists = getOptionLists();
            $.each(optionlists, function (table, optarr) {
                rendertype = $( '#' + objIdPrefix + '_' + pluginUid + '_' + table ).data('rendertype');
                labeltext = $( '#' + objIdPrefix + '_' + pluginUid + '_' + table ).data('label');
                var selectObj = $( '#' + objIdPrefix + '_' + pluginUid + '_' + table ).html();
                var aIndex = {0:'i', 1:0 };
                
                if( rendertype == 'select' ){
                    selectObj = '<option value="0">' + labeltext + '...</option>' + buildOptionlistFromArray( optionlists[table] );
                    
                }else if( rendertype == 'filterselect' ){
                    selectObj = autofillFilteredSelect( optionlists[table] , objIdPrefix , pluginUid , table , $( '#' + objIdPrefix + 'Filter_' + pluginUid + '_' + table ).val() );
                    
                }else if( rendertype == 'checkgroup' ){
                    selectObj = '';
                    for(var sIndex in optionlists[table]){
                        aIndex = sIndex.split('.');
                        index = aIndex[1];
                        selectObj = selectObj + '<label><input type="checkbox" id="ck_' + pluginUid + '_' + table + '_' + index + '" name="data[' + table + '][' + index + ']" value="' + index + '" />' + optionlists[table][sIndex] + '</label> ';
                    }
                    
                }else if( rendertype == 'radiogroup' ){
                    selectObj = '<label><input type="radio" name="data[' + table + ']" value="0" /> (leer) </label>';
                    for(var sIndex in optionlists[table]){
                        aIndex = sIndex.split('.');
                        index = aIndex[1];
                        // dont add 'empty'-option on No/Yes options 
                        if( index == 0 ) selectObj = '';
                        selectObj = selectObj + '<label><input type="radio" name="data[' + table + ']" value="' + index + '" />' + optionlists[table][sIndex] + '</label> ';
                    }
                    
                }
                if( typeof selectObj !== 'undefined' && selectObj != 'null' ){
                    $( '#' + objIdPrefix + '_' + pluginUid + '_' + table ).html( selectObj );
                }
            });
}
function buildOptionlistFromArray( optionlist ){
        var selectObj = '';
        for(var sIndex in optionlist){
            aIndex = sIndex.split('.');
            index = aIndex[1];
            if( index == 0 ) index = 'zero';
            selectObj = selectObj + '<option value="' + index + '">' + optionlist[sIndex] + '</option>';
        }
        return selectObj;
}

// called from fillOptionsLists(), triggered in the view 'BaseEdit'
function bindAutoFillOptionsLists( URI , objIdPrefix , pluginUid ){
            var optionlists = getOptionLists();
            $.each(optionlists, function (table, optarr) {
                rendertype = $( '#' + objIdPrefix + '_' + pluginUid + '_' + table ).data('rendertype');
                if( rendertype == 'filterselect' ){
                    
                    $( '#' + objIdPrefix + 'Filter_' + pluginUid + '_' + table ).on('input', function() {
                        filtertext = $( '#' + objIdPrefix + 'Filter_' + pluginUid + '_' + table ).val();
                        selectObj = autofillFilteredSelect( optionlists[table] , objIdPrefix , pluginUid , table , filtertext );
                        $( '#' + objIdPrefix + '_' + pluginUid + '_' + table ).html( selectObj );
                    });
                    
                }else if( rendertype == 'checkgroup' ){
                    $( '#' + objIdPrefix + '_' + pluginUid + '_' + table + ' input[type="checkbox"]' ).on('click', function() {
                            $( '#valuesList_' + pluginUid + '_' + table ).animate({ color: "red" }, 5 );
                            $( '#valuesList_' + pluginUid + '_' + table ).addClass( 'blinker' );
                            usroption = {};
                            usroption['table'] = table;
                            usroption['uid_local'] = $( '#singleFormContainer_' + pluginUid ).data('recordid');
                            usroption['uid_foreign'] = $( this ).val();
                            jsonCallAndRunScript( URI ,  objIdPrefix + '_' + pluginUid + '_' + table , usroption , 'Checkgroup' );
                    });
                }
            });
}
function autofillFilteredSelect( optionlist , objIdPrefix , pluginUid , table , filtertext){
         labeltext = $( '#' + objIdPrefix + '_' + pluginUid + '_' + table ).data('label');
         firstOption = '<option value="0">' + labeltext + '...</option>';
         selectObj = buildFilteredOptionlistFromArray( optionlist , objIdPrefix , pluginUid , table , filtertext );
         if( typeof selectObj !== 'undefined' && selectObj != 'null'  && selectObj != '' ){
            return firstOption + selectObj;
         }else{
             if( filtertext == '' ){
                return firstOption + buildOptionlistFromArray( optionlist );
             }else{
                 return firstOption ;
            }
         }
}
function buildFilteredOptionlistFromArray( optionlist , objIdPrefix , pluginUid , table , filtertext ){
        var selectObj = '';
        var foundIn = 0;
        var aSearchPatterns = filtertext.split('+');
        var firstSelected = 0;
        
        $.each(optionlist, function (sIndex, content){
            aIndex = sIndex.split('.');
            index = aIndex[1];
            
            foundIn = 0;
            for (var w = 0; w < aSearchPatterns.length; w++) {
                if(  Number.isInteger(parseInt(aSearchPatterns[w])) ){
                    if( index == aSearchPatterns[w] ){ foundIn+= 1; } 
                }else{
                    if( aSearchPatterns[w].length >= 1 &&  content.search(new RegExp(aSearchPatterns[w], "i"))!= -1 ){ foundIn+= 1; } 
                 } 
                 
            };
            
            if( foundIn >= 1 ) {
                if( firstSelected == 0 ){
                    selectObj = selectObj + '<option value="' + index + '" selected="selected">' + content + '</option>';
                    firstSelected = index;
                }else{
                    selectObj = selectObj + '<option value="' + index + '">' + content + '</option>';
                }
            }
            
        });
        
        return selectObj;
}
// end of prepare edit form


// called from partial Pager.html with $(document).ready...
function bindTableSorter( pluginUid , rows ){
    if( rows.length == 0 ) rows = 10;
    $( 'TABLE.type_preview THEAD TH' ).css('cursor','pointer');
    $( 'TABLE.type_edit THEAD TH' ).css('cursor','pointer');
    $("#trnsSortPagerTable" + pluginUid).tablesorter({
		dateFormat: "ddmmyyyy", 
		debug:false, 
		initWidgets:false, 
		headers : {
				".dateFormat-ddmmyyyy" : {
					sorter: "shortDate", 
					dateFormat: "ddmmyyyy" 
				} 
		}
    }).tablesorterPager({
		container: $("#pager_" + pluginUid) , 
		size: rows , 
		page: 0
    });
}

// Binding for List created by Ajax-call
function bindClickOnDisplayListItem( URI , responseId ){
    $( 'TABLE.type_preview .datarow' ).css('cursor','pointer');
    $( 'TABLE.type_preview .datarow TD:first-child' ).css({'white-space':'nowrap','overflow':'visible'});
    
   // click on rows of table to display them as preview
    $( 'TABLE.type_preview TR.datarow' ).on('click', function() {
        if( $( this ).data('idx') ){
            $( '#' + responseId ).data( 'uri' , URI );
            ajaxCall( URI , responseId , { 'filter' : {'id':$( this ).data('idx')} } );
        }
    });
}

function bindClickOnEditListItem( URI , responseId ){
    $( 'TABLE.type_edit .datarow' ).css('cursor','pointer');
    $( 'TABLE.type_edit .datarow TD:first-child' ).css({'white-space':'nowrap','overflow':'visible'});
    
   // click on rows of table to display them as edit-form
    $( 'TABLE.type_edit TR.datarow' ).on('click', function() {
        if( $( this ).data('idx') ){
            $( '#' + responseId ).data( 'uri' , URI );
            jsonCallAndRunScript( URI , responseId , { 'id':$( this ).data('idx') , 'subaction':'read' } , 'Page' );
        }
    });
}
// end of Binding for List created by Ajax-call

// Binding for Edit-Form filled by Json-call
function bindEditorButtonEvents( URI , pluginUid ){
    var responseId = 'singleFormContainer_' + pluginUid;
    var formContainerId = 'formular_' + pluginUid;
    changeEditFormToEdit( formContainerId , pluginUid );
    
    //pager buttons
    $( '#button-back' ).on('click', function() {
            usroption = {};
            usroption['id'] = $( 'TABLE.type_edit TR.datarow[data-idx="' + $( '#' + responseId ).data('recordid') + '"]' ).prev().data( 'idx' );
            usroption['subaction'] = 'read';
            if( usroption['id'] >= 1 ) jsonCallAndRunScript( $( '#' + responseId ).data('uri') , responseId , usroption , 'Page' );
    });
    $( '#button-fwd' ).on('click', function() {
            usroption = {};
            usroption['id'] = $( 'TABLE.type_edit TR.datarow[data-idx="' + $( '#' + responseId ).data('recordid') + '"]' ).next().data( 'idx' );
            usroption['subaction'] = 'read';
            if( usroption['id'] >= 1 ) jsonCallAndRunScript( $( '#' + responseId ).data('uri') , responseId , usroption , 'Page' );
    });
    
    // klick on ADD button
    $( 'BUTTON[name="addFormButton"]' ).on('click', function() {
            $( '#' + responseId ).data( 'copynr' , '' );
            usroption = {};
            usroption['id'] = $( '#' + responseId ).data('recordid');
            usroption['subaction'] = 'clear';
            jsonCallAndRunScript( URI , responseId , usroption , 'Add' );
    });
    
    // klick on STORE-CREATE button
    $( 'BUTTON[name="storeCreateButton"]' ).on('click', function() {
            $( '#' + formContainerId ).fadeTo( 1 , 0.2 ); // dont fade out completely, otherwise the window will flickering
            usroption = {};
            usroption['record'] = $( '#' + formContainerId ).serialize();
            if( $( '#' + responseId ).data('copynr') == $( '#' + responseId ).data('recordid') ){
                usroption['id'] = $( '#' + responseId ).data('copynr');
                usroption['subaction'] = 'dupliz';
            }else{
                usroption['id'] = 0;
                usroption['subaction'] = 'create';
            }
            jsonCallAndRunScript( URI , responseId , usroption , 'Created');
    });
    // klick on ABORT-CREATE button
    $( 'BUTTON[name="abortCreateButton"]' ).on('click', function() {
            clearInfoBox(responseId);
            lastId = $( '#' + responseId ).data('recordid');
            URL = $( '#' + responseId ).data('uri');
            if( URL.length > 0 ){
                usroption = {};
                usroption['id'] = lastId;
                usroption['subaction'] = 'read';
                jsonCallAndRunScript( URL , responseId , usroption , 'Page' );
            }else{
                switchEditForm( pluginUid ,  0 , 500 );
            }
    });
    
    // klick on DUPLIZ button
    $( 'BUTTON[name="duplizFormButton"]' ).on('click', function() {
        // try to clear display-field for unique key
        var uidFieldname = $( '#' + responseId ).data('keyname');
        var uidRendertype = $( '#objectContainer_' + pluginUid + '_' + uidFieldname ).data('rendertype');
        if( uidRendertype != 'undefined' && uidRendertype.length > 0 ){
            var fName = 'insertJsonInObjectType_' + uidRendertype ;
            window[fName]('#objectContainer_' + pluginUid + '_' + uidFieldname , 'Kopie von ' + $( '#' + responseId ).data('recordid') );
        }
        // set uid to copy subordinated tables entries from
        $( '#' + responseId ).data( 'copynr' , $( '#' + responseId ).data('recordid') );
        // call form with corresponding buttons
        changeEditFormToCreate( formContainerId , pluginUid );
    });
    
    // klick on STORE button
    $( 'BUTTON[name="updateFormButton"]' ).on('click', function() {
        clearInfoBox(responseId);
        usroption = {};
        usroption['id'] = $( '#' + responseId ).data('recordid');
        usroption['record'] = $( '#' + formContainerId ).serialize();
        usroption['subaction'] = 'update';
        $( '#' + formContainerId ).fadeTo( 1 , 0.2 ); // dont fade out completely, otherwise the window will flickering
        jsonCallAndRunScript( URI , responseId , usroption , 'Created' );
    });

    // klick on DELETE button
    $( 'BUTTON[name="deleteFormButton"]' ).on('click', function() {
        var delId = $( '#' + responseId ).data('recordid');
        if (window.confirm('Datensatz Nr. "' + delId + '" wirklich löschen?')){
            usroption = {};
            usroption['id'] = delId;
            usroption['subaction'] = 'delete';
            //$( '#formular_' + pluginUid ).fadeTo( 1 , 0.2 ); // dont fade out completely, otherwise the window will flickering
            jsonCallAndRunScript( URI , responseId , usroption , 'Delete' );
        }
    });
    
    // klick on ABORT button
    $( 'BUTTON[name="abortFormButton"]' ).on('click', function() {
        clearInfoBox(responseId);
        $( '#' + responseId ).data( 'uri' , '' );
        switchEditForm( pluginUid ,  0 , 500 );
    });
    return false;
}
function changeEditFormToCreate( formContainerId , pluginUid ){
        var mainframe = '#singleFormContainer_' + pluginUid;
        $( mainframe + ' .createButtonBox' ).show();
        $( mainframe + ' .formButtonBox' ).hide();
        $( mainframe + ' .singleFormSubRecords' ).hide();
        clearInfoBox('singleFormContainer_' + pluginUid);
        URL = $( mainframe ).data('uri');
        if( URL.length > 0 ){
            $( 'BUTTON[name="abortCreateButton"]' ).html( ' Abbrechen' );
        }else{
            $( 'BUTTON[name="abortCreateButton"]' ).html( ' Schliessen' );
        }
}
function changeEditFormToEdit( formContainerId , pluginUid ){
        var mainframe = '#singleFormContainer_' + pluginUid;
        $( mainframe + ' .createButtonBox' ).hide();
        $( mainframe + ' .formButtonBox' ).show();
        $( mainframe + ' .singleFormSubRecords' ).show();
        clearInfoBox('singleFormContainer_' + pluginUid);
}

// switch the edit form on (display=1) or off (display=0)
function switchEditForm( pluginUid , display , delay ){
    if( display ){
        $( '#singleFormContainer_' + pluginUid ).fadeIn( delay , function() {
                $( '#singleButtonContainer_' + pluginUid ).hide(); // FIXME dont hide add-new button!
             }
        );
    }else{
        $( '#singleFormContainer_' + pluginUid ).fadeOut( delay , function() {
                $( '#singleButtonContainer_' + pluginUid ).show(); // FIXME dont hide add-new button!
            }
        );
    }
}

function clearInfoBox(responseId){
        $( '.objectInfos' ).hide();
        $( '.objectInfos' ).html( '' );
        $( '.objectInfos' ).removeClass( 'attention' );
}

// start of Json call (from Ajax-call)
function jsonCallAndRunScript( URI , responseId , usroptions , scriptToRun ){
    var aIdParts = responseId.split('_');
    var piUid = aIdParts[1];
    $.ajax({
        url : URI,
        type : 'GET',
		data: {'data':usroptions},
        dataType:'json',
        success : function(data) {
            var obj = JSON.parse( data );
            window[ 'insertJsonSearchResults_' + scriptToRun ]( obj , responseId );
            return true;
        },
        error : function(request,error)
        {
            $( '#formular_' + piUid ).fadeTo( 1 , 1 );
            switchEditForm( piUid ,  1 , 100 );
            if( request['status'] > 0 ){
                alert('error: ' + URI + ' Request ' + error + ': '+JSON.stringify(request));
                return false;
            }else{
                $( '#singleFormContainer_' + piUid ).html( JSON.stringify(request) );
            }
            return true;
        }
    });
}
function insertJsonSearchResults_Created( obj , responseId ){
        if( obj.error ){
            console.log( 'action:' + obj.subaction  + ' id:' + obj.id );
            $.each(obj.error,function( fieldname, text) {
                console.log( fieldname + ' ' + text + ' INSERTED IN #objectInfo_' + obj.pluginUid + '_' + fieldname);
                $( '#objectInfo_' + obj.pluginUid + '_' + fieldname ).html( '"' + fieldname + '" ' + text ).addClass( 'attention' ).show();
            });
            switchEditForm( obj.pluginUid ,  1 , 100 );
            $( '#formular_' + obj.pluginUid ).fadeTo( 1 , 1 );
        }else{
            insertJsonSearchResults_Page( obj , responseId );
        }
}
function insertJsonSearchResults_Add( obj , responseId ){
        $.each(obj.recordset,function( fieldname, datarow) {
            var rendertype = $( '#objectContainer_' + obj.pluginUid + '_' + fieldname ).data('rendertype');
            var fName = 'insertJsonInObjectType_' + rendertype ;
            // try to clear display-field for unique key
            window[fName]('#objectContainer_' + obj.pluginUid + '_' + fieldname , datarow);
        });
        switchEditForm( obj.pluginUid ,  1 , 100 );
        $( '#formular_' + obj.pluginUid ).fadeTo( 1 , 1 );
        changeEditFormToCreate( 'formular_' + obj.pluginUid , obj.pluginUid );
//         $('html,body').animate({scrollTop: $('#singleFormContainer_' + obj.pluginUid ).offset().top - 140 },'slow');
}
function insertJsonSearchResults_Delete( obj , responseId ){
        $( '#' + responseId ).data( 'recordid' , '' );
        $( '#' + responseId ).data( 'copynr' , '' );
        $( '#' + responseId ).data( 'uri' , '' );
        switchEditForm( obj.pluginUid ,  0 , 150 );
        // hide deleted recordset in list of found-results
        $( '#trnsSortPagerTable' + obj.pluginUid + ' TR[data-idx="' + obj.id + '"] TD' ).fadeOut( 500 );

        $.each(obj.recordset,function( fieldname, datarow) {
            var rendertype = $( '#objectContainer_' + obj.pluginUid + '_' + fieldname ).data('rendertype');
            var fName = 'insertJsonInObjectType_' + rendertype ;
            window[fName]('#objectContainer_' + obj.pluginUid + '_' + fieldname , datarow);
        });
}
function insertJsonSearchResults_Checkgroup( obj , responseId ){
        var aIdParts = responseId.split('_');
        var piUid = aIdParts[1];
        var field = aIdParts[2];
        var datarows = {};
        switchEditForm( piUid ,  1 , 100 );
        $( '#formular_' + piUid ).fadeTo( 1 , 1 );
        
        $.each(obj.recordset,function( fieldname, datarow) {
            datarows[fieldname] = datarow.uid_foreign;
        });
        insertJsonInObjectType_checkgroup( 'valuesList_' + piUid + '_' + field , datarows );
        $( '#valuesList_' + piUid + '_' + field ).animate({ color: "black" }, 500 );
        $( '#valuesList_' + piUid + '_' + field ).removeClass('blinker');
}
function insertJsonSearchResults_Page( obj , responseId ){
        if( obj.id > 0 ){ $( '#' + responseId ).data( 'recordid' , obj.id );};
        
        if( obj.error ){
            console.log( 'action:' + obj.subaction  + ' id:' + obj.id );
            $.each(obj.error,function( fieldname, text) {
                console.log( fieldname + ' ' + text  );
                $( '#objectInfo_' + obj.pluginUid + '_' + fieldname ).append( '"' + fieldname + '" ' + text ).addClass( 'attention' ).show();
            });
        }else{
            $.each(obj.recordset,function( fieldname, datarow) {
                var rendertype = $( '#objectContainer_' + obj.pluginUid + '_' + fieldname ).data('rendertype');
                var fName = 'insertJsonInObjectType_' + rendertype ;
                window[fName]('#objectContainer_' + obj.pluginUid + '_' + fieldname , datarow);
            });
        }
        // display formular
        switchEditForm( obj.pluginUid ,  1 , 100 );
        $( '#formular_' + obj.pluginUid ).fadeTo( 1 , 1 );
        changeEditFormToEdit( '#formular_' + obj.pluginUid , obj.pluginUid );
        // scroll to formular - 140px 
        //  $('html,body').animate({scrollTop: $('#singleFormContainer_' + obj.pluginUid ).offset().top - 140 },'slow');
}
// Element types: none, html, textarea, richtext, text, select, filtered-select, radiogroup, checkbox, checkgoup
function insertJsonInObjectType_( containerId , value  ){
        $( containerId ).html( value );
}
function insertJsonInObjectType_html( containerId , value  ){
        $( containerId ).html( value );
}
function insertJsonInObjectType_textarea( containerId , value  ){
        $( containerId ).html( value );
}
function insertJsonInObjectType_richtext( containerId , value  ){
        $( containerId ).html( value );
        $( '.jqte_editor' ).html( value );
}

function insertJsonInObjectType_text( containerId , value  ){
        $( containerId ).val( value );
}
function insertJsonInObjectType_date( containerId , value  ){
    if( value.length ){
        var aDate = value.split('-');
        $( containerId ).val( aDate[2] + '.' + aDate[1] + '.' + aDate[0] );
    }else{
        $( containerId ).val('');
    }
}
function insertJsonInObjectType_select( containerId , value  ){
        if( value == '' ) value = 0;
        $( containerId ).val( value );
}
function insertJsonInObjectType_filterselect( containerId , value  ){
        var aIdParts = containerId.split('_');
        var filterselectId = '#objectContainerFilter_' + aIdParts[1] + '_' + aIdParts[2];
        $( filterselectId ).val( value );
        $( filterselectId ).trigger( 'input' );
}

function insertJsonInObjectType_radiogroup( containerId , value  ){
        if( value == '' || value == null ) value = 0;
        $( containerId + ' input[type="radio"]' ).each(function () {
            $( this ).prop('checked',false);
            if( $( this ).attr( 'value') == value ){
                $( this ).prop('checked',true);
            }
        });
}
function insertJsonInObjectType_checkbox( containerId , value  ){
        if( value == 1 ){
            $( containerId ).prop('checked',true);
        }else{
            $( containerId ).prop('checked',false);
        }
}
function insertJsonInObjectType_checkgroup( containerId , datarow  ){
        $( containerId + ' input[type="checkbox"]' ).each(function () {
            $( this ).prop('checked',false);
        });
        $.each(datarow,function( i , value ) {
                $( containerId + ' input[type="checkbox"]' ).each(function () {
                    if( $( this ).attr( 'value') == value ){
                        $( this ).prop('checked',true);
                    }
                });
        });
        prependValuesToCheckgroupBox( containerId , datarow  );
}
// Element types end. 
// Individual element function
function prependValuesToCheckgroupBox( containerId , datarow  ){
        var aIdParts = containerId.split('_');
        var piUid = aIdParts[1];
        var fieldname = aIdParts[2];
        
        var optionlists = getOptionLists();
        var valuesListId = '#valuesList_' + piUid + '_' + fieldname;
        // clear box
        $( valuesListId ).html('');
        
        $.each(datarow,function( i , value ) {
            if( $( valuesListId ).html() ){ 
                $( valuesListId ).append( ', ' );
            }
            var container = '<span class="pointer" onClick="scrollToIdInSpecifiedBox(\'#ck_'+piUid+'_'+fieldname+'_'+value+'\',\'#checkgroupContainer_'+piUid+'_'+fieldname+'\')">' + optionlists[fieldname][ 'i.' + value] + '</span>';
            $( valuesListId ).append(  container );
        });
        if( $( valuesListId ).html() ) {
            $( valuesListId ).append( '.' );
        }else{
            $( valuesListId ).html( '<i>Keine Einträge.</i>' )
        }
}
function scrollToIdInSpecifiedBox( targetId , boxId ) {
            var scrollDistance = $( boxId ).scrollTop() + $( targetId ).offset().top - $( boxId ).offset().top;
            $( boxId ).animate( {	scrollTop: scrollDistance - 100 } , 100 );
}
//     end of individual element function.
// end of Json call from Ajax-call

