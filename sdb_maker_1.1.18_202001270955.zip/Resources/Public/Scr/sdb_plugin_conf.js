/*!
 * sdb_plugin_conf.js
 * 
 * Licensed MIT © Daniel Rueegg
 */

// start of Model->settingsAction
function initiatePluginEditFields() {
            // decide whether the table should be displayed with pager or with scrollbar
            $('#navigationType').change( function(){
                blackIfTrue( "lab_pagerSteps" , $( "#navigationType" ).val() );
            } );
            blackIfTrue( "lab_pagerSteps" , $( "#navigationType" ).val() );
            
            // enable all search filter in Editor 
            $('#filterEditEnable').click( function(){
                filterEditEnableClick();
            } );
            filterEditEnableClick();
            
            // enable all search filter in Preview 
            $('#filterPreviewEnable').click( function(){
                filterPreviewEnableClick();
            } );
            filterPreviewEnableClick();
            
            // force select-search filter in Preview and Editor
            $('#filterSelectorsForced').click( function(){
                filterEditEnableClick();
                filterPreviewEnableClick();
            } );
}
function displayIfTrue( targetContainer , isChecked ){
    if( isChecked == true || isChecked == 1  ){
        $('#' + targetContainer + ' input').attr('disabled',false); 
        $('#' + targetContainer + '').show(); 
    }else{ 
        $('#' + targetContainer + ' input').attr('disabled','disabled'); 
        $('#' + targetContainer + '').hide(); 
    }
}
function blackIfTrue( targetContainer , isChecked ){
    if( isChecked == true || isChecked == 1  ){
        $('#' + targetContainer + ' input').css('color','#000'); 
        $('#' + targetContainer + '').css('color','#000'); 
    }else{ 
        $('#' + targetContainer + ' input').css('color','#999'); 
        $('#' + targetContainer + '').css('color','#999'); 
    }
}
function filterEditEnableClick(){
    displayIfTrue( "lab_edit" , $( "#filterEditEnable" ).is(':checked') );
    displayIfTrue( "lab_edit_selectorsOnly" , $( "#filterEditEnable" ).is(':checked') == false && $( '#filterSelectorsForced' ).is(':checked') );
    displayIfTrue( "lab_edit_hidden" , $( "#filterEditEnable" ).is(':checked') == false && $( '#filterSelectorsForced' ).is(':checked') == false );
}
function filterPreviewEnableClick(){
    displayIfTrue( "lab_preview" , $( "#filterPreviewEnable" ).is(':checked') );
    displayIfTrue( "lab_preview_selectorsOnly" , $( "#filterPreviewEnable" ).is(':checked') == false && $( '#filterSelectorsForced' ).is(':checked') );
    displayIfTrue( "lab_preview_hidden" , $( "#filterPreviewEnable" ).is(':checked') == false && $( '#filterSelectorsForced' ).is(':checked') == false );
}

// called on load in Model/Settings.html
function initiateTableRowMove() {
	// cahnges the sort order in a edit-table
 	$('.da').css('cursor','pointer');
 	$('.da').click(function () { moveRow( $( this ).closest('TR') , 'down' ); });
    
	$('.ua').css('cursor','pointer');
	$('.ua').click(function () { moveRow( $( this ).closest('TR') , 'up' ); });
}

function moveRow( selectedTRobj , direction ) {
        // detect the other row otherTRobj
        var cssSplit = $( selectedTRobj ).attr('class').split('_');
        if( direction == 'up' ){
            otherNr = parseInt(cssSplit[1]) -1 ;
        }else{
            otherNr = parseInt(cssSplit[1]) +1 ;
        }
        otherTRobj = $( '.' + cssSplit[0] + '_' + otherNr );
        
        // change the hidden sort  value of both rows
        selectedTRobj.find('.nr').each(function () {
            var selectedNrObj = $( this );
            var selectedNr = $( this ).val();
            otherTRobj.find('.nr').each(function () {
                selectedNrObj.val( $( this ).val() );
                $( this ).val(selectedNr);
            });
        });
        
        // store all TDs from selected TR in a array. Store values of selected row
		var aSelectedTDObj = [];
		var aSelectedTDInput = [];
		var aSelectedTDSelect = [];
        selectedTRobj.find('TD').each(function ( z ) {
            if( !$( this ).hasClass('ua') && !$( this ).hasClass('da') ){
                aSelectedTDObj[z] = $( this );
                // store input elements values of selected row
                aSelectedTDInput[z] = [];
                $( this ).find('INPUT').each(function ( i ) {
                    if( $( this ).attr('type') == 'text' ){
                        aSelectedTDInput[z][i] = $( this ).prop('value');
                    } else if( $( this ).attr('type') == 'checkbox' ){
                        aSelectedTDInput[z][i] = $( this ).prop('checked');
                    }
                });
                // store select value of selected row
                aSelectedTDSelect[z] = [];
                $( this ).find('SELECT').each(function ( i ) {
                     aSelectedTDSelect[z][i] = $( this ).prop('value');
                });
            }
        });
        
		var aOtherTDInput = [];
		var aOtherTDSelect = [];
        otherTRobj.find('TD').each(function ( y ) {
            if( !$( this ).hasClass('ua') && !$( this ).hasClass('da') ){
                // store input elements values of other row
                aOtherTDInput[y] = [];
                $( this ).find("INPUT").each(function ( i ) {
                    if( $( this ).attr('type') == 'text' ){
                        aOtherTDInput[y][i] = $( this ).prop('value');
                    } else if( $( this ).attr('type') == 'checkbox' ){
                        aOtherTDInput[y][i] = $( this ).prop('checked');
                    }
                });
                // store select value of other row
                aOtherTDSelect[y] = [];
                $( this ).find('SELECT').each(function ( i ) {
                     aOtherTDSelect[y][i] = $( this ).prop('value');
                });
                
                // change all td-contents with each other, including sort element
                var selectedInnerHtml = $( aSelectedTDObj[y] ).html();
                $( aSelectedTDObj[y] ).html($( this ).html());
                $( this ).html( selectedInnerHtml );
                
                // from here on the 'this' points to selected row 
                // and aSelectedTDObj points to other row
                
                // insert values in selected row
                $( aSelectedTDObj[y] ).find("INPUT").each(function ( i ) {
                    if( $( this ).attr('type') == 'text' ){
                         $( this ).prop('value',aOtherTDInput[y][i]);
                    } else if( $( this ).attr('type') == 'checkbox' ){
                         $( this ).prop('checked',aOtherTDInput[y][i]);
                    }
                });
                $( aSelectedTDObj[y] ).find("SELECT").each(function ( i ) {
                      $( this ).prop('value',aOtherTDSelect[y][i]);
                });
                // insert values in other row
                $( this ).find("INPUT").each(function ( i ) {
                    if( $( this ).attr('type') == 'text' ){
                         $( this ).prop('value',aSelectedTDInput[y][i]);
                    } else if( $( this ).attr('type') == 'checkbox' ){
                         $( this ).prop('checked',aSelectedTDInput[y][i]);
                    }
                });
                $( this ).find('SELECT').each(function ( i ) {
                         $( this ).prop('value',aSelectedTDSelect[y][i]);
                });
            }
        });
}
// end of Model->settingsAction
